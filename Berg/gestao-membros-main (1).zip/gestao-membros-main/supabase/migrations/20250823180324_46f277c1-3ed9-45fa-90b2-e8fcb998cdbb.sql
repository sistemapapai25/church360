-- Verificar e criar alguns eventos de teste para 2025 para validar a ordenação
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'agenda'
  ) THEN
    -- Primeiro, vamos verificar os dados atuais da agenda
    PERFORM data, descricao FROM agenda ORDER BY data DESC LIMIT 10;
  END IF;
END
$$;