DO $$
BEGIN
  -- Enable Row Level Security on tables missing RLS policies
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'agenda_full') THEN
    ALTER TABLE public.agenda_full ENABLE ROW LEVEL SECURITY;
    
    -- Create RLS policies for agenda_full (authenticated users can view all events)
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'agenda_full' AND policyname = 'agenda_full_select_authenticated') THEN
      CREATE POLICY "agenda_full_select_authenticated" 
      ON public.agenda_full 
      FOR SELECT 
      USING (auth.role() = 'authenticated'::text);
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'me') THEN
    ALTER TABLE public.me ENABLE ROW LEVEL SECURITY;
    
    -- Create RLS policies for me (users can only see their own profile data)
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'me' AND policyname = 'me_select_own_profile') THEN
      CREATE POLICY "me_select_own_profile" 
      ON public.me 
      FOR SELECT 
      USING (auth.uid() = auth_uid);
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'raizes_funil_mensal_por_lider') THEN
    ALTER TABLE public.raizes_funil_mensal_por_lider ENABLE ROW LEVEL SECURITY;
    
    -- Create RLS policies for raizes_funil_mensal_por_lider (authenticated users can view metrics)
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'raizes_funil_mensal_por_lider' AND policyname = 'raizes_funil_select_authenticated') THEN
      CREATE POLICY "raizes_funil_select_authenticated" 
      ON public.raizes_funil_mensal_por_lider 
      FOR SELECT 
      USING (auth.role() = 'authenticated'::text);
    END IF;
  END IF;

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'raizes_lideres_resolvidos') THEN
    ALTER TABLE public.raizes_lideres_resolvidos ENABLE ROW LEVEL SECURITY;
    
    -- Create RLS policies for raizes_lideres_resolvidos (authenticated users can view leader data)
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'raizes_lideres_resolvidos' AND policyname = 'raizes_lideres_select_authenticated') THEN
      CREATE POLICY "raizes_lideres_select_authenticated" 
      ON public.raizes_lideres_resolvidos 
      FOR SELECT 
      USING (auth.role() = 'authenticated'::text);
    END IF;
  END IF;
END
$$;