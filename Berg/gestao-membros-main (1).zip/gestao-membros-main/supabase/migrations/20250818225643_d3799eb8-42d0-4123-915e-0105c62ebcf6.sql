-- Fix membros RLS policies to allow admin access
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name IN ('membros', 'usuarios')
  ) THEN
    -- Add missing admin policy for membros table
    DROP POLICY IF EXISTS "membros_select_admin" ON public.membros;
    CREATE POLICY "membros_select_admin" 
    ON public.membros 
    FOR SELECT 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    );

    -- Also add admin write access
    DROP POLICY IF EXISTS "membros_write_admin" ON public.membros;
    CREATE POLICY "membros_write_admin" 
    ON public.membros 
    FOR ALL 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    );
  END IF;
END
$$;