-- Restringir visualização de usuários apenas para ADM
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios'
  )
  AND EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros'
  ) THEN
    CREATE OR REPLACE FUNCTION public.list_users()
    RETURNS TABLE (
      idusuario text,
      email text,
      idmembro text,
      permissao text,
      auth_uid uuid,
      nome_membro text,
      created_at timestamptz
    )
    LANGUAGE sql
    SECURITY DEFINER
    SET search_path = public
    AS $fn$
      SELECT 
        u.idusuario::text,
        u.email,
        u.idmembro::text,
        u.permissao,
        u.auth_uid,
        COALESCE(m.nome, 'Sem membro vinculado') AS nome_membro,
        u.created_at
      FROM public.usuarios u
      LEFT JOIN public.membros m ON u.idmembro = m.idmembro
      WHERE EXISTS (
        SELECT 1 FROM me WHERE permissao = 'ADM'
      )
      ORDER BY u.created_at DESC NULLS LAST;
    $fn$;
  END IF;
END
$$;