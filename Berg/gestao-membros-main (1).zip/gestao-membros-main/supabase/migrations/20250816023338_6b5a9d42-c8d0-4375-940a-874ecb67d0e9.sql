-- Add data_casamento field to membros table if table exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='membros' AND column_name='data_casamento') THEN
      ALTER TABLE public.membros 
      ADD COLUMN data_casamento date;
    END IF;
  END IF;
END
$$;