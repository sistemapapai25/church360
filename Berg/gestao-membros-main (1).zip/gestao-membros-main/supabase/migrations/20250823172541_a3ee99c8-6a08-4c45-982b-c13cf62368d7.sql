DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Remove the problematic policy that causes infinite recursion
    DROP POLICY IF EXISTS "usuarios_select_admin_only" ON public.usuarios;

    -- Create a security definer function to check if current user is admin
    CREATE OR REPLACE FUNCTION public.is_current_user_admin()
    RETURNS boolean
    LANGUAGE sql
    STABLE
    SECURITY DEFINER
    SET search_path TO 'public'
    AS $function$
      SELECT EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      );
    $function$;

    -- Create new policy using the security definer function to avoid recursion
    CREATE POLICY "usuarios_select_admin_only" 
    ON public.usuarios 
    FOR SELECT 
    USING (public.is_current_user_admin());
  END IF;
END
$$;

-- The existing "usuarios_select_by_auth_uid" policy remains to allow users to read their own record