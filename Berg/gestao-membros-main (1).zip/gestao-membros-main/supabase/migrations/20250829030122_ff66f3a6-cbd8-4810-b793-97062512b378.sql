-- Habilitar RLS nas tabelas eventos_igreja e locais
ALTER TABLE public.eventos_igreja ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.locais ENABLE ROW LEVEL SECURITY;

-- Criar políticas para eventos_igreja
CREATE POLICY "eventos_igreja_select_authenticated" 
ON public.eventos_igreja 
FOR SELECT 
USING (auth.role() = 'authenticated');

CREATE POLICY "eventos_igreja_insert_admin" 
ON public.eventos_igreja 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);

CREATE POLICY "eventos_igreja_update_admin" 
ON public.eventos_igreja 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);

CREATE POLICY "eventos_igreja_delete_admin" 
ON public.eventos_igreja 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);

-- Criar políticas para locais
CREATE POLICY "locais_select_authenticated" 
ON public.locais 
FOR SELECT 
USING (auth.role() = 'authenticated');

CREATE POLICY "locais_insert_admin" 
ON public.locais 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);

CREATE POLICY "locais_update_admin" 
ON public.locais 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);

CREATE POLICY "locais_delete_admin" 
ON public.locais 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.usuarios 
    WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  )
);