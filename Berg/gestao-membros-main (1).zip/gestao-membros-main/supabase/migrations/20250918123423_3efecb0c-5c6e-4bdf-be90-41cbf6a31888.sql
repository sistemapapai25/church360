-- Adicionar política de INSERT para a tabela lideres
CREATE POLICY "lideres_insert_authenticated" 
ON public.lideres 
FOR INSERT 
WITH CHECK (auth.role() = 'authenticated'::text);