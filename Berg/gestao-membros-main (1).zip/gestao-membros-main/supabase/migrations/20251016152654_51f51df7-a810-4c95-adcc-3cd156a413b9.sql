-- Adicionar campo de observação na tabela departamentos
ALTER TABLE public.departamentos
ADD COLUMN observacao TEXT;