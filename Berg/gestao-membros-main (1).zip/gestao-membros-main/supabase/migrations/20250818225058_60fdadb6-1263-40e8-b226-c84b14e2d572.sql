-- Fix circular dependency in RLS policies for usuarios table
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Drop existing policies that cause circular dependency
    DROP POLICY IF EXISTS "usuarios_select_own_record" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_select_admin_all" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_admin_full_access" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_admin_operations" ON public.usuarios;

    -- Create simpler, non-circular policies
    -- Policy 1: Allow all authenticated users to read usuarios table
    CREATE POLICY "usuarios_read_authenticated" 
    ON public.usuarios 
    FOR SELECT 
    USING (auth.role() = 'authenticated'::text);

    -- Policy 2: Only admins can write to usuarios table
    CREATE POLICY "usuarios_write_admin_only" 
    ON public.usuarios 
    FOR ALL 
    USING (
      EXISTS (
        SELECT 1 FROM usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
        AND u.auth_uid IS NOT NULL
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
        AND u.auth_uid IS NOT NULL
      )
    );
  END IF;
END
$$;