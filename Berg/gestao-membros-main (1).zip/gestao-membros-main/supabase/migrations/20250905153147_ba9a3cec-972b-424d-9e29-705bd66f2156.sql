-- Criar políticas RLS para UPDATE e DELETE na tabela areas

-- Política para permitir UPDATE de áreas por usuários autenticados
CREATE POLICY "areas_update_auth" 
ON public.areas 
FOR UPDATE 
TO authenticated
USING (true)
WITH CHECK (true);

-- Política para permitir DELETE de áreas por usuários autenticados (para soft delete)
CREATE POLICY "areas_delete_auth" 
ON public.areas 
FOR DELETE 
TO authenticated
USING (true);