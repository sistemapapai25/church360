-- Permitir que usuários autenticados gerenciem seus próprios relacionamentos familiares
DO $$
BEGIN
  -- Apenas se as tabelas e a view existirem
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='relacionamentos_familiares')
     AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios')
  THEN
    -- Política de INSERT: usuário pode inserir quando o relacionamento pertence ao seu próprio membro_id
    CREATE POLICY IF NOT EXISTS "relacionamentos_insert_self"
    ON public.relacionamentos_familiares
    FOR INSERT
    WITH CHECK (
      auth.role() = 'authenticated' AND
      membro_id = (SELECT idmembro FROM me)
    );

    -- Política de DELETE: usuário pode deletar quando ele é o membro ou o parente envolvido
    CREATE POLICY IF NOT EXISTS "relacionamentos_delete_self"
    ON public.relacionamentos_familiares
    FOR DELETE
    USING (
      auth.role() = 'authenticated' AND (
        membro_id = (SELECT idmembro FROM me) OR
        parente_id = (SELECT idmembro FROM me)
      )
    );

    -- Política de UPDATE: usuário pode alterar quando ele é o membro proprietário da linha
    CREATE POLICY IF NOT EXISTS "relacionamentos_update_self"
    ON public.relacionamentos_familiares
    FOR UPDATE
    USING (
      auth.role() = 'authenticated' AND
      membro_id = (SELECT idmembro FROM me)
    )
    WITH CHECK (
      auth.role() = 'authenticated' AND
      membro_id = (SELECT idmembro FROM me)
    );
  END IF;
END
$$;