-- Improve the create_user_with_profile function to work more reliably
CREATE OR REPLACE FUNCTION public.create_user_with_profile(
  p_email text,
  p_password text,
  p_idmembro text DEFAULT NULL,
  p_permissao text DEFAULT 'USR'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_user_id uuid;
  new_idusuario text;
  result json;
  existing_user_count int;
BEGIN
  -- Apenas ADM pode criar usuários
  IF NOT EXISTS (
    SELECT 1 FROM me WHERE permissao = 'ADM'
  ) THEN
    RAISE EXCEPTION 'Apenas administradores podem criar usuários';
  END IF;

  -- Verificar se email já existe na tabela usuarios
  SELECT COUNT(*) INTO existing_user_count 
  FROM usuarios WHERE email = p_email;
  
  IF existing_user_count > 0 THEN
    RAISE EXCEPTION 'Email já cadastrado no sistema';
  END IF;

  -- Verificar se email já existe no auth.users
  SELECT COUNT(*) INTO existing_user_count 
  FROM auth.users WHERE email = p_email;
  
  IF existing_user_count > 0 THEN
    RAISE EXCEPTION 'Email já existe na autenticação';
  END IF;

  -- Criar usuário no Supabase Auth usando função administrativa
  BEGIN
    -- Usar INSERT direto na tabela auth.users com password encriptada
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      p_email,
      crypt(p_password, gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      NOW(),
      NOW(),
      '',
      '',
      '',
      ''
    )
    RETURNING id INTO new_user_id;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE EXCEPTION 'Erro ao criar usuário na autenticação: %', SQLERRM;
  END;

  IF new_user_id IS NULL THEN
    RAISE EXCEPTION 'Erro: ID do usuário não foi gerado';
  END IF;

  -- Gerar novo idusuario
  SELECT 'USR' || LPAD((COALESCE(MAX(SUBSTRING(idusuario, 4)::int), 0) + 1)::text, 6, '0')
  INTO new_idusuario
  FROM usuarios
  WHERE idusuario ~ '^USR[0-9]{6}$';

  -- Inserir na tabela usuarios
  BEGIN
    INSERT INTO usuarios (idusuario, email, idmembro, permissao, auth_uid)
    VALUES (new_idusuario, p_email, p_idmembro, p_permissao, new_user_id);
  EXCEPTION
    WHEN OTHERS THEN
      -- Em caso de erro, remover o usuário criado
      DELETE FROM auth.users WHERE id = new_user_id;
      RAISE EXCEPTION 'Erro ao criar registro do usuário: %', SQLERRM;
  END;

  -- Retornar resultado de sucesso
  SELECT json_build_object(
    'success', true,
    'user_id', new_user_id,
    'idusuario', new_idusuario,
    'email', p_email,
    'permissao', p_permissao,
    'message', 'Usuário criado com sucesso'
  ) INTO result;

  RETURN result;

EXCEPTION
  WHEN OTHERS THEN
    -- Em caso de qualquer erro, tentar limpar
    BEGIN
      IF new_user_id IS NOT NULL THEN
        DELETE FROM auth.users WHERE id = new_user_id;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
    
    RAISE EXCEPTION 'Erro ao criar usuário: %', SQLERRM;
END;
$$;