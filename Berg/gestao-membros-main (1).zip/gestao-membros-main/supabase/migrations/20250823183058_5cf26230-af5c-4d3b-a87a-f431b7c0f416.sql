-- Função para popular auth_uid dos usuários existentes
CREATE OR REPLACE FUNCTION populate_auth_uid()
RETURNS void AS $$
DECLARE
    user_record RECORD;
    auth_record RECORD;
BEGIN
    -- Para cada usuário sem auth_uid
    FOR user_record IN 
        SELECT idusuario, email FROM usuarios WHERE auth_uid IS NULL
    LOOP
        -- Buscar o auth_uid correspondente
        SELECT id INTO auth_record
        FROM auth.users 
        WHERE email = user_record.email
        LIMIT 1;
        
        -- Se encontrou, atualizar
        IF auth_record.id IS NOT NULL THEN
            UPDATE usuarios 
            SET auth_uid = auth_record.id
            WHERE idusuario = user_record.idusuario;
            
            RAISE NOTICE 'Atualizado usuário % com auth_uid %', user_record.email, auth_record.id;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Executar a função
SELECT populate_auth_uid();

-- Remover a função após uso
DROP FUNCTION IF EXISTS populate_auth_uid();