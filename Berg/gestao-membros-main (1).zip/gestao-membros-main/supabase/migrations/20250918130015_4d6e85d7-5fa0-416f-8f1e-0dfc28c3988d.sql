-- Ensure a safe and unique idlider generation on the database side
-- 1) Create sequence for lideres
CREATE SEQUENCE IF NOT EXISTS public.lideres_seq;

-- 2) Initialize sequence to current max numeric part from existing IDs
SELECT setval(
  'public.lideres_seq',
  COALESCE(
    (SELECT MAX(SUBSTRING(idlider, 4)::int) FROM public.lideres WHERE idlider ~ '^LID[0-9]{6}$'),
    0
  )
);

-- 3) Set default for idlider to use the sequence with LID prefix and zero padding
ALTER TABLE public.lideres 
ALTER COLUMN idlider SET DEFAULT (
  'LID' || LPAD(nextval('public.lideres_seq')::text, 6, '0')
);
