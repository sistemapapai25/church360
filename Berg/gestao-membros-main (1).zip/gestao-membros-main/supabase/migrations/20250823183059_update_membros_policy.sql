-- Remover a política antiga
DROP POLICY IF EXISTS "membros_admin_write" ON public.membros;

-- Criar a nova política que permite ADM e OPE
CREATE POLICY "membros_admin_write" 
ON public.membros FOR ALL 
USING (EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE')))
WITH CHECK (EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE')));