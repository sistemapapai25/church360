-- Add conjuge_id field to membros table with foreign key constraint if table exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    -- Add column if not exists
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='membros' AND column_name='conjuge_id') THEN
      ALTER TABLE public.membros 
      ADD COLUMN conjuge_id TEXT;

      -- Add foreign key constraint if not exists
      IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints WHERE table_schema='public' AND table_name='membros' AND constraint_name='fk_membros_conjuge') THEN
        ALTER TABLE public.membros
        ADD CONSTRAINT fk_membros_conjuge
        FOREIGN KEY (conjuge_id)
        REFERENCES public.membros(idmembro)
        ON DELETE SET NULL;
      END IF;

      -- Create index if not exists
      IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND tablename='membros' AND indexname='idx_membros_conjuge') THEN
        CREATE INDEX idx_membros_conjuge ON public.membros(conjuge_id);
      END IF;
    END IF;
  END IF;
END
$$;