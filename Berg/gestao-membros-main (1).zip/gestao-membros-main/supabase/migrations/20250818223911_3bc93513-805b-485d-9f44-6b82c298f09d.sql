-- Fix Security Definer Views by recreating them with SECURITY INVOKER
-- This ensures views respect RLS policies and user permissions

DO $$
BEGIN
  -- First, check if all required tables exist
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name IN ('agenda', 'departamentos', 'membros', 'eventos_igreja', 'locais', 'status_agenda')
  ) THEN
    -- Drop and recreate agenda_full with security_invoker=on
    DROP VIEW IF EXISTS public.agenda_full CASCADE;
    
    CREATE VIEW public.agenda_full
    WITH (security_invoker=on)
    AS
    SELECT a.idagenda,
        a.iddepto,
        d.nome AS departamento,
        a.idlider,
        m.nome AS nome_lider,
        a.data,
        a.horario_inicial,
        a.horario_final,
        (make_timestamp((EXTRACT(year FROM a.data))::integer, (EXTRACT(month FROM a.data))::integer, (EXTRACT(day FROM a.data))::integer, (EXTRACT(hour FROM a.horario_inicial))::integer, (EXTRACT(minute FROM a.horario_inicial))::integer, 0::double precision)) AS inicio_ts,
        (make_timestamp((EXTRACT(year FROM a.data))::integer, (EXTRACT(month FROM a.data))::integer, (EXTRACT(day FROM a.data))::integer, (EXTRACT(hour FROM a.horario_final))::integer, (EXTRACT(minute FROM a.horario_final))::integer, 0::double precision)) AS fim_ts,
        ei.evento AS nome_evento,
        a.ideventoig,
        a.descricao,
        a.observacao,
        a.idlocal,
        l.local AS nome_local,
        a.idstatus,
        s.status AS status_evento,
        s.cor AS cor_evento,
        a.created_by,
        a.created_at,
        a.updated_at
    FROM agenda a
    LEFT JOIN departamentos d ON (a.iddepto = d.iddepto)
    LEFT JOIN membros m ON (a.idlider = m.idmembro)
     LEFT JOIN eventos_igreja ei ON (a.ideventoig = ei.ideventoig)
      LEFT JOIN locais l ON (a.idlocal = l.idlocal)
      LEFT JOIN status_agenda s ON (a.idstatus = s.idstatus);
  END IF;
END
$$;

-- Drop and recreate me with security_invoker=on  
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    DROP VIEW IF EXISTS public.me CASCADE;
    CREATE VIEW public.me
    WITH (security_invoker=on)
    AS
    SELECT idusuario,
        idmembro,
        email,
        permissao,
        auth_uid
    FROM usuarios u
    WHERE (auth_uid = auth.uid());
  END IF;
END
$$;

-- Drop and recreate raizes_lideres_resolvidos with security_invoker=on
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name IN ('lideres', 'membros', 'departamentos')
  ) THEN
    DROP VIEW IF EXISTS public.raizes_lideres_resolvidos CASCADE;
    CREATE VIEW public.raizes_lideres_resolvidos
    WITH (security_invoker=on)
    AS
    WITH base AS (
      SELECT l.idlider,
        l.iddepto,
        l.status,
        COALESCE(m.nome, m2.nome) AS nome
      FROM (((lideres l
        LEFT JOIN membros m ON (l.idmembro = m.idmembro))
        LEFT JOIN departamentos d ON (l.iddepto = d.iddepto))
        LEFT JOIN membros m2 ON (d.liderdepto1 = m2.idmembro))
      WHERE (l.status = 'Ativo'::text)
    )
    SELECT base.idlider,
      base.nome,
      lower(regexp_replace(base.nome, '[^a-zA-Z0-9]+'::text, ''::text, 'g'::text)) AS nome_ord
    FROM base
    WHERE (base.nome IS NOT NULL)
    ORDER BY (lower(regexp_replace(base.nome, '[^a-zA-Z0-9]+'::text, ''::text, 'g'::text)));
  END IF;
END
$$;

-- Drop and recreate raizes_funil_mensal_por_lider with security_invoker=on
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'visitantes'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.views 
    WHERE table_schema = 'public' 
    AND table_name = 'raizes_lideres_resolvidos'
  ) THEN
    DROP VIEW IF EXISTS public.raizes_funil_mensal_por_lider CASCADE;
    CREATE VIEW public.raizes_funil_mensal_por_lider
    WITH (security_invoker=on)
    AS
    SELECT (date_trunc('month'::text, v.created_at))::date AS mes,
      COALESCE(r.nome, '[Sem responsável]'::text) AS responsavel_nome,
      COALESCE(v.raizes_status, 'Novo'::text) AS status,
      count(*) AS qtd
    FROM (visitantes v
      LEFT JOIN raizes_lideres_resolvidos r ON (v.responsavel_id = r.idlider))
    GROUP BY ((date_trunc('month'::text, v.created_at))::date), (COALESCE(r.nome, '[Sem responsável]'::text)), (COALESCE(v.raizes_status, 'Novo'::text))
    ORDER BY ((date_trunc('month'::text, v.created_at))::date) DESC, (COALESCE(r.nome, '[Sem responsável]'::text));
  END IF;
END
$$;