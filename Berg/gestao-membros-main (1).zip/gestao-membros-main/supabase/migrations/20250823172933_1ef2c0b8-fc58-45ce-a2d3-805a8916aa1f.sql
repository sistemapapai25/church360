-- Fix the reset password function to properly handle user lookup
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    CREATE OR REPLACE FUNCTION public.reset_user_password(p_user_id uuid, p_new_password text DEFAULT '123456'::text)
    RETURNS json
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path TO 'public'
    AS $function$
    DECLARE
      result JSON;
      user_exists boolean;
    BEGIN
      -- Only ADM can reset passwords
      IF NOT EXISTS (
        SELECT 1 FROM public.usuarios WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      ) THEN
        RAISE EXCEPTION 'Apenas administradores podem resetar senhas';
      END IF;

      -- Check if user exists in auth.users table
      SELECT EXISTS (SELECT 1 FROM auth.users WHERE id = p_user_id) INTO user_exists;
      
      IF NOT user_exists THEN
        RAISE EXCEPTION 'Usuário não encontrado no sistema de autenticação';
      END IF;

      -- Update user password using Supabase auth
      UPDATE auth.users 
      SET encrypted_password = extensions.crypt(p_new_password, extensions.gen_salt('bf')),
          updated_at = now()
      WHERE id = p_user_id;
      
      -- Double check if update was successful
      IF NOT FOUND THEN
        RAISE EXCEPTION 'Falha ao atualizar senha do usuário';
      END IF;
      
      result := json_build_object(
        'success', true, 
        'message', 'Senha resetada com sucesso',
        'new_password', p_new_password
      );
      RETURN result;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE EXCEPTION 'Erro ao resetar senha: %', SQLERRM;
    END;
    $function$;
  END IF;
END
$$;

-- Fix RLS policies for relacionamentos_familiares table
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name IN ('relacionamentos_familiares', 'usuarios')
  ) THEN
    -- Drop existing restrictive policies
    DROP POLICY IF EXISTS "relacionamentos_select_all" ON public.relacionamentos_familiares;

    -- Create comprehensive policies for family relationships
    CREATE POLICY "relacionamentos_select_authenticated" 
    ON public.relacionamentos_familiares 
    FOR SELECT 
    USING (auth.role() = 'authenticated');

    CREATE POLICY "relacionamentos_insert_admin" 
    ON public.relacionamentos_familiares 
    FOR INSERT 
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );

    CREATE POLICY "relacionamentos_update_admin" 
    ON public.relacionamentos_familiares 
    FOR UPDATE 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );

    CREATE POLICY "relacionamentos_delete_admin" 
    ON public.relacionamentos_familiares 
    FOR DELETE 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );
  END IF;
END
$$;