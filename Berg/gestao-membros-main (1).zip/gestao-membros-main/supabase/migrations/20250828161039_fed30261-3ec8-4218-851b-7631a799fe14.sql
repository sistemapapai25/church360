-- Adicionar usuário logado na tabela usuarios se não existir
DO $$
DECLARE
    current_user_id uuid;
    current_email text;
    new_user_id text;
BEGIN
    -- Pegar o ID e email do usuário logado
    SELECT id, email INTO current_user_id, current_email 
    FROM auth.users 
    WHERE id = 'd7b1c535-bd40-499b-8be4-f45fc2de39ac';
    
    -- Se o usuário existe mas não está na tabela usuarios, adicionar
    IF current_user_id IS NOT NULL THEN
        -- Verificar se já existe na tabela usuarios
        IF NOT EXISTS (SELECT 1 FROM usuarios WHERE auth_uid = current_user_id) THEN
            -- Gerar novo idusuario
            SELECT 'USR' || LPAD((COALESCE(MAX(SUBSTRING(idusuario, 4)::int), 0) + 1)::text, 6, '0')
            INTO new_user_id
            FROM usuarios
            WHERE idusuario ~ '^USR[0-9]{6}$';
            
            -- Inserir o usuário na tabela
            INSERT INTO usuarios (idusuario, email, permissao, auth_uid)
            VALUES (new_user_id, current_email, 'ADM', current_user_id);
            
            RAISE NOTICE 'Usuário % adicionado com ID % e permissão ADM', current_email, new_user_id;
        ELSE
            RAISE NOTICE 'Usuário % já existe na tabela usuarios', current_email;
        END IF;
    ELSE
        RAISE NOTICE 'Usuário com ID % não encontrado na tabela auth.users', 'd7b1c535-bd40-499b-8be4-f45fc2de39ac';
    END IF;
END $$;