-- Fix RLS policies for usuarios table to allow proper authentication
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Drop existing restrictive policies
    DROP POLICY IF EXISTS "usuarios_select_self_or_admin" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_admin_write" ON public.usuarios;

    -- Create correct policies that allow users to access their own data
    -- Policy 1: Users can view their own user record
    CREATE POLICY "usuarios_select_own_record" 
    ON public.usuarios 
    FOR SELECT 
    USING (auth.uid() = auth_uid);

    -- Policy 2: Admins can view all user records  
    CREATE POLICY "usuarios_select_admin_all" 
    ON public.usuarios 
    FOR SELECT 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    );

    -- Keep admin write permissions
    CREATE POLICY "usuarios_admin_full_access" 
    ON public.usuarios 
    FOR ALL 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() 
        AND u.permissao = 'ADM'
      )
    );
  END IF;
END
$$;