-- Atualizar o auth_uid do usuário para corresponder ao usuário autenticado atual se a tabela existir
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios') THEN
    UPDATE usuarios 
    SET auth_uid = 'd7b1c535-bd40-499b-8bed-f45fc2de39ac'
    WHERE email = 'prbergnterra@gmail.com';
  END IF;
END
$$;