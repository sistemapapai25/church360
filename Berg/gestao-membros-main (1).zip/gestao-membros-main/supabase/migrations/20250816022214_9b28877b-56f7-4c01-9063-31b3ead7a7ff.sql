-- Criar tabela de relacionamentos familiares entre membros apenas se a tabela membros existir
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    -- Criar tabela se não existir
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='relacionamentos_familiares') THEN
      CREATE TABLE public.relacionamentos_familiares (
          id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
          membro_id TEXT NOT NULL REFERENCES public.membros(idmembro) ON DELETE CASCADE,
          parente_id TEXT NOT NULL REFERENCES public.membros(idmembro) ON DELETE CASCADE,
          tipo_relacionamento TEXT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
          updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
          
          -- Evitar duplicatas do mesmo relacionamento
          UNIQUE(membro_id, parente_id, tipo_relacionamento)
      );

      -- Criar índices para melhor performance
      CREATE INDEX idx_relacionamentos_membro ON public.relacionamentos_familiares(membro_id);
      CREATE INDEX idx_relacionamentos_parente ON public.relacionamentos_familiares(parente_id);

      -- Habilitar RLS
      ALTER TABLE public.relacionamentos_familiares ENABLE ROW LEVEL SECURITY;

      -- Política para visualização - todos usuários autenticados podem ver
      CREATE POLICY "relacionamentos_select_all" 
      ON public.relacionamentos_familiares 
      FOR SELECT 
      USING (auth.role() = 'authenticated');

      -- Política para inserção - apenas admins
      CREATE POLICY "relacionamentos_admin_write" 
      ON public.relacionamentos_familiares 
      FOR ALL 
      USING (EXISTS (
        SELECT 1 FROM me WHERE permissao = 'ADM'
      ))
      WITH CHECK (EXISTS (
        SELECT 1 FROM me WHERE permissao = 'ADM'
      ));

      -- Trigger para atualizar updated_at
      CREATE TRIGGER update_relacionamentos_updated_at
      BEFORE UPDATE ON public.relacionamentos_familiares
      FOR EACH ROW
      EXECUTE FUNCTION public.set_updated_at();
    END IF;
  END IF;
END
$$;