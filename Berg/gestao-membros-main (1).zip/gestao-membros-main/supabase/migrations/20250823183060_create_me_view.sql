-- Criar a view 'me' que retorna as informações do usuário autenticado
CREATE OR REPLACE VIEW me AS
SELECT
  u.email,
  u.permissao,
  u.idmembro
FROM
  usuarios u
WHERE
  u.auth_uid = auth.uid();

-- Adicionar comentário à view
COMMENT ON VIEW me IS 'View que retorna as informações do usuário autenticado';