-- Corrigir funções existentes com search_path
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
begin
  new.updated_at = now();
  return new;
end; 
$function$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios')
  AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='lideres') THEN
    CREATE OR REPLACE FUNCTION public.is_current_user_lider_do_depto(depto text)
    RETURNS boolean
    LANGUAGE sql
    STABLE
    SET search_path = public
    AS $function$
      select exists (
        select 1
        from public.usuarios u
        join public.lideres li on li.idmembro = u.idmembro and li.status = 'Ativo'
        where u.auth_uid = auth.uid() and li.iddepto = depto
      );
    $function$;
  END IF;
END
$$;