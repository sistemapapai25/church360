-- Alterar o campo cidade na tabela membros para aceitar apenas texto simples
-- Remove qualquer relacionamento com a tabela cidade

-- Primeiro, garantir que não há constraint de foreign key
ALTER TABLE public.membros DROP CONSTRAINT IF EXISTS membros_cidade_fkey;

-- Alterar o tipo da coluna para VARCHAR se ainda não for
-- (caso seja uma referência para ID, vamos garantir que seja texto)
ALTER TABLE public.membros 
ALTER COLUMN cidade TYPE VARCHAR(100);

-- Atualizar o comentário da coluna
COMMENT ON COLUMN public.membros.cidade IS 'Nome da cidade (texto simples, sem relacionamento com tabela cidade)';

-- Opcional: Limpar dados que possam ser IDs da tabela cidade
-- Atualizar registros que tenham IDs (formato MUN###) para NULL
-- para que possam ser preenchidos novamente via CEP
UPDATE public.membros 
SET cidade = NULL 
WHERE cidade ~ '^MUN[0-9]+$';