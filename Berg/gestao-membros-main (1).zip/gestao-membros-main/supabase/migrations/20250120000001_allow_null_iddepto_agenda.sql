-- Permitir que a coluna iddepto da tabela agenda seja NULL para preservar histórico
-- Isso permite desvincular eventos de departamentos excluídos sem perder o histórico

DO $$
BEGIN
  -- Verificar se a tabela agenda existe
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'agenda'
  ) THEN
    
    -- Alterar a coluna iddepto para permitir NULL
    ALTER TABLE public.agenda 
    ALTER COLUMN iddepto DROP NOT NULL;
    
    -- Adicionar comentário explicativo
    COMMENT ON COLUMN public.agenda.iddepto IS 'ID do departamento responsável pelo evento. Pode ser NULL quando o departamento foi excluído mas o evento deve ser preservado no histórico.';
    
  END IF;
END
$$;