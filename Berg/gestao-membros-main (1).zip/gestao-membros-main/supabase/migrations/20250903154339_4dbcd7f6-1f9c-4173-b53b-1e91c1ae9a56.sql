-- Habilitar RLS na tabela usuarios
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Política para permitir que usuários vejam seu próprio registro
CREATE POLICY "Usuários podem ver seu próprio perfil" 
ON usuarios 
FOR SELECT 
USING (auth.uid() = auth_uid);

-- Política para permitir que usuários atualizem seu próprio perfil (se necessário)
CREATE POLICY "Usuários podem atualizar seu próprio perfil" 
ON usuarios 
FOR UPDATE 
USING (auth.uid() = auth_uid);

-- Habilitar RLS na tabela membros também (caso precise acessar os dados dos membros)
ALTER TABLE membros ENABLE ROW LEVEL SECURITY;

-- Política para permitir que usuários vejam dados de membros (necessário para buscar nome/apelido)
CREATE POLICY "Usuários podem ver dados de membros" 
ON membros 
FOR SELECT 
USING (true); -- Permite leitura para todos os usuários autenticados