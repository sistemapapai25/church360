-- Habilitar RLS em todas as tabelas que não têm (com proteção IF EXISTS)
DO $$
BEGIN
  -- departamentos
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='departamentos') THEN
    ALTER TABLE public.departamentos ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'departamentos' AND policyname = 'departamentos_select_all') THEN
      CREATE POLICY "departamentos_select_all" ON public.departamentos FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;

  -- eventos_igreja
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='eventos_igreja') THEN
    ALTER TABLE public.eventos_igreja ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'eventos_igreja' AND policyname = 'eventos_igreja_select_all') THEN
      CREATE POLICY "eventos_igreja_select_all" ON public.eventos_igreja FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;

  -- locais
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='locais') THEN
    ALTER TABLE public.locais ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'locais' AND policyname = 'locais_select_all') THEN
      CREATE POLICY "locais_select_all" ON public.locais FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;

  -- membros
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    ALTER TABLE public.membros ENABLE ROW LEVEL SECURITY;
  END IF;

  -- permissoes
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='permissoes') THEN
    ALTER TABLE public.permissoes ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'permissoes' AND policyname = 'permissoes_select_all') THEN
      CREATE POLICY "permissoes_select_all" ON public.permissoes FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;

  -- status_agenda
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='status_agenda') THEN
    ALTER TABLE public.status_agenda ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'status_agenda' AND policyname = 'status_agenda_select_all') THEN
      CREATE POLICY "status_agenda_select_all" ON public.status_agenda FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;

  -- tipos_membro
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='tipos_membro') THEN
    ALTER TABLE public.tipos_membro ENABLE ROW LEVEL SECURITY;
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'tipos_membro' AND policyname = 'tipos_membro_select_all') THEN
      CREATE POLICY "tipos_membro_select_all" ON public.tipos_membro FOR SELECT USING (auth.role() = 'authenticated');
    END IF;
  END IF;
END
$$;

-- Política para membros (administradores podem tudo, outros só leem)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'membros' AND policyname = 'membros_select_all') THEN
      CREATE POLICY "membros_select_all" ON public.membros FOR SELECT USING (auth.role() = 'authenticated');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'membros' AND policyname = 'membros_admin_write') THEN
      CREATE POLICY "membros_admin_write" ON public.membros FOR ALL
      USING (EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE')))
      WITH CHECK (EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE')));
    END IF;
  END IF;
END
$$;

-- Corrigir funções com search_path
CREATE OR REPLACE FUNCTION public.create_user_with_profile(
  p_email text,
  p_password text,
  p_idmembro text DEFAULT NULL,
  p_permissao text DEFAULT 'USR'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_user_id uuid;
  new_idusuario text;
  result json;
BEGIN
  -- Apenas ADM pode criar usuários
  IF NOT EXISTS (
    SELECT 1 FROM me WHERE permissao = 'ADM'
  ) THEN
    RAISE EXCEPTION 'Apenas administradores podem criar usuários';
  END IF;

  -- Verificar se email já existe
  IF EXISTS (SELECT 1 FROM usuarios WHERE email = p_email) THEN
    RAISE EXCEPTION 'Email já cadastrado no sistema';
  END IF;

  -- Criar usuário no Supabase Auth (via admin)
  SELECT auth.create_user(
    json_build_object(
      'email', p_email,
      'password', p_password,
      'email_confirm', true
    )
  )::json->>'id' INTO new_user_id;

  IF new_user_id IS NULL THEN
    RAISE EXCEPTION 'Erro ao criar usuário na autenticação';
  END IF;

  -- Gerar novo idusuario
  SELECT 'USR' || LPAD((COALESCE(MAX(SUBSTRING(idusuario, 4)::int), 0) + 1)::text, 6, '0')
  INTO new_idusuario
  FROM usuarios
  WHERE idusuario ~ '^USR[0-9]{6}$';

  -- Inserir na tabela usuarios
  INSERT INTO usuarios (idusuario, email, idmembro, permissao, auth_uid)
  VALUES (new_idusuario, p_email, p_idmembro, p_permissao, new_user_id);

  -- Retornar resultado
  SELECT json_build_object(
    'success', true,
    'user_id', new_user_id,
    'idusuario', new_idusuario,
    'email', p_email,
    'permissao', p_permissao
  ) INTO result;

  RETURN result;

EXCEPTION
  WHEN OTHERS THEN
    -- Em caso de erro, tentar limpar o usuário criado
    BEGIN
      PERFORM auth.delete_user(new_user_id);
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
    
    RAISE EXCEPTION 'Erro ao criar usuário: %', SQLERRM;
END;
$$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios')
  AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    CREATE OR REPLACE FUNCTION public.list_users()
    RETURNS TABLE (
      idusuario text,
      email text,
      idmembro text,
      permissao text,
      auth_uid uuid,
      nome_membro text,
      created_at timestamptz
    )
    LANGUAGE sql
    SECURITY DEFINER
    SET search_path = public
    AS $fn$
      SELECT 
        u.idusuario,
        u.email,
        u.idmembro,
        u.permissao,
        u.auth_uid,
        COALESCE(m.nome, 'Sem membro vinculado') as nome_membro,
        auth.users.created_at
      FROM usuarios u
      LEFT JOIN membros m ON u.idmembro = m.idmembro
      LEFT JOIN auth.users ON u.auth_uid = auth.users.id
      WHERE EXISTS (
        SELECT 1 FROM me WHERE permissao = 'ADM'
      )
      ORDER BY auth.users.created_at DESC;
    $fn$;
  END IF;
END
$$;