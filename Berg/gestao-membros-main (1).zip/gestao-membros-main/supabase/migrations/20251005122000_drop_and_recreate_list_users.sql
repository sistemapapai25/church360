-- Corrigir erro 42P13 ao atualizar a assinatura de retorno da função
-- Precisamos remover a função antiga antes de recriar com novos OUT params

-- 1) Drop da função existente (sem parâmetros)
DROP FUNCTION IF EXISTS public.list_users();

-- 2) Recriação da função com retorno esperado e restrição somente ADM
CREATE OR REPLACE FUNCTION public.list_users()
RETURNS TABLE (
  idusuario text,
  email text,
  idmembro text,
  permissao text,
  auth_uid uuid,
  nome_membro text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT 
    u.idusuario::text,
    u.email,
    u.idmembro::text,
    u.permissao,
    u.auth_uid,
    COALESCE(m.nome, 'Sem membro vinculado') AS nome_membro,
    u.created_at
  FROM public.usuarios u
  LEFT JOIN public.membros m ON u.idmembro = m.idmembro
  WHERE EXISTS (
    SELECT 1 FROM me WHERE permissao = 'ADM'
  )
  ORDER BY u.created_at DESC NULLS LAST;
$fn$;