-- Corrigir função reset_user_password com search_path seguro
CREATE OR REPLACE FUNCTION public.reset_user_password(p_user_id uuid, p_new_password text DEFAULT '123456'::text)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
DECLARE
  result JSON;
BEGIN
  -- Only ADM can reset passwords
  IF NOT EXISTS (
    SELECT 1 FROM public.usuarios WHERE auth_uid = auth.uid() AND permissao = 'ADM'
  ) THEN
    RAISE EXCEPTION 'Apenas administradores podem resetar senhas';
  END IF;

  -- Update user password using Supabase auth
  UPDATE auth.users 
  SET encrypted_password = extensions.crypt(p_new_password, extensions.gen_salt('bf')),
      updated_at = now()
  WHERE id = p_user_id;
  
  -- Check if update was successful
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Usuário não encontrado';
  END IF;
  
  result := json_build_object(
    'success', true, 
    'message', 'Senha resetada com sucesso',
    'new_password', p_new_password
  );
  RETURN result;
EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Erro ao resetar senha: %', SQLERRM;
END;
$function$;