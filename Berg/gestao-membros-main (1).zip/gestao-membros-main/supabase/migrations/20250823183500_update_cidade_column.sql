-- Remover a restrição de chave estrangeira da coluna cidade
ALTER TABLE public.membros DROP CONSTRAINT IF EXISTS membros_cidade_fkey;

-- Atualizar o comentário da coluna para refletir que agora aceita texto
COMMENT ON COLUMN public.membros.cidade IS 'ID da tabela cidade ou nome da cidade quando não encontrada na tabela';