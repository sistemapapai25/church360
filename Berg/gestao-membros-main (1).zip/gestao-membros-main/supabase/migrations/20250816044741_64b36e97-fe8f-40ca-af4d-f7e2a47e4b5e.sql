-- Adicionar campo credencial à tabela membros se ela existir
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='membros' AND column_name='credencial') THEN
      ALTER TABLE public.membros 
      ADD COLUMN credencial DATE;
    END IF;
  END IF;
END
$$;