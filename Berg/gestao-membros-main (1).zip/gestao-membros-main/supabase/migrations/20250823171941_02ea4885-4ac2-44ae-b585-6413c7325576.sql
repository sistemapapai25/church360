-- Remove overly permissive policies that allow all authenticated users to read user data
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Remove overly permissive policies
    DROP POLICY IF EXISTS "usuarios_read_all_authenticated" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_read_authenticated" ON public.usuarios;

    -- Add policy to allow only administrators to read all user records
    DROP POLICY IF EXISTS "usuarios_select_admin_only" ON public.usuarios;
    CREATE POLICY "usuarios_select_admin_only" 
    ON public.usuarios 
    FOR SELECT 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u 
        WHERE u.auth_uid = auth.uid() AND u.permissao = 'ADM'
      )
    );
  END IF;
END
$$;

-- The existing policy "usuarios_select_by_auth_uid" remains to allow users to read their own record