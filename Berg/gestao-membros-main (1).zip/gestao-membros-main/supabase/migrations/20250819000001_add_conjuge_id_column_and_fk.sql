-- Drop existing conjuge_id column and constraints if they exist
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    -- Drop existing foreign key constraint if it exists
    IF EXISTS (
      SELECT 1 
      FROM information_schema.table_constraints tc 
      JOIN information_schema.key_column_usage kcu 
      ON tc.constraint_name = kcu.constraint_name 
      WHERE tc.table_schema = 'public' 
      AND tc.table_name = 'membros' 
      AND kcu.column_name = 'conjuge_id'
      AND tc.constraint_type = 'FOREIGN KEY'
    ) THEN
      ALTER TABLE public.membros DROP CONSTRAINT IF EXISTS fk_membros_conjuge;
    END IF;

    -- Drop existing index if it exists
    DROP INDEX IF EXISTS idx_membros_conjuge;

    -- Drop the column if it exists
    ALTER TABLE public.membros DROP COLUMN IF EXISTS conjuge_id;

    -- Add the column fresh
    ALTER TABLE public.membros ADD COLUMN conjuge_id TEXT;

    -- Add the foreign key constraint
    ALTER TABLE public.membros
    ADD CONSTRAINT fk_membros_conjuge
    FOREIGN KEY (conjuge_id)
    REFERENCES public.membros(idmembro)
    ON DELETE SET NULL;

    -- Create index for better performance
    CREATE INDEX idx_membros_conjuge ON public.membros(conjuge_id);
  END IF;
END
$$;