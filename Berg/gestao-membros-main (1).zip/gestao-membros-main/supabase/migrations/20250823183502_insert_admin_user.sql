-- Insert initial admin user if not exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM usuarios WHERE email = 'admin@example.com') THEN
        INSERT INTO usuarios (email, permissao)
        VALUES ('admin@example.com', 'ADM');
    END IF;
END
$$;