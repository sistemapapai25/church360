-- Fix infinite recursion in usuarios RLS policies
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Drop the problematic policy that causes recursion
    DROP POLICY IF EXISTS "usuarios_write_admin_only" ON public.usuarios;
    DROP POLICY IF EXISTS "usuarios_write_known_admins" ON public.usuarios;

    -- Create a simple policy that allows authenticated users to read usuarios
    -- This breaks the recursion by not checking the usuarios table within the policy
    CREATE POLICY "usuarios_read_all_authenticated" 
    ON public.usuarios 
    FOR SELECT 
    USING (auth.role() = 'authenticated'::text);
  END IF;
END
$$;