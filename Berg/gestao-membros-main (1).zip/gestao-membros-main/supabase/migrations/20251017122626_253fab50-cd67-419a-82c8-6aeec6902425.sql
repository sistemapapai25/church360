-- Política para permitir que usuários atualizem seu próprio perfil
-- vinculando através da tabela usuarios

-- Primeiro, remove políticas antigas que podem causar conflito
DROP POLICY IF EXISTS "p_membros_own" ON public.membros;

-- Cria política para permitir UPDATE do próprio perfil via tabela usuarios
CREATE POLICY "membros_update_own_via_usuarios"
ON public.membros
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.idmembro = membros.idmembro
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.idmembro = membros.idmembro
  )
);

-- Garantir que a coluna user_id seja sincronizada com auth_uid quando possível
-- para casos futuros
UPDATE public.membros m
SET user_id = u.auth_uid
FROM public.usuarios u
WHERE u.idmembro = m.idmembro
AND m.user_id IS NULL;