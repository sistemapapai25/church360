-- Corrigir a data de nascimento da Larissa Adrielli Alves Silva
UPDATE membros 
SET nascimento = '1996-09-04' 
WHERE nome = 'Larissa Adrielli Alves Silva' AND nascimento = '1996-09-05';