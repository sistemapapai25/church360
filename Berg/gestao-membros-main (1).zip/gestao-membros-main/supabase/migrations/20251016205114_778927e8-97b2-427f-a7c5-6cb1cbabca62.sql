-- Remove a foreign key entre membros e cidade
ALTER TABLE public.membros DROP CONSTRAINT IF EXISTS fk_membros_cidade;

-- Garante que a coluna cidade seja text simples
ALTER TABLE public.membros ALTER COLUMN cidade TYPE text;