-- Create usuarios table if it doesn't exist
CREATE TABLE IF NOT EXISTS usuarios (
    idusuario SERIAL PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    auth_uid UUID REFERENCES auth.users(id),
    permissao TEXT CHECK (permissao IN ('ADM', 'OPE')) NOT NULL
);

-- Add comment to table
COMMENT ON TABLE usuarios IS 'Tabela de usuários do sistema';

-- Add comments to columns
COMMENT ON COLUMN usuarios.idusuario IS 'ID único do usuário';
COMMENT ON COLUMN usuarios.email IS 'Email do usuário';
COMMENT ON COLUMN usuarios.auth_uid IS 'ID do usuário no auth.users';
COMMENT ON COLUMN usuarios.permissao IS 'Permissão do usuário (ADM ou OPE)';

-- Enable RLS
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "usuarios_select_policy" ON usuarios
    FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "usuarios_insert_policy" ON usuarios
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() IN (SELECT auth_uid FROM usuarios WHERE permissao = 'ADM'));

CREATE POLICY "usuarios_update_policy" ON usuarios
    FOR UPDATE
    TO authenticated
    USING (auth.uid() IN (SELECT auth_uid FROM usuarios WHERE permissao = 'ADM'))
    WITH CHECK (auth.uid() IN (SELECT auth_uid FROM usuarios WHERE permissao = 'ADM'));

CREATE POLICY "usuarios_delete_policy" ON usuarios
    FOR DELETE
    TO authenticated
    USING (auth.uid() IN (SELECT auth_uid FROM usuarios WHERE permissao = 'ADM'));