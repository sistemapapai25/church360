-- Ajustar políticas RLS para permitir que usuários gerenciem seus próprios familiares
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='relacionamentos_familiares') THEN
    -- Remover políticas antigas para evitar conflitos
    DROP POLICY IF EXISTS "relacionamentos_insert_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_update_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_delete_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_select_authenticated" ON public.relacionamentos_familiares;

    -- Visualização: permitir para todos autenticados
    CREATE POLICY "relacionamentos_select_authenticated"
    ON public.relacionamentos_familiares
    FOR SELECT
    USING (auth.role() = 'authenticated');

    -- Inserção: permitir quando o relacionamento pertence ao próprio membro logado
    CREATE POLICY "relacionamentos_insert_self"
    ON public.relacionamentos_familiares
    FOR INSERT
    WITH CHECK (
      auth.role() = 'authenticated'
      AND EXISTS (SELECT 1 FROM me)
      AND membro_id = (SELECT idmembro FROM me)
    );

    -- Atualização: permitir quando o usuário é o dono (membro_id)
    CREATE POLICY "relacionamentos_update_self"
    ON public.relacionamentos_familiares
    FOR UPDATE
    USING (
      auth.role() = 'authenticated'
      AND EXISTS (SELECT 1 FROM me)
      AND membro_id = (SELECT idmembro FROM me)
    )
    WITH CHECK (
      auth.role() = 'authenticated'
      AND EXISTS (SELECT 1 FROM me)
      AND membro_id = (SELECT idmembro FROM me)
    );

    -- Exclusão: permitir quando o usuário é o membro ou o parente envolvido
    CREATE POLICY "relacionamentos_delete_self"
    ON public.relacionamentos_familiares
    FOR DELETE
    USING (
      auth.role() = 'authenticated'
      AND EXISTS (SELECT 1 FROM me)
      AND (
        membro_id = (SELECT idmembro FROM me)
        OR parente_id = (SELECT idmembro FROM me)
      )
    );
  END IF;
END
$$;