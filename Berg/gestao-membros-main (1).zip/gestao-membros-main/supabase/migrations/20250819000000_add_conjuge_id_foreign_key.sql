-- Add foreign key constraint for conjuge_id in membros table
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='membros') THEN
    -- Add foreign key constraint if it doesn't exist
    IF NOT EXISTS (
      SELECT 1 
      FROM information_schema.table_constraints tc 
      JOIN information_schema.key_column_usage kcu 
      ON tc.constraint_name = kcu.constraint_name 
      WHERE tc.table_schema = 'public' 
      AND tc.table_name = 'membros' 
      AND kcu.column_name = 'conjuge_id'
      AND tc.constraint_type = 'FOREIGN KEY'
    ) THEN
      ALTER TABLE public.membros
      ADD CONSTRAINT fk_membros_conjuge
      FOREIGN KEY (conjuge_id)
      REFERENCES public.membros(idmembro)
      ON DELETE SET NULL;
    END IF;
  END IF;
END
$$;