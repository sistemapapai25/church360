-- Fix remaining RLS issues - check for any tables missing RLS
-- Based on the linter error, there are still tables without RLS enabled

-- Let's check all tables in public schema and ensure RLS is enabled
-- First, let's see what tables might be missing RLS by checking system catalogs

-- Enable RLS on any remaining tables that might be missing it
-- (this is a safe operation that won't affect tables that already have RLS)

DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN 
        SELECT schemaname, tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        AND tablename NOT IN (
            SELECT tablename 
            FROM pg_tables t
            JOIN pg_class c ON c.relname = t.tablename
            WHERE c.relrowsecurity = true
            AND t.schemaname = 'public'
        )
    LOOP
        -- Enable RLS on tables that don't have it yet
        EXECUTE format('ALTER TABLE %I.%I ENABLE ROW LEVEL SECURITY', r.schemaname, r.tablename);
        RAISE NOTICE 'Enabled RLS on table: %.%', r.schemaname, r.tablename;
    END LOOP;
END
$$;