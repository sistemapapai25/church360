-- Fix the reset password function to work properly
CREATE OR REPLACE FUNCTION public.reset_user_password(
  p_user_id UUID,
  p_new_password TEXT DEFAULT '123456'
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result JSON;
BEGIN
  -- Only ADM can reset passwords
  IF NOT EXISTS (
    SELECT 1 FROM me WHERE permissao = 'ADM'
  ) THEN
    RAISE EXCEPTION 'Apenas administradores podem resetar senhas';
  END IF;

  -- Update user password using Supabase auth admin functions
  -- This approach uses the auth.update_user function which is more secure
  UPDATE auth.users 
  SET encrypted_password = crypt(p_new_password, gen_salt('bf')),
      updated_at = now()
  WHERE id = p_user_id;
  
  -- Check if update was successful
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Usuário não encontrado';
  END IF;
  
  result := json_build_object(
    'success', true, 
    'message', 'Senha resetada com sucesso',
    'new_password', p_new_password
  );
  RETURN result;
EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Erro ao resetar senha: %', SQLERRM;
END;
$$;