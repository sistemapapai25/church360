-- Criar tabela de áreas com relacionamento aos departamentos se a view me existir
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.views WHERE table_schema='public' AND table_name='me') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='areas') THEN
      CREATE TABLE public.areas (
        idarea TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
        nome TEXT NOT NULL,
        descricao TEXT,
        iddepto TEXT NOT NULL,
        status TEXT DEFAULT 'Ativo' CHECK (status IN ('Ativo', 'Inativo')),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
      );

      -- Habilitar RLS
      ALTER TABLE public.areas ENABLE ROW LEVEL SECURITY;

      -- Políticas de RLS para áreas
      CREATE POLICY "areas_select_all" 
      ON public.areas 
      FOR SELECT 
      USING (auth.role() = 'authenticated');

      CREATE POLICY "areas_admin_write" 
      ON public.areas 
      FOR ALL 
      USING (EXISTS (SELECT 1 FROM me WHERE permissao = 'ADM'))
      WITH CHECK (EXISTS (SELECT 1 FROM me WHERE permissao = 'ADM'));

      -- Trigger para atualizar updated_at
      CREATE TRIGGER update_areas_updated_at
        BEFORE UPDATE ON public.areas
        FOR EACH ROW
        EXECUTE FUNCTION public.set_updated_at();

      -- Inserir algumas áreas de exemplo para o departamento Capelania
      INSERT INTO public.areas (idarea, nome, descricao, iddepto) VALUES
      ('b9527cad', 'Hospital São Silvestre - Terça', 'Visita hospitalar às terças-feiras no Hospital São Silvestre', 'c3245218'),
      ('c344da41', 'Hospital São Silvestre - Sexta', 'Visita hospitalar às sextas-feiras no Hospital São Silvestre', 'c3245218'),
      ('824861de', 'Abrigo Dona Norma', 'Atendimento espiritual no Abrigo Dona Norma', 'c3245218'),
      ('ad24c9fe', 'Presídio Cepaigo', 'Ministração espiritual no Presídio Cepaigo', 'c3245218');

      -- Inserir áreas para outros departamentos como exemplo
      INSERT INTO public.areas (idarea, nome, descricao, iddepto) VALUES
      ('b7346492', 'Louvor Domingo Manhã', 'Ministério de louvor do culto de domingo manhã', '33b4a9a3'),
      ('5aee6443', 'Louvor Domingo Noite', 'Ministério de louvor do culto de domingo noite', '33b4a9a3'),
      ('4ebd3162', 'Ensaios e Treinamento', 'Área responsável pelos ensaios e treinamento dos músicos', '33b4a9a3');
    END IF;
  END IF;
END
$$;