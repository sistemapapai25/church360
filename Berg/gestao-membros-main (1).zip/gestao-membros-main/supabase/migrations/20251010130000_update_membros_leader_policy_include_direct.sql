-- Atualiza a política de leitura de membros para incluir liderança direta em departamentos
-- Contexto: líderes definidos em departamentos (liderdepto1/liderdepto2) não conseguiam ver membros
-- de seus departamentos no Relatório de Dons, pois a política considerava apenas a tabela 'lideres'.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'membros'
  ) THEN
    -- Remove a política existente para recriá-la com a condição ampliada
    DROP POLICY IF EXISTS "membros_select_leader_basic" ON public.membros;

    -- Nova política: líderes conseguem ver membros do departamento quando:
    -- 1) Há um vínculo ativo na tabela 'lideres' para o mesmo departamento; OU
    -- 2) O usuário é líder direto do departamento via 'departamentos.liderdepto1' ou 'departamentos.liderdepto2'.
    CREATE POLICY "membros_select_leader_basic"
    ON public.membros
    FOR SELECT
    USING (
      -- Caso 1: liderança ativa registrada em 'lideres'
      EXISTS (
        SELECT 1
        FROM public.lideres l
        JOIN me ON me.idmembro = l.idmembro
        WHERE l.status = 'Ativo'
          AND l.iddepto = membros.iddepto
      )
      OR
      -- Caso 2: liderança direta registrada na tabela 'departamentos'
      EXISTS (
        SELECT 1
        FROM public.departamentos d
        JOIN me ON me.idmembro IN (d.liderdepto1, d.liderdepto2)
        WHERE d.iddepto = membros.iddepto
      )
    );
  END IF;
END
$$;

-- Observação: mantém inalteradas as políticas de "membros_select_own_record" e "membros_select_admin".