DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
      AND tablename = 'departamentos' 
      AND policyname = 'departamentos_update_admin'
  ) THEN
    CREATE POLICY "departamentos_update_admin"
    ON public.departamentos
    FOR UPDATE
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u
        WHERE u.auth_uid = auth.uid() AND u.permissao = 'ADM'
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.usuarios u
        WHERE u.auth_uid = auth.uid() AND u.permissao = 'ADM'
      )
    );
  END IF;
END $$;