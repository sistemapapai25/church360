-- Tornar o campo iddepto opcional na tabela lideres para preservar histórico
-- quando departamentos são excluídos

DO $$
BEGIN
  -- Verificar se a tabela lideres existe
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'lideres'
  ) THEN
    
    -- 1. Remover a constraint existente lideres_iddepto_fkey
    IF EXISTS (
      SELECT 1 FROM information_schema.table_constraints 
      WHERE table_schema = 'public' 
      AND table_name = 'lideres' 
      AND constraint_name = 'lideres_iddepto_fkey'
    ) THEN
      ALTER TABLE public.lideres DROP CONSTRAINT lideres_iddepto_fkey;
      RAISE NOTICE 'Constraint lideres_iddepto_fkey removida';
    END IF;
    
    -- 2. Tornar a coluna iddepto nullable
    ALTER TABLE public.lideres ALTER COLUMN iddepto DROP NOT NULL;
    RAISE NOTICE 'Campo iddepto agora permite valores NULL';
    
    -- 3. Recriar a constraint com ON DELETE SET NULL para preservar histórico
    ALTER TABLE public.lideres
    ADD CONSTRAINT lideres_iddepto_fkey
    FOREIGN KEY (iddepto)
    REFERENCES public.departamentos(iddepto)
    ON DELETE SET NULL;
    
    RAISE NOTICE 'Nova constraint lideres_iddepto_fkey criada com ON DELETE SET NULL';
    
  ELSE
    RAISE NOTICE 'Tabela lideres não encontrada';
  END IF;
END
$$;