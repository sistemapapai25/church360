-- Corrigir políticas RLS para relacionamentos_familiares
-- Esta migração resolve o erro de política de segurança ao inserir relacionamentos

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='relacionamentos_familiares') THEN
    
    -- Remover todas as políticas antigas para evitar conflitos
    DROP POLICY IF EXISTS "relacionamentos_insert_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_update_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_delete_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_select_authenticated" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_select_all" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_insert_self" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_update_self" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_delete_self" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_insert_policy" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_update_policy" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_delete_policy" ON public.relacionamentos_familiares;

    -- Política de SELECT: permitir para todos autenticados
    CREATE POLICY "relacionamentos_select_all"
    ON public.relacionamentos_familiares
    FOR SELECT
    TO authenticated
    USING (true);

    -- Política de INSERT: permitir quando o usuário tem permissão ADM/OPE ou quando é o próprio membro
    CREATE POLICY "relacionamentos_insert_policy"
    ON public.relacionamentos_familiares
    FOR INSERT
    TO authenticated
    WITH CHECK (
      -- Administradores e operadores podem inserir qualquer relacionamento
      EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
      OR
      -- Usuários podem inserir relacionamentos onde eles são o membro principal
      (
        EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
        AND membro_id = (SELECT idmembro FROM me)
      )
    );

    -- Política de UPDATE: permitir quando o usuário tem permissão ADM/OPE ou quando é o próprio membro
    CREATE POLICY "relacionamentos_update_policy"
    ON public.relacionamentos_familiares
    FOR UPDATE
    TO authenticated
    USING (
      -- Administradores e operadores podem atualizar qualquer relacionamento
      EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
      OR
      -- Usuários podem atualizar relacionamentos onde eles são o membro principal
      (
        EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
        AND membro_id = (SELECT idmembro FROM me)
      )
    )
    WITH CHECK (
      -- Administradores e operadores podem atualizar qualquer relacionamento
      EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
      OR
      -- Usuários podem atualizar relacionamentos onde eles são o membro principal
      (
        EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
        AND membro_id = (SELECT idmembro FROM me)
      )
    );

    -- Política de DELETE: permitir quando o usuário tem permissão ADM/OPE ou quando é o membro envolvido
    CREATE POLICY "relacionamentos_delete_policy"
    ON public.relacionamentos_familiares
    FOR DELETE
    TO authenticated
    USING (
      -- Administradores e operadores podem deletar qualquer relacionamento
      EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
      OR
      -- Usuários podem deletar relacionamentos onde eles são o membro principal ou parente
      (
        EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
        AND (
          membro_id = (SELECT idmembro FROM me)
          OR parente_id = (SELECT idmembro FROM me)
        )
      )
    );

  END IF;
END
$$;