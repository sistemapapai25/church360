-- 1. Adicionar campo pertence_capelania na tabela departamentos
ALTER TABLE public.departamentos 
ADD COLUMN IF NOT EXISTS pertence_capelania boolean NOT NULL DEFAULT false;

-- 2. Criar novos departamentos a partir das áreas da Capelania
INSERT INTO public.departamentos (iddepto, nome, pertence_capelania, liderdepto1, liderdepto2)
SELECT 
  a.idarea as iddepto,
  a.nome,
  true as pertence_capelania,
  a.lider1 as liderdepto1,
  a.lider2 as liderdepto2
FROM public.areas a
WHERE a.iddepto IN (
  SELECT iddepto FROM public.departamentos WHERE LOWER(nome) LIKE '%capelania%'
)
AND a.status = 'Ativo'
AND NOT EXISTS (
  SELECT 1 FROM public.departamentos d WHERE d.iddepto = a.idarea
)
ON CONFLICT (iddepto) DO NOTHING;

-- 3. Atualizar tabela lideres: converter líderes de áreas para departamentos
UPDATE public.lideres
SET iddepto = idarea,
    idarea = NULL
WHERE iddepto IN (
  SELECT iddepto FROM public.departamentos WHERE LOWER(nome) LIKE '%capelania%'
)
AND idarea IS NOT NULL
AND EXISTS (
  SELECT 1 FROM public.departamentos WHERE iddepto = lideres.idarea
);

-- 4. Atualizar membros para os novos departamentos
UPDATE public.membros m
SET iddepto = l.iddepto
FROM public.lideres l
WHERE l.idmembro = m.idmembro 
AND l.status = 'Ativo'
AND EXISTS (
  SELECT 1 FROM public.departamentos d 
  WHERE d.iddepto = l.iddepto 
  AND d.pertence_capelania = true
);

-- 5. Atualizar agenda para os novos departamentos
UPDATE public.agenda a
SET iddepto = l.iddepto
FROM public.lideres l
WHERE l.idlider = a.idlider
AND l.status = 'Ativo'
AND EXISTS (
  SELECT 1 FROM public.departamentos d 
  WHERE d.iddepto = l.iddepto 
  AND d.pertence_capelania = true
);

-- 6. Comentar sobre o novo campo
COMMENT ON COLUMN departamentos.pertence_capelania IS 'Indica se o departamento pertence à estrutura da Capelania (antigas áreas convertidas em departamentos)';

-- 7. Marcar áreas migradas como inativas (usando valor válido)
UPDATE public.areas
SET status = 'Inativo',
    descricao = COALESCE(descricao || ' - ', '') || 'Convertido para departamento'
WHERE iddepto IN (
  SELECT iddepto FROM public.departamentos WHERE LOWER(nome) LIKE '%capelania%'
)
AND status = 'Ativo';