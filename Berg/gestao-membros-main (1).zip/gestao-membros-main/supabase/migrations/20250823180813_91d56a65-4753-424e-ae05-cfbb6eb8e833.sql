-- Verificar e atualizar os auth_uid dos usuários
DO $$
DECLARE
  usuarios_sem_auth RECORD;
  auth_user_id uuid;
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    -- Verificar todos os usuários que têm auth_uid NULL
    FOR usuarios_sem_auth IN
      SELECT idusuario, email FROM usuarios WHERE auth_uid IS NULL
    LOOP
      -- Buscar o auth_uid correspondente na tabela auth.users
      SELECT id INTO auth_user_id
      FROM auth.users
      WHERE email = usuarios_sem_auth.email
      LIMIT 1;

      -- Atualizar o auth_uid se encontrado
      IF auth_user_id IS NOT NULL THEN
        UPDATE usuarios
        SET auth_uid = auth_user_id
        WHERE idusuario = usuarios_sem_auth.idusuario;
      END IF;
    END LOOP;
  END IF;
END
$$;