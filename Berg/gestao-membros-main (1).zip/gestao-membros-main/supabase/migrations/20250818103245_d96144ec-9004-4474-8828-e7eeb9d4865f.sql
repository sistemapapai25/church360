-- Recriar a view 'me' para garantir que funcione corretamente se a tabela usuarios existir
DO $$
BEGIN
  DROP VIEW IF EXISTS me;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='usuarios') THEN
    CREATE VIEW me AS
    SELECT 
        u.idusuario,
        u.email,
        u.permissao,
        u.idmembro,
        u.auth_uid
    FROM usuarios u
    WHERE u.auth_uid = auth.uid();
  END IF;
END
$$;