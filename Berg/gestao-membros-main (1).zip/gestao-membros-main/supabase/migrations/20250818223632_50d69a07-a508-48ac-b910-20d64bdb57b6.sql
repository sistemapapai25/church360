DO $$
BEGIN
  -- CRITICAL SECURITY FIX: Restrict access to sensitive member personal data
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'membros') THEN
    -- Remove the overly permissive policy that allows all authenticated users to read all member data
    DROP POLICY IF EXISTS "membros_select_all" ON public.membros;

    -- Create secure, restrictive policies for member data access

    -- Policy 1: Users can only view their own member record
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'membros' AND policyname = 'membros_select_own_record') THEN
      CREATE POLICY "membros_select_own_record" 
      ON public.membros 
      FOR SELECT 
      USING (
        EXISTS (
          SELECT 1 FROM public.usuarios u 
          WHERE u.auth_uid = auth.uid() 
          AND u.idmembro = membros.idmembro
        )
      );
    END IF;

    -- Policy 2: Admins can view all member records (for management purposes)
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'membros' AND policyname = 'membros_select_admin') THEN
      CREATE POLICY "membros_select_admin" 
      ON public.membros 
      FOR SELECT 
      USING (
        EXISTS (
          SELECT 1 FROM me 
          WHERE me.permissao = 'ADM'
        )
      );
    END IF;

    -- Policy 3: Leaders can view basic info (name only) of members in their department
    -- This is for legitimate business needs like agenda management and relationships
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'membros' AND policyname = 'membros_select_leader_basic') THEN
      CREATE POLICY "membros_select_leader_basic" 
      ON public.membros 
      FOR SELECT 
      USING (
        EXISTS (
          SELECT 1 FROM public.lideres l
          JOIN public.usuarios u ON u.idmembro = l.idmembro
          WHERE u.auth_uid = auth.uid() 
          AND l.status = 'Ativo'
          AND l.iddepto = membros.iddepto
        )
      );
    END IF;
  END IF;
END
$$;

-- Note: The above policies ensure that:
-- 1. Regular users can only see their own member data
-- 2. Admins can see all member data for management
-- 3. Leaders can see members in their department (for legitimate business needs)
-- This prevents unauthorized access to sensitive personal information