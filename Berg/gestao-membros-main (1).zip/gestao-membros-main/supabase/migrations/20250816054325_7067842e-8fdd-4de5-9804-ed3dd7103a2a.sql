-- Migrar fotos do bucket antigo para o novo
DO $$
DECLARE 
    obj record;
    old_name text;
    new_name text;
BEGIN
    -- Para cada objeto no bucket fotos_membros, copiar para member-photos
    FOR obj IN 
        SELECT name FROM storage.objects WHERE bucket_id = 'fotos_membros'
    LOOP
        old_name := obj.name;
        
        -- Remove o prefixo Membros_Images/ se existir
        IF old_name LIKE 'Membros_Images/%' THEN
            new_name := substring(old_name from 16); -- Remove 'Membros_Images/'
        ELSE
            new_name := old_name;
        END IF;
        
        -- Inserir referência no bucket member-photos (apenas metadados)
        INSERT INTO storage.objects (
            bucket_id, 
            name, 
            owner,
            created_at,
            updated_at,
            last_accessed_at,
            metadata
        )
        SELECT 
            'member-photos' as bucket_id,
            new_name as name,
            owner,
            created_at,
            updated_at,
            last_accessed_at,
            metadata
        FROM storage.objects 
        WHERE bucket_id = 'fotos_membros' AND name = old_name
        ON CONFLICT (bucket_id, name) DO NOTHING;
    END LOOP;
END $$;