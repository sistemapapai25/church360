-- Create function to update user information
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'usuarios'
  ) THEN
    CREATE OR REPLACE FUNCTION public.update_user_info(
      p_idusuario text,
      p_email text DEFAULT NULL,
      p_permissao text DEFAULT NULL
    )
    RETURNS json
    LANGUAGE plpgsql
    SECURITY DEFINER
    SET search_path TO 'public'
    AS $function$
    DECLARE
      current_user_record usuarios%ROWTYPE;
      result json;
    BEGIN
      -- Only ADM can update user information
      IF NOT EXISTS (
        SELECT 1 FROM public.usuarios WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      ) THEN
        RAISE EXCEPTION 'Apenas administradores podem atualizar informações de usuários';
      END IF;

      -- Get current user record
      SELECT * INTO current_user_record FROM usuarios WHERE idusuario = p_idusuario;
      
      IF NOT FOUND THEN
        RAISE EXCEPTION 'Usuário não encontrado';
      END IF;

      -- Update email in auth.users if provided
      IF p_email IS NOT NULL AND p_email != current_user_record.email THEN
        -- Check if email already exists
        IF EXISTS (SELECT 1 FROM auth.users WHERE email = p_email AND id != current_user_record.auth_uid) THEN
          RAISE EXCEPTION 'Este email já está em uso por outro usuário';
        END IF;
        
        -- Update in auth.users
        UPDATE auth.users 
        SET email = p_email, 
            updated_at = now()
        WHERE id = current_user_record.auth_uid;
        
        -- Update in usuarios table
        UPDATE usuarios 
        SET email = p_email 
        WHERE idusuario = p_idusuario;
      END IF;

      -- Update permission if provided
      IF p_permissao IS NOT NULL AND p_permissao != current_user_record.permissao THEN
        UPDATE usuarios 
        SET permissao = p_permissao 
        WHERE idusuario = p_idusuario;
      END IF;
      
      result := json_build_object(
        'success', true, 
        'message', 'Informações do usuário atualizadas com sucesso'
      );
      RETURN result;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE EXCEPTION 'Erro ao atualizar usuário: %', SQLERRM;
    END;
    $function$;
  END IF;
END
$$;