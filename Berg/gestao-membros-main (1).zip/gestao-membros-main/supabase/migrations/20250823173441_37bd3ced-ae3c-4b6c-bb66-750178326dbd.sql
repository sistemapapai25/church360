-- Drop existing restrictive policies for relacionamentos_familiares
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'relacionamentos_familiares'
  ) THEN
    DROP POLICY IF EXISTS "relacionamentos_select_all" ON public.relacionamentos_familiares;
  END IF;
END
$$;