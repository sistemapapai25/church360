-- Habilitar RLS para tabelas críticas que podem estar causando o problema
ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.membros ENABLE ROW LEVEL SECURITY;

-- Verificar se há função is_current_user_admin que pode estar faltando
CREATE OR REPLACE FUNCTION public.is_current_user_admin()
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM usuarios 
    WHERE auth_uid = auth.uid() 
    AND permissao = 'ADM'
  );
$$;