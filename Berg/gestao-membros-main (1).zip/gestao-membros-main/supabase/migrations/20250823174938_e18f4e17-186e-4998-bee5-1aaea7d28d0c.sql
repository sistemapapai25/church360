-- Create comprehensive policies for family relationships
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name IN ('relacionamentos_familiares', 'usuarios')
  ) THEN
    -- Drop existing policies first
    DROP POLICY IF EXISTS "relacionamentos_select_authenticated" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_insert_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_update_admin" ON public.relacionamentos_familiares;
    DROP POLICY IF EXISTS "relacionamentos_delete_admin" ON public.relacionamentos_familiares;

    -- Create new policies
    CREATE POLICY "relacionamentos_select_authenticated" 
    ON public.relacionamentos_familiares 
    FOR SELECT 
    USING (auth.role() = 'authenticated');

    CREATE POLICY "relacionamentos_insert_admin" 
    ON public.relacionamentos_familiares 
    FOR INSERT 
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );

    CREATE POLICY "relacionamentos_update_admin" 
    ON public.relacionamentos_familiares 
    FOR UPDATE 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );

    CREATE POLICY "relacionamentos_delete_admin" 
    ON public.relacionamentos_familiares 
    FOR DELETE 
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios 
        WHERE auth_uid = auth.uid() AND permissao = 'ADM'
      )
    );
  END IF;
END
$$;