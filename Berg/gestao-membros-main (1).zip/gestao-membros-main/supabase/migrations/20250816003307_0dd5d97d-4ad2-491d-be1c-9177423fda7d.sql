-- Criar função para criar usuário completo
CREATE OR REPLACE FUNCTION public.create_user_with_profile(
  p_email text,
  p_password text,
  p_idmembro text DEFAULT NULL,
  p_permissao text DEFAULT 'USR'
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id uuid;
  new_idusuario text;
  result json;
BEGIN
  -- Apenas ADM pode criar usuários
  IF NOT EXISTS (
    SELECT 1 FROM me WHERE permissao = 'ADM'
  ) THEN
    RAISE EXCEPTION 'Apenas administradores podem criar usuários';
  END IF;

  -- Verificar se email já existe
  IF EXISTS (SELECT 1 FROM usuarios WHERE email = p_email) THEN
    RAISE EXCEPTION 'Email já cadastrado no sistema';
  END IF;

  -- Criar usuário no Supabase Auth (via admin)
  SELECT auth.create_user(
    json_build_object(
      'email', p_email,
      'password', p_password,
      'email_confirm', true
    )
  )::json->>'id' INTO new_user_id;

  IF new_user_id IS NULL THEN
    RAISE EXCEPTION 'Erro ao criar usuário na autenticação';
  END IF;

  -- Gerar novo idusuario
  SELECT 'USR' || LPAD((COALESCE(MAX(SUBSTRING(idusuario, 4)::int), 0) + 1)::text, 6, '0')
  INTO new_idusuario
  FROM usuarios
  WHERE idusuario ~ '^USR[0-9]{6}$';

  -- Inserir na tabela usuarios
  INSERT INTO usuarios (idusuario, email, idmembro, permissao, auth_uid)
  VALUES (new_idusuario, p_email, p_idmembro, p_permissao, new_user_id);

  -- Retornar resultado
  SELECT json_build_object(
    'success', true,
    'user_id', new_user_id,
    'idusuario', new_idusuario,
    'email', p_email,
    'permissao', p_permissao
  ) INTO result;

  RETURN result;

EXCEPTION
  WHEN OTHERS THEN
    -- Em caso de erro, tentar limpar o usuário criado
    BEGIN
      PERFORM auth.delete_user(new_user_id);
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
    
    RAISE EXCEPTION 'Erro ao criar usuário: %', SQLERRM;
END;
$$;

-- Função para listar usuários (apenas para ADM) — protegida por IF EXISTS
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema='public' AND table_name='usuarios'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema='public' AND table_name='membros'
  ) THEN
    CREATE OR REPLACE FUNCTION public.list_users()
    RETURNS TABLE (
      idusuario text,
      email text,
      idmembro text,
      permissao text,
      auth_uid uuid,
      nome_membro text,
      created_at timestamptz
    )
    LANGUAGE sql
    SECURITY DEFINER
    AS $fn$
      SELECT
        u.idusuario,
        u.email,
        u.idmembro,
        u.permissao,
        u.auth_uid,
        COALESCE(m.nome, 'Sem membro vinculado') AS nome_membro,
        auth.users.created_at
      FROM public.usuarios u
      LEFT JOIN public.membros m ON m.idmembro = u.idmembro
      LEFT JOIN auth.users ON u.auth_uid = auth.users.id
      WHERE EXISTS (
        SELECT 1 FROM me WHERE permissao = 'ADM'
      )
      ORDER BY auth.users.created_at DESC;
    $fn$;
  END IF;
END
$$;