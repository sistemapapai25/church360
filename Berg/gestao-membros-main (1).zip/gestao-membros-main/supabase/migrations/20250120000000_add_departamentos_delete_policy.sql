-- Adicionar política DELETE para departamentos
-- Permite que administradores excluam departamentos

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
      AND tablename = 'departamentos' 
      AND policyname = 'departamentos_delete_admin'
  ) THEN
    CREATE POLICY "departamentos_delete_admin"
    ON public.departamentos
    FOR DELETE
    USING (
      EXISTS (
        SELECT 1 FROM public.usuarios u
        WHERE u.auth_uid = auth.uid() AND u.permissao = 'ADM'
      )
    );
  END IF;
END $$;