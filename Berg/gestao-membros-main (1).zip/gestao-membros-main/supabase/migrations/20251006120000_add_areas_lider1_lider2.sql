-- Adiciona as colunas lider1 e lider2 na tabela areas com FKs para membros
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_schema='public' AND table_name='areas'
  ) THEN

    -- Adiciona colunas se não existirem
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_schema='public' AND table_name='areas' AND column_name='lider1'
    ) THEN
      ALTER TABLE public.areas ADD COLUMN lider1 TEXT;
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_schema='public' AND table_name='areas' AND column_name='lider2'
    ) THEN
      ALTER TABLE public.areas ADD COLUMN lider2 TEXT;
    END IF;

    -- Adiciona constraints de chave estrangeira se não existirem
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints 
      WHERE table_schema='public' AND table_name='areas' AND constraint_name='fk_areas_lider1'
    ) THEN
      ALTER TABLE public.areas
        ADD CONSTRAINT fk_areas_lider1
        FOREIGN KEY (lider1)
        REFERENCES public.membros(idmembro)
        ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints 
      WHERE table_schema='public' AND table_name='areas' AND constraint_name='fk_areas_lider2'
    ) THEN
      ALTER TABLE public.areas
        ADD CONSTRAINT fk_areas_lider2
        FOREIGN KEY (lider2)
        REFERENCES public.membros(idmembro)
        ON DELETE SET NULL;
    END IF;

    -- Índices para melhorar consultas por lider1/lider2
    IF NOT EXISTS (
      SELECT 1 FROM pg_indexes WHERE schemaname='public' AND tablename='areas' AND indexname='idx_areas_lider1'
    ) THEN
      CREATE INDEX idx_areas_lider1 ON public.areas(lider1);
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM pg_indexes WHERE schemaname='public' AND tablename='areas' AND indexname='idx_areas_lider2'
    ) THEN
      CREATE INDEX idx_areas_lider2 ON public.areas(lider2);
    END IF;

  END IF;
END
$$;