-- Script para investigar problema específico de Ramon e Clarissa
-- Execute no Supabase SQL Editor

-- 1. Buscar dados do Ramon
SELECT 'Dados do Ramon:' as info;
SELECT 
  m.idmembro,
  m.nome,
  m.conjuge_id,
  u.email,
  u.permissao
FROM membros m
LEFT JOIN usuarios u ON u.idmembro = m.idmembro
WHERE u.email = 'ramon.naciff@gmail.com' OR m.nome ILIKE '%ramon%naciff%';

-- 2. Buscar dados da Clarissa
SELECT 'Dados da Clarissa:' as info;
SELECT 
  m.idmembro,
  m.nome,
  m.conjuge_id,
  u.email,
  u.permissao
FROM membros m
LEFT JOIN usuarios u ON u.idmembro = m.idmembro
WHERE u.email = 'clarissa.naciff@gmail.com' OR m.nome ILIKE '%clarissa%naciff%';

-- 3. Verificar relacionamento cruzado
SELECT 'Verificação de relacionamento cruzado:' as info;
SELECT 
  m1.nome as membro1,
  m1.idmembro as id1,
  m1.conjuge_id as conjuge_id1,
  m2.nome as conjuge1,
  m2.conjuge_id as conjuge_id2,
  CASE 
    WHEN m1.conjuge_id = m2.idmembro AND m2.conjuge_id = m1.idmembro THEN 'RECÍPROCO COMPLETO'
    WHEN m1.conjuge_id = m2.idmembro AND m2.conjuge_id IS NULL THEN 'FALTA RECÍPROCO EM M2'
    WHEN m1.conjuge_id = m2.idmembro AND m2.conjuge_id != m1.idmembro THEN 'RECÍPROCO INCORRETO EM M2'
    ELSE 'SITUAÇÃO DESCONHECIDA'
  END as status_relacionamento
FROM membros m1
LEFT JOIN membros m2 ON m1.conjuge_id = m2.idmembro
WHERE m1.idmembro IN (
  SELECT m.idmembro 
  FROM membros m
  LEFT JOIN usuarios u ON u.idmembro = m.idmembro
  WHERE u.email IN ('ramon.naciff@gmail.com', 'clarissa.naciff@gmail.com')
     OR m.nome ILIKE '%ramon%naciff%' 
     OR m.nome ILIKE '%clarissa%naciff%'
);

-- 4. Simular a query do componente CorrecaoConjuges
SELECT 'Simulação da query do CorrecaoConjuges:' as info;
SELECT 
  m.idmembro,
  m.nome,
  m.conjuge_id,
  conjuge.idmembro as conjuge_idmembro,
  conjuge.nome as conjuge_nome,
  conjuge.conjuge_id as conjuge_conjuge_id,
  CASE 
    WHEN conjuge.conjuge_id = m.idmembro THEN 'TEM RECÍPROCO'
    ELSE 'SEM RECÍPROCO'
  END as status_reciproco
FROM membros m
LEFT JOIN membros conjuge ON m.conjuge_id = conjuge.idmembro
WHERE m.conjuge_id IS NOT NULL
  AND m.idmembro IN (
    SELECT m2.idmembro 
    FROM membros m2
    LEFT JOIN usuarios u ON u.idmembro = m2.idmembro
    WHERE u.email IN ('ramon.naciff@gmail.com', 'clarissa.naciff@gmail.com')
       OR m2.nome ILIKE '%ramon%naciff%' 
       OR m2.nome ILIKE '%clarissa%naciff%'
  );

-- 5. Verificar se aparecem na lista de incompletos
SELECT 'Membros que apareceriam na lista de incompletos:' as info;
SELECT 
  m.idmembro,
  m.nome,
  m.conjuge_id,
  conjuge.nome as nome_conjuge,
  conjuge.conjuge_id as conjuge_tem_reciproco_id,
  CASE 
    WHEN conjuge.conjuge_id != m.idmembro OR conjuge.conjuge_id IS NULL THEN 'APARECERIA NA LISTA'
    ELSE 'NÃO APARECERIA'
  END as status_lista
FROM membros m
LEFT JOIN membros conjuge ON m.conjuge_id = conjuge.idmembro
WHERE m.conjuge_id IS NOT NULL
  AND (conjuge.conjuge_id != m.idmembro OR conjuge.conjuge_id IS NULL);