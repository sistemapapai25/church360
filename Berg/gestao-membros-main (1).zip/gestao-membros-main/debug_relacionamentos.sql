-- Script de diagnóstico para problemas com relacionamentos familiares
-- Execute no Supabase SQL Editor

-- 1. Verificar se a view 'me' está funcionando
SELECT 'Teste da view me:' as info;
SELECT * FROM me;

-- 2. Verificar dados do usuário atual
SELECT 'Dados do usuário atual:' as info;
SELECT 
  u.idusuario,
  u.email,
  u.permissao,
  u.auth_uid,
  u.idmembro,
  auth.uid() as current_auth_uid,
  CASE 
    WHEN u.auth_uid = auth.uid() THEN 'MATCH'
    ELSE 'NO MATCH'
  END as auth_match
FROM usuarios u 
WHERE u.auth_uid = auth.uid();

-- 3. Verificar políticas ativas na tabela relacionamentos_familiares
SELECT 'Políticas ativas na tabela relacionamentos_familiares:' as info;
SELECT 
  schemaname, 
  tablename, 
  policyname, 
  permissive, 
  roles, 
  cmd, 
  qual, 
  with_check
FROM pg_policies 
WHERE tablename = 'relacionamentos_familiares' 
ORDER BY policyname;

-- 4. Testar se a condição da política está funcionando
SELECT 'Teste da condição da política INSERT:' as info;
SELECT 
  EXISTS (SELECT 1 FROM me) as me_exists,
  (SELECT idmembro FROM me) as me_idmembro,
  auth.role() as current_role,
  CASE 
    WHEN auth.role() = 'authenticated' AND EXISTS (SELECT 1 FROM me) THEN 'POLICY SHOULD ALLOW'
    ELSE 'POLICY WILL DENY'
  END as policy_result;

-- 5. Verificar se RLS está habilitado
SELECT 'Status RLS da tabela relacionamentos_familiares:' as info;
SELECT 
  schemaname, 
  tablename, 
  rowsecurity 
FROM pg_tables 
WHERE tablename = 'relacionamentos_familiares';

-- 6. Teste direto de inserção (pode falhar, é esperado para diagnóstico)
-- DESCOMENTE APENAS PARA TESTE:
-- INSERT INTO relacionamentos_familiares (membro_id, parente_id, tipo_relacionamento) 
-- VALUES ('1', '2', 'irmao');