-- Script para verificar relacionamentos de cônjuges na tabela relacionamentos_familiares
-- Execute no Supabase SQL Editor

-- 1. Verificar todos os relacionamentos familiares
SELECT 'Todos os relacionamentos familiares:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as parente_nome,
  m2.email as parente_email
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
ORDER BY m1.nome, rf.tipo_relacionamento;

-- 2. Verificar especificamente relacionamentos de cônjuge/esposa
SELECT 'Relacionamentos de cônjuge/esposa:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as parente_nome,
  m2.email as parente_email
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento IN ('conjuge', 'esposa', 'esposo', 'marido')
ORDER BY m1.nome;

-- 3. Verificar especificamente Ramon e Clarissa
SELECT 'Relacionamentos específicos de Ramon e Clarissa:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as parente_nome,
  m2.email as parente_email
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE (m1.email = 'ramon.naciff@gmail.com' OR m1.email = 'clarissa.naciff@gmail.com')
   OR (m2.email = 'ramon.naciff@gmail.com' OR m2.email = 'clarissa.naciff@gmail.com')
ORDER BY m1.nome;

-- 4. Verificar se existem relacionamentos recíprocos
SELECT 'Análise de reciprocidade nos relacionamentos familiares:' as info;
SELECT 
  rf1.id as relacionamento_1,
  m1.nome as pessoa_1,
  m1.email as email_1,
  rf1.tipo_relacionamento as tipo_1_para_2,
  m2.nome as pessoa_2,
  m2.email as email_2,
  rf2.id as relacionamento_reciproco,
  rf2.tipo_relacionamento as tipo_2_para_1,
  CASE 
    WHEN rf2.id IS NOT NULL THEN '✅ TEM RECÍPROCO'
    ELSE '❌ SEM RECÍPROCO'
  END as status_reciprocidade
FROM relacionamentos_familiares rf1
JOIN membros m1 ON rf1.membro_id = m1.idmembro
JOIN membros m2 ON rf1.parente_id = m2.idmembro
LEFT JOIN relacionamentos_familiares rf2 ON rf2.membro_id = rf1.parente_id 
  AND rf2.parente_id = rf1.membro_id
WHERE rf1.tipo_relacionamento IN ('conjuge', 'esposa', 'esposo', 'marido')
ORDER BY m1.nome;

-- 5. Estatísticas dos relacionamentos familiares
SELECT 'Estatísticas dos relacionamentos familiares:' as info;
SELECT 
  tipo_relacionamento,
  COUNT(*) as quantidade
FROM relacionamentos_familiares
GROUP BY tipo_relacionamento
ORDER BY quantidade DESC;

-- 5. Estatísticas dos relacionamentos familiares
SELECT 'Estatísticas dos relacionamentos familiares:' as info;
SELECT 
  tipo_relacionamento,
  COUNT(*) as quantidade
FROM relacionamentos_familiares
GROUP BY tipo_relacionamento
ORDER BY quantidade DESC;