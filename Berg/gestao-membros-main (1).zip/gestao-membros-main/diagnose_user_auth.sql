-- Script de diagnóstico completo para investigar problemas de autenticação
-- Este script verifica a integridade dos dados do usuário e autenticação

-- 1. Verificar o auth.uid() atual
SELECT 
  'Current auth.uid()' as check_type,
  auth.uid() as auth_uid,
  CASE 
    WHEN auth.uid() IS NULL THEN 'ERROR: No authenticated user'
    ELSE 'OK: User is authenticated'
  END as status;

-- 2. Verificar se existe um usuário com este auth_uid na tabela usuarios
SELECT 
  'User lookup by auth_uid' as check_type,
  u.email,
  u.permissao,
  u.idmembro,
  u.auth_uid,
  u.created_at
FROM public.usuarios u 
WHERE u.auth_uid = auth.uid();

-- 3. Verificar todos os usuários ADM na tabela (para debug)
SELECT 
  'All ADM users' as check_type,
  u.email,
  u.permissao,
  u.idmembro,
  u.auth_uid,
  u.created_at
FROM public.usuarios u 
WHERE u.permissao = 'ADM'
ORDER BY u.created_at;

-- 4. Verificar se há problemas com a tabela usuarios
SELECT 
  'Table integrity check' as check_type,
  COUNT(*) as total_users,
  COUNT(CASE WHEN permissao = 'ADM' THEN 1 END) as adm_users,
  COUNT(CASE WHEN permissao = 'OPE' THEN 1 END) as ope_users,
  COUNT(CASE WHEN auth_uid IS NULL THEN 1 END) as users_without_auth_uid
FROM public.usuarios;

-- 5. Verificar a view 'me' diretamente
SELECT 
  'ME view test' as check_type,
  me.email,
  me.permissao,
  me.idmembro
FROM me;

-- 6. Verificar se o usuário atual está na tabela auth.users
SELECT 
  'Auth users check' as check_type,
  au.id as auth_user_id,
  au.email as auth_email,
  au.created_at as auth_created_at,
  CASE 
    WHEN au.id = auth.uid() THEN 'MATCH: This is the current user'
    ELSE 'NO MATCH'
  END as match_status
FROM auth.users au 
WHERE au.id = auth.uid();

-- 7. Verificar se há discrepância entre auth.users e public.usuarios
SELECT 
  'Cross-table verification' as check_type,
  au.email as auth_email,
  u.email as usuarios_email,
  u.permissao,
  CASE 
    WHEN u.auth_uid IS NULL THEN 'ERROR: Missing auth_uid in usuarios'
    WHEN au.id != u.auth_uid THEN 'ERROR: Mismatched auth_uid'
    ELSE 'OK: Data is consistent'
  END as consistency_check
FROM auth.users au
LEFT JOIN public.usuarios u ON au.id = u.auth_uid
WHERE au.id = auth.uid();