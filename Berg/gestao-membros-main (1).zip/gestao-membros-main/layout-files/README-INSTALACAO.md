# Instalação do Layout Idêntico

## 1. Substitua estes arquivos no seu projeto:

### Arquivos principais (OBRIGATÓRIOS):
- `src/index.css` → Copie TODO o conteúdo
- `tailwind.config.ts` → Substitua completamente  
- `src/components/ui/button.tsx` → Substitua completamente

### Estrutura dos componentes:
- `src/components/MainLayout.tsx` → Adapte para suas rotas
- `src/components/AppSidebar.tsx` → Adapte os itens do menu

## 2. Dependências necessárias:

```bash
npm install @radix-ui/react-slot
npm install class-variance-authority
npm install clsx
npm install tailwind-merge
npm install tailwindcss-animate
npm install lucide-react
```

## 3. Componentes UI necessários (shadcn/ui):

```bash
npx shadcn-ui@latest add sidebar
npx shadcn-ui@latest add badge
npx shadcn-ui@latest add collapsible
npx shadcn-ui@latest add button
```

## 4. Estrutura de pastas:

```
src/
├── components/
│   ├── ui/
│   │   ├── sidebar.tsx
│   │   ├── button.tsx
│   │   ├── badge.tsx
│   │   └── collapsible.tsx
│   ├── MainLayout.tsx
│   └── AppSidebar.tsx
├── lib/
│   └── utils.ts
└── index.css
```

## 5. Personalizações necessárias:

### No AppSidebar.tsx:
- Ajuste os `menuItems` para suas páginas
- Modifique as permissões conforme sua lógica
- Altere os ícones dos menus

### No MainLayout.tsx:
- Substitua o logo: `src="/seu-logo.png"`
- Ajuste o título: "Sistema de Gestão" 
- Conecte suas rotas/componentes

### No index.css:
- MANTENHA todas as variáveis CSS
- NÃO remova as classes utilitárias
- As cores podem ser ajustadas nas variáveis `--primary`, `--secondary`, etc.

## 6. Resultado esperado:

✅ Sidebar retrátil com animações suaves
✅ Header com logo e título gradiente
✅ Botões com gradientes e sombras elegantes  
✅ Design system completo com modo escuro
✅ Layout responsivo e profissional
✅ Cores consistentes em todo o sistema

## 7. Problemas comuns:

❌ **Cores não aparecem**: Verifique se copiou todo o `index.css`
❌ **Sidebar não funciona**: Instale os componentes shadcn corretos
❌ **Gradientes não funcionam**: Verifique o `tailwind.config.ts`
❌ **Layout quebrado**: Use `w-full` no container do SidebarProvider

## 8. Teste final:

- [ ] Sidebar abre/fecha corretamente
- [ ] Header com logo e título gradiente
- [ ] Botões com visual elegante (gradientes/sombras)
- [ ] Cores consistentes em modo claro/escuro
- [ ] Navegação entre telas funcionando
- [ ] Design responsivo no mobile