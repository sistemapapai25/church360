import { 
  Calendar, 
  Home, 
  Users, 
  Settings, 
  LogOut,
  ChevronDown,
  Building2,
  MapPin,
  CalendarDays,
  UserCog,
  Shield
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";

interface User {
  email: string;
  permission: "ADM" | "LDR" | "USR" | "MTR" | "OPE";
  memberName?: string;
}

interface AppSidebarProps {
  user: User;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
}

const PERMISSION_LABELS = {
  ADM: { label: "Admin", color: "bg-red-500" },
  LDR: { label: "Líder", color: "bg-blue-500" },
  USR: { label: "Usuário", color: "bg-green-500" },
  MTR: { label: "Membro", color: "bg-yellow-500" },
  OPE: { label: "Operador", color: "bg-purple-500" },
};

export function AppSidebar({ user, activeTab, onTabChange, onLogout }: AppSidebarProps) {
  const { collapsed } = useSidebar();

  const menuItems = [
    {
      title: "Dashboard",
      icon: Home,
      id: "dashboard",
    },
    {
      title: "Agenda",
      icon: Calendar,
      id: "agenda",
    },
    {
      title: "Membros",
      icon: Users,
      id: "membros",
    },
  ];

  const liderancaItems = [
    {
      title: "Líderes",
      icon: UserCog,
      id: "lideres",
    },
    {
      title: "Departamentos",
      icon: Building2,
      id: "departamentos",
      adminOnly: true,
    },
    {
      title: "Áreas",
      icon: MapPin,
      id: "areas",
      adminOnly: true,
    },
  ];

  const agendaItems = [
    {
      title: "Tipos de Eventos",
      icon: CalendarDays,
      id: "tipos-eventos",
      adminOnly: true,
    },
    {
      title: "Locais de Eventos",
      icon: MapPin,
      id: "locais-eventos",
      adminOnly: true,
    },
  ];

  return (
    <Sidebar className="border-r bg-background/95 backdrop-blur-sm">
      <SidebarContent>
        {/* Menu Principal */}
        <SidebarGroup>
          <SidebarGroupLabel>Menu Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    onClick={() => onTabChange(item.id)}
                    isActive={activeTab === item.id}
                    className="w-full justify-start"
                  >
                    <item.icon className="h-4 w-4" />
                    {!collapsed && <span>{item.title}</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Liderança */}
        <SidebarGroup>
          <Collapsible defaultOpen>
            <CollapsibleTrigger asChild>
              <SidebarGroupLabel className="group/collapsible cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
                Liderança
                <ChevronDown className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-180" />
              </SidebarGroupLabel>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <SidebarGroupContent>
                <SidebarMenu>
                  {liderancaItems.map((item) => {
                    if (item.adminOnly && user.permission !== "ADM") return null;
                    return (
                      <SidebarMenuItem key={item.id}>
                        <SidebarMenuButton
                          onClick={() => onTabChange(item.id)}
                          isActive={activeTab === item.id}
                          className="w-full justify-start"
                        >
                          <item.icon className="h-4 w-4" />
                          {!collapsed && <span>{item.title}</span>}
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </CollapsibleContent>
          </Collapsible>
        </SidebarGroup>

        {/* Agenda - Cadastros */}
        {user.permission === "ADM" && (
          <SidebarGroup>
            <Collapsible defaultOpen>
              <CollapsibleTrigger asChild>
                <SidebarGroupLabel className="group/collapsible cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
                  Agenda - Cadastros
                  <ChevronDown className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-180" />
                </SidebarGroupLabel>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {agendaItems.map((item) => (
                      <SidebarMenuItem key={item.id}>
                        <SidebarMenuButton
                          onClick={() => onTabChange(item.id)}
                          isActive={activeTab === item.id}
                          className="w-full justify-start"
                        >
                          <item.icon className="h-4 w-4" />
                          {!collapsed && <span>{item.title}</span>}
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </Collapsible>
          </SidebarGroup>
        )}

        {/* Administração */}
        {user.permission === "ADM" && (
          <SidebarGroup>
            <SidebarGroupLabel>Administração</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    onClick={() => onTabChange("usuarios")}
                    isActive={activeTab === "usuarios"}
                    className="w-full justify-start"
                  >
                    <Shield className="h-4 w-4" />
                    {!collapsed && <span>Usuários</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <div className="flex flex-col gap-2 p-2">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-xs font-medium text-primary-foreground">
                    {user.memberName?.[0] || user.email[0].toUpperCase()}
                  </span>
                </div>
                {!collapsed && (
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {user.memberName || user.email}
                    </p>
                    <Badge 
                      variant="secondary" 
                      className={`text-xs ${PERMISSION_LABELS[user.permission].color} text-white`}
                    >
                      {PERMISSION_LABELS[user.permission].label}
                    </Badge>
                  </div>
                )}
              </div>
              <SidebarMenuButton onClick={onLogout} className="w-full justify-start text-red-600 hover:bg-red-50">
                <LogOut className="h-4 w-4" />
                {!collapsed && <span>Sair</span>}
              </SidebarMenuButton>
            </div>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}