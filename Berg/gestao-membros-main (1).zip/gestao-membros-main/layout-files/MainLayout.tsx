import { ReactNode, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";

interface User {
  email: string;
  permission: "ADM" | "LDR" | "USR" | "MTR" | "OPE";
  memberName?: string;
}

interface Props {
  user: User;
  onLogout: () => Promise<{ error: any }> | (() => void);
  children?: ReactNode;
}

export default function MainLayout({ user, onLogout }: Props) {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-subtle">
        <AppSidebar
          user={user}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          onLogout={() => onLogout()}
        />

        <div className="flex-1 min-w-0">
          {/* Header */}
          <header className="bg-background/95 backdrop-blur-sm border-b shadow-lg sticky top-0 z-40">
            <div className="flex items-center gap-3 px-4 py-3">
              <SidebarTrigger className="mr-1" />
              <img
                src="/seu-logo.png" // Substitua pelo seu logo
                alt="Sua Igreja"
                className="w-8 h-8 object-contain"
              />
              <h1 className="text-lg font-bold bg-gradient-to-r from-primary via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Sistema de Gestão
              </h1>
            </div>
          </header>

          {/* Content */}
          <main className="p-6">
            {/* Aqui você renderiza seus componentes baseado no activeTab */}
            {activeTab === "dashboard" && <div>Dashboard Component</div>}
            {activeTab === "agenda" && <div>Agenda Component</div>}
            {activeTab === "membros" && <div>Membros Component</div>}
            {/* Adicione mais tabs conforme necessário */}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}