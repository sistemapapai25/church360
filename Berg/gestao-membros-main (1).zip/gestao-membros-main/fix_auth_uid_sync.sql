-- Script para corrigir a sincronização entre auth.users e public.usuarios
-- Este script resolve o problema onde o usuário autenticado não está vinculado corretamente na tabela usuarios

-- 1. Primeiro, vamos verificar o estado atual
SELECT 
  'Current State Check' as step,
  auth.uid() as current_auth_uid,
  (SELECT email FROM auth.users WHERE id = auth.uid()) as auth_email,
  (SELECT COUNT(*) FROM public.usuarios WHERE auth_uid = auth.uid()) as matching_usuarios_count;

-- 2. Mostrar usuários ADM sem auth_uid ou com auth_uid incorreto
SELECT 
  'ADM Users Analysis' as step,
  u.email,
  u.permissao,
  u.auth_uid,
  CASE 
    WHEN u.auth_uid IS NULL THEN 'Missing auth_uid'
    WHEN u.auth_uid != auth.uid() THEN 'Different auth_uid'
    ELSE 'Correct auth_uid'
  END as status
FROM public.usuarios u 
WHERE u.permissao = 'ADM';

-- 3. Tentar encontrar o usuário correto pelo email
SELECT 
  'Email Match Check' as step,
  u.email as usuarios_email,
  u.permissao,
  u.auth_uid as current_auth_uid,
  (SELECT email FROM auth.users WHERE id = auth.uid()) as auth_email,
  CASE 
    WHEN u.email = (SELECT email FROM auth.users WHERE id = auth.uid()) THEN 'EMAIL MATCH - This user should be updated'
    ELSE 'No email match'
  END as match_status
FROM public.usuarios u 
WHERE u.permissao = 'ADM';

-- 4. CORREÇÃO: Atualizar o auth_uid do usuário correto
-- Esta query atualiza o usuário na tabela usuarios que tem o mesmo email do usuário autenticado
UPDATE public.usuarios 
SET auth_uid = auth.uid()
WHERE email = (SELECT email FROM auth.users WHERE id = auth.uid())
  AND permissao = 'ADM'
  AND (auth_uid IS NULL OR auth_uid != auth.uid());

-- 5. Verificar se a correção funcionou
SELECT 
  'Post-Update Verification' as step,
  u.email,
  u.permissao,
  u.auth_uid,
  CASE 
    WHEN u.auth_uid = auth.uid() THEN 'SUCCESS: auth_uid updated correctly'
    ELSE 'FAILED: auth_uid still incorrect'
  END as update_status
FROM public.usuarios u 
WHERE u.email = (SELECT email FROM auth.users WHERE id = auth.uid());

-- 6. Testar a política novamente após a correção
SELECT 
  'Final Policy Test' as step,
  CASE 
    WHEN EXISTS (
      SELECT 1 
      FROM public.usuarios u 
      WHERE u.auth_uid = auth.uid() 
      AND u.permissao IN ('ADM', 'OPE')
    ) THEN 'PASS - User now has ADM/OPE permission'
    ELSE 'FAIL - User still does not have ADM/OPE permission'
  END as result;

-- 7. Verificar a view 'me' após a correção
SELECT 
  'ME View After Fix' as step,
  me.email,
  me.permissao,
  me.idmembro
FROM me;