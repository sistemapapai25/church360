-- Script completo para testar relacionamentos de Ramon e Clarissa
-- Execute no Supabase SQL Editor

-- 1. Primeiro, vamos verificar se Ramon e Clarissa existem na tabela membros
SELECT 'Verificando existência de Ramon e Clarissa:' as info;
SELECT 
  idmembro,
  nome,
  email,
  conjuge_id,
  estado_civil,
  data_casamento
FROM membros
WHERE nome ILIKE '%ramon%' OR nome ILIKE '%clarissa%'
ORDER BY nome;

-- 2. Buscar relacionamentos onde Ramon ou Clarissa são o membro principal
SELECT 'Relacionamentos onde Ramon ou Clarissa são o membro principal:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as parente_nome,
  m2.email as parente_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE (m1.nome ILIKE '%ramon%' OR m1.nome ILIKE '%clarissa%')
ORDER BY m1.nome, rf.tipo_relacionamento;

-- 3. Buscar relacionamentos onde Ramon ou Clarissa são o parente
SELECT 'Relacionamentos onde Ramon ou Clarissa são o parente:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as parente_nome,
  m2.email as parente_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE (m2.nome ILIKE '%ramon%' OR m2.nome ILIKE '%clarissa%')
ORDER BY m2.nome, rf.tipo_relacionamento;

-- 4. Buscar especificamente relacionamentos de cônjuge envolvendo Ramon ou Clarissa
SELECT 'Relacionamentos de cônjuge envolvendo Ramon ou Clarissa:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as conjuge_nome,
  m2.email as conjuge_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
  AND (
    m1.nome ILIKE '%ramon%' OR m1.nome ILIKE '%clarissa%'
    OR m2.nome ILIKE '%ramon%' OR m2.nome ILIKE '%clarissa%'
  )
ORDER BY rf.created_at;

-- 5. Verificar se existe relacionamento recíproco entre Ramon e Clarissa
SELECT 'Verificação de reciprocidade Ramon ↔ Clarissa:' as info;
WITH ramon_clarissa AS (
  SELECT idmembro, nome, email 
  FROM membros 
  WHERE nome ILIKE '%ramon%' AND nome ILIKE '%naciff%'
),
clarissa_ramon AS (
  SELECT idmembro, nome, email 
  FROM membros 
  WHERE nome ILIKE '%clarissa%' AND nome ILIKE '%naciff%'
)
SELECT 
  'Ramon → Clarissa' as direcao,
  rf.id,
  r.nome as de_pessoa,
  r.email as de_email,
  rf.tipo_relacionamento,
  c.nome as para_pessoa,
  c.email as para_email
FROM relacionamentos_familiares rf
JOIN ramon_clarissa r ON rf.membro_id = r.idmembro
JOIN clarissa_ramon c ON rf.parente_id = c.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'

UNION ALL

SELECT 
  'Clarissa → Ramon' as direcao,
  rf.id,
  c.nome as de_pessoa,
  c.email as de_email,
  rf.tipo_relacionamento,
  r.nome as para_pessoa,
  r.email as para_email
FROM relacionamentos_familiares rf
JOIN clarissa_ramon c ON rf.membro_id = c.idmembro
JOIN ramon_clarissa r ON rf.parente_id = r.idmembro
WHERE rf.tipo_relacionamento = 'conjuge';

-- 6. Listar todos os relacionamentos de cônjuge para contexto
SELECT 'Todos os relacionamentos de cônjuge no sistema:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  m2.nome as conjuge_nome,
  m2.email as conjuge_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
ORDER BY m1.nome;