-- Script específico para investigar Ramon e Clarissa entre os relacionamentos de cônjuge
-- Execute no Supabase SQL Editor

-- 1. Buscar especificamente Ramon e Clarissa nos relacionamentos de cônjuge
SELECT 'Relacionamentos de cônjuge envolvendo Ramon ou Clarissa:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  rf.tipo_relacionamento,
  m2.nome as conjuge_nome,
  m2.email as conjuge_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
  AND (
    m1.email IN ('ramon.naciff@gmail.com', 'clarissa.naciff@gmail.com')
    OR m2.email IN ('ramon.naciff@gmail.com', 'clarissa.naciff@gmail.com')
  )
ORDER BY rf.created_at;

-- 2. Verificar se existe relacionamento recíproco entre Ramon e Clarissa
SELECT 'Verificação de reciprocidade Ramon ↔ Clarissa:' as info;
SELECT 
  'Ramon → Clarissa' as direcao,
  rf.id,
  m1.nome as de_pessoa,
  m1.email as de_email,
  rf.tipo_relacionamento,
  m2.nome as para_pessoa,
  m2.email as para_email
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
  AND m1.email = 'ramon.naciff@gmail.com'
  AND m2.email = 'clarissa.naciff@gmail.com'

UNION ALL

SELECT 
  'Clarissa → Ramon' as direcao,
  rf.id,
  m1.nome as de_pessoa,
  m1.email as de_email,
  rf.tipo_relacionamento,
  m2.nome as para_pessoa,
  m2.email as para_email
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
  AND m1.email = 'clarissa.naciff@gmail.com'
  AND m2.email = 'ramon.naciff@gmail.com';

-- 3. Listar todos os 14 relacionamentos de cônjuge para contexto
SELECT 'Todos os 14 relacionamentos de cônjuge:' as info;
SELECT 
  rf.id,
  m1.nome as membro_principal,
  m1.email as email_principal,
  m2.nome as conjuge_nome,
  m2.email as conjuge_email,
  rf.created_at
FROM relacionamentos_familiares rf
JOIN membros m1 ON rf.membro_id = m1.idmembro
JOIN membros m2 ON rf.parente_id = m2.idmembro
WHERE rf.tipo_relacionamento = 'conjuge'
ORDER BY m1.nome;

-- 4. Verificar se Ramon e Clarissa existem na tabela membros
SELECT 'Verificação de existência de Ramon e Clarissa na tabela membros:' as info;
SELECT 
  idmembro,
  nome,
  email,
  conjuge_id
FROM membros
WHERE email IN ('ramon.naciff@gmail.com', 'clarissa.naciff@gmail.com')
ORDER BY nome;