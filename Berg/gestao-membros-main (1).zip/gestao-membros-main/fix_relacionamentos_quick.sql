-- Script de correção rápida para relacionamentos familiares
-- Remove todas as políticas existentes e recria com as corretas

-- Primeiro, remover TODAS as políticas existentes
DROP POLICY IF EXISTS "relacionamentos_insert_admin" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_update_admin" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_delete_admin" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_select_authenticated" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_select_all" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_insert_self" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_update_self" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_delete_self" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_insert_policy" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_update_policy" ON public.relacionamentos_familiares;
DROP POLICY IF EXISTS "relacionamentos_delete_policy" ON public.relacionamentos_familiares;

-- Agora criar as novas políticas
-- Política de SELECT: permitir para todos autenticados
CREATE POLICY "relacionamentos_select_all"
ON public.relacionamentos_familiares
FOR SELECT
TO authenticated
USING (true);

-- Política de INSERT: permitir ADM/OPE ou próprio membro
CREATE POLICY "relacionamentos_insert_policy"
ON public.relacionamentos_familiares
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
  OR
  (
    EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
    AND membro_id = (SELECT idmembro FROM me)
  )
);

-- Política de UPDATE: permitir ADM/OPE ou próprio membro
CREATE POLICY "relacionamentos_update_policy"
ON public.relacionamentos_familiares
FOR UPDATE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
  OR
  (
    EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
    AND membro_id = (SELECT idmembro FROM me)
  )
)
WITH CHECK (
  EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
  OR
  (
    EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
    AND membro_id = (SELECT idmembro FROM me)
  )
);

-- Política de DELETE: permitir ADM/OPE ou membro envolvido
CREATE POLICY "relacionamentos_delete_policy"
ON public.relacionamentos_familiares
FOR DELETE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE'))
  OR
  (
    EXISTS (SELECT 1 FROM me WHERE idmembro IS NOT NULL)
    AND (
      membro_id = (SELECT idmembro FROM me)
      OR parente_id = (SELECT idmembro FROM me)
    )
  )
);