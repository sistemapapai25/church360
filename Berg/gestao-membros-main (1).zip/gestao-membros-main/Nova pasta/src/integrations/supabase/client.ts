import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

// Configuração direta do Supabase para Lovable
const SUPABASE_URL = 'https://tqtsnuplmqfgastmksun.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxdHNudXBsbXFmZ2FzdG1rc3VuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUyOTc1MDEsImV4cCI6MjA3MDg3MzUwMX0.eZnq0skN-iZ7NHaOn_QkaCEF4nIQEgdnMQHgi0Tj4Jw';

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  }
});