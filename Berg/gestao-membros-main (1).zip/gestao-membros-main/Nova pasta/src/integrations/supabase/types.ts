export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      agenda: {
        Row: {
          created_at: string | null
          created_by: string | null
          data: string
          descricao: string | null
          horario_final: string | null
          horario_inicial: string | null
          idagenda: string
          iddepto: string
          ideventoig: string | null
          idlider: string | null
          idlocal: string | null
          idstatus: string | null
          observacao: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          data: string
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda?: string
          iddepto: string
          ideventoig?: string | null
          idlider?: string | null
          idlocal?: string | null
          idstatus?: string | null
          observacao?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          data?: string
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda?: string
          iddepto?: string
          ideventoig?: string | null
          idlider?: string | null
          idlocal?: string | null
          idstatus?: string | null
          observacao?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "agenda_ideventoig_fkey"
            columns: ["ideventoig"]
            isOneToOne: false
            referencedRelation: "eventos_igreja"
            referencedColumns: ["ideventoig"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlocal_fkey"
            columns: ["idlocal"]
            isOneToOne: false
            referencedRelation: "locais"
            referencedColumns: ["idlocal"]
          },
          {
            foreignKeyName: "agenda_idstatus_fkey"
            columns: ["idstatus"]
            isOneToOne: false
            referencedRelation: "status_agenda"
            referencedColumns: ["idstatus"]
          },
        ]
      }
      areas: {
        Row: {
          created_at: string | null
          descricao: string | null
          idarea: string
          iddepto: string
          lider1: string | null
          lider2: string | null
          nome: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          descricao?: string | null
          idarea?: string
          iddepto: string
          lider1?: string | null
          lider2?: string | null
          nome: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          descricao?: string | null
          idarea?: string
          iddepto?: string
          lider1?: string | null
          lider2?: string | null
          nome?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      cidade: {
        Row: {
          cidade: string
          id: string
          uf: string
        }
        Insert: {
          cidade: string
          id: string
          uf: string
        }
        Update: {
          cidade?: string
          id?: string
          uf?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_cidade_uf"
            columns: ["uf"]
            isOneToOne: false
            referencedRelation: "uf"
            referencedColumns: ["uf"]
          },
        ]
      }
      departamentos: {
        Row: {
          iddepto: string
          liderdepto1: string | null
          liderdepto2: string | null
          nome: string
        }
        Insert: {
          iddepto: string
          liderdepto1?: string | null
          liderdepto2?: string | null
          nome: string
        }
        Update: {
          iddepto?: string
          liderdepto1?: string | null
          liderdepto2?: string | null
          nome?: string
        }
        Relationships: []
      }
      eventos_igreja: {
        Row: {
          evento: string
          ideventoig: string
        }
        Insert: {
          evento: string
          ideventoig: string
        }
        Update: {
          evento?: string
          ideventoig?: string
        }
        Relationships: []
      }
      lideres: {
        Row: {
          idarea: string | null
          iddepto: string
          idlider: string
          idmembro: string
          idposicao: string | null
          status: string | null
        }
        Insert: {
          idarea?: string | null
          iddepto: string
          idlider: string
          idmembro: string
          idposicao?: string | null
          status?: string | null
        }
        Update: {
          idarea?: string | null
          iddepto?: string
          idlider?: string
          idmembro?: string
          idposicao?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lideres_idarea_fkey"
            columns: ["idarea"]
            isOneToOne: false
            referencedRelation: "areas"
            referencedColumns: ["idarea"]
          },
          {
            foreignKeyName: "lideres_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "lideres_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      lideres_backup: {
        Row: {
          idarea: string | null
          iddepto: string | null
          idlider: string | null
          idmembro: string | null
          idposicao: string | null
          status: string | null
        }
        Insert: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string | null
          idmembro?: string | null
          idposicao?: string | null
          status?: string | null
        }
        Update: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string | null
          idmembro?: string | null
          idposicao?: string | null
          status?: string | null
        }
        Relationships: []
      }
      locais: {
        Row: {
          contato: string | null
          fone: string | null
          idlocal: string
          local: string
        }
        Insert: {
          contato?: string | null
          fone?: string | null
          idlocal: string
          local: string
        }
        Update: {
          contato?: string | null
          fone?: string | null
          idlocal?: string
          local?: string
        }
        Relationships: []
      }
      membros: {
        Row: {
          apelido: string | null
          bairro: string | null
          cep: string | null
          cidade: string | null
          complemento: string | null
          conjuge_id: string | null
          cpf: string | null
          created_at: string | null
          credencial: string | null
          data_casamento: string | null
          email: string | null
          endereco: string | null
          entrevista: string | null
          entrevistador: string | null
          estado_civil: string | null
          ficha_pdf: string | null
          foto: string | null
          iddepto: string | null
          idmembro: string
          nascimento: string | null
          nome: string
          profissao: string | null
          sexo: string | null
          status: string | null
          telefone: string | null
          tipo_membro: string | null
          uf: string | null
          updated_at: string | null
        }
        Insert: {
          apelido?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          conjuge_id?: string | null
          cpf?: string | null
          created_at?: string | null
          credencial?: string | null
          data_casamento?: string | null
          email?: string | null
          endereco?: string | null
          entrevista?: string | null
          entrevistador?: string | null
          estado_civil?: string | null
          ficha_pdf?: string | null
          foto?: string | null
          iddepto?: string | null
          idmembro: string
          nascimento?: string | null
          nome: string
          profissao?: string | null
          sexo?: string | null
          status?: string | null
          telefone?: string | null
          tipo_membro?: string | null
          uf?: string | null
          updated_at?: string | null
        }
        Update: {
          apelido?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          conjuge_id?: string | null
          cpf?: string | null
          created_at?: string | null
          credencial?: string | null
          data_casamento?: string | null
          email?: string | null
          endereco?: string | null
          entrevista?: string | null
          entrevistador?: string | null
          estado_civil?: string | null
          ficha_pdf?: string | null
          foto?: string | null
          iddepto?: string | null
          idmembro?: string
          nascimento?: string | null
          nome?: string
          profissao?: string | null
          sexo?: string | null
          status?: string | null
          telefone?: string | null
          tipo_membro?: string | null
          uf?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_membros_cidade"
            columns: ["cidade"]
            isOneToOne: false
            referencedRelation: "cidade"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_membros_conjuge"
            columns: ["conjuge_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "membros_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "membros_tipo_membro_fkey"
            columns: ["tipo_membro"]
            isOneToOne: false
            referencedRelation: "tipos_membro"
            referencedColumns: ["tipo"]
          },
        ]
      }
      membros_codigo_legacy: {
        Row: {
          codigo_legacy: string
          idmembro: string
        }
        Insert: {
          codigo_legacy: string
          idmembro: string
        }
        Update: {
          codigo_legacy?: string
          idmembro?: string
        }
        Relationships: [
          {
            foreignKeyName: "membros_codigo_legacy_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      permissoes: {
        Row: {
          permissao: string
        }
        Insert: {
          permissao: string
        }
        Update: {
          permissao?: string
        }
        Relationships: []
      }
      profissao: {
        Row: {
          idprofissao: string
          profissao: string
        }
        Insert: {
          idprofissao: string
          profissao: string
        }
        Update: {
          idprofissao?: string
          profissao?: string
        }
        Relationships: []
      }
      raizes_interacoes: {
        Row: {
          created_at: string
          created_by: string | null
          data_limite: string | null
          id: string
          observacoes: string | null
          proximo_passo: string | null
          responsavel_id: string | null
          resultado: string | null
          tipo: string
          visitante_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          data_limite?: string | null
          id?: string
          observacoes?: string | null
          proximo_passo?: string | null
          responsavel_id?: string | null
          resultado?: string | null
          tipo: string
          visitante_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          data_limite?: string | null
          id?: string
          observacoes?: string | null
          proximo_passo?: string | null
          responsavel_id?: string | null
          resultado?: string | null
          tipo?: string
          visitante_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "raizes_interacoes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "raizes_interacoes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "raizes_interacoes_visitante_id_fkey"
            columns: ["visitante_id"]
            isOneToOne: false
            referencedRelation: "visitantes"
            referencedColumns: ["id"]
          },
        ]
      }
      relacionamentos_familiares: {
        Row: {
          created_at: string
          id: string
          membro_id: string
          parente_id: string
          tipo_relacionamento: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          membro_id: string
          parente_id: string
          tipo_relacionamento: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          membro_id?: string
          parente_id?: string
          tipo_relacionamento?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "relacionamentos_familiares_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "relacionamentos_familiares_parente_id_fkey"
            columns: ["parente_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      status_agenda: {
        Row: {
          cor: string | null
          idstatus: string
          status: string
        }
        Insert: {
          cor?: string | null
          idstatus: string
          status: string
        }
        Update: {
          cor?: string | null
          idstatus?: string
          status?: string
        }
        Relationships: []
      }
      tipos_membro: {
        Row: {
          tipo: string
        }
        Insert: {
          tipo: string
        }
        Update: {
          tipo?: string
        }
        Relationships: []
      }
      uf: {
        Row: {
          iduf: string
          uf: string
        }
        Insert: {
          iduf: string
          uf: string
        }
        Update: {
          iduf?: string
          uf?: string
        }
        Relationships: []
      }
      usuarios: {
        Row: {
          auth_uid: string | null
          email: string
          idmembro: string | null
          idusuario: string
          permissao: string | null
        }
        Insert: {
          auth_uid?: string | null
          email: string
          idmembro?: string | null
          idusuario: string
          permissao?: string | null
        }
        Update: {
          auth_uid?: string | null
          email?: string
          idmembro?: string | null
          idusuario?: string
          permissao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "usuarios_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "usuarios_permissao_fkey"
            columns: ["permissao"]
            isOneToOne: false
            referencedRelation: "permissoes"
            referencedColumns: ["permissao"]
          },
        ]
      }
      visitantes: {
        Row: {
          contato: string | null
          created_at: string
          direcionado: string
          direcionado_flag: boolean | null
          email: string | null
          id: string
          id_short: string | null
          nascimento: string | null
          nome: string
          raizes_data_limite: string | null
          raizes_proximo_passo: string | null
          raizes_status: string | null
          responsavel_id: string | null
          telefone: string | null
        }
        Insert: {
          contato?: string | null
          created_at?: string
          direcionado?: string
          direcionado_flag?: boolean | null
          email?: string | null
          id?: string
          id_short?: string | null
          nascimento?: string | null
          nome: string
          raizes_data_limite?: string | null
          raizes_proximo_passo?: string | null
          raizes_status?: string | null
          responsavel_id?: string | null
          telefone?: string | null
        }
        Update: {
          contato?: string | null
          created_at?: string
          direcionado?: string
          direcionado_flag?: boolean | null
          email?: string | null
          id?: string
          id_short?: string | null
          nascimento?: string | null
          nome?: string
          raizes_data_limite?: string | null
          raizes_proximo_passo?: string | null
          raizes_status?: string | null
          responsavel_id?: string | null
          telefone?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "visitantes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "visitantes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
        ]
      }
    }
    Views: {
      agenda_full: {
        Row: {
          cor_evento: string | null
          created_at: string | null
          created_by: string | null
          data: string | null
          departamento: string | null
          descricao: string | null
          fim_ts: string | null
          horario_final: string | null
          horario_inicial: string | null
          idagenda: string | null
          iddepto: string | null
          ideventoig: string | null
          idlider: string | null
          idlocal: string | null
          idstatus: string | null
          inicio_ts: string | null
          nome_evento: string | null
          nome_lider: string | null
          nome_local: string | null
          observacao: string | null
          status_evento: string | null
          updated_at: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "agenda_ideventoig_fkey"
            columns: ["ideventoig"]
            isOneToOne: false
            referencedRelation: "eventos_igreja"
            referencedColumns: ["ideventoig"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlocal_fkey"
            columns: ["idlocal"]
            isOneToOne: false
            referencedRelation: "locais"
            referencedColumns: ["idlocal"]
          },
          {
            foreignKeyName: "agenda_idstatus_fkey"
            columns: ["idstatus"]
            isOneToOne: false
            referencedRelation: "status_agenda"
            referencedColumns: ["idstatus"]
          },
        ]
      }
      me: {
        Row: {
          auth_uid: string | null
          email: string | null
          idmembro: string | null
          idusuario: string | null
          permissao: string | null
        }
        Insert: {
          auth_uid?: string | null
          email?: string | null
          idmembro?: string | null
          idusuario?: string | null
          permissao?: string | null
        }
        Update: {
          auth_uid?: string | null
          email?: string | null
          idmembro?: string | null
          idusuario?: string | null
          permissao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "usuarios_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "usuarios_permissao_fkey"
            columns: ["permissao"]
            isOneToOne: false
            referencedRelation: "permissoes"
            referencedColumns: ["permissao"]
          },
        ]
      }
      raizes_lideres_resolvidos: {
        Row: {
          idlider: string | null
          nome: string | null
          nome_ord: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      create_user_with_profile: {
        Args: {
          p_email: string
          p_idmembro: string
          p_password: string
          p_permissao?: string
        }
        Returns: Json
      }
      is_current_user_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_current_user_lider_do_depto: {
        Args: { depto: string }
        Returns: boolean
      }
      list_users: {
        Args: Record<PropertyKey, never>
        Returns: {
          auth_uid: string
          created_at: string
          email: string
          idmembro: string
          idusuario: string
          nome_membro: string
          permissao: string
        }[]
      }
      reset_user_password: {
        Args: { p_new_password?: string; p_user_id: string }
        Returns: Json
      }
      unaccent: {
        Args: { "": string }
        Returns: string
      }
      unaccent_init: {
        Args: { "": unknown }
        Returns: unknown
      }
      update_user_info: {
        Args: { p_email?: string; p_idusuario: string; p_permissao?: string }
        Returns: Json
      }
    }
    Enums: {
      raizes_interacao_tipo:
        | "WhatsApp"
        | "Ligacao"
        | "Visita"
        | "Convite"
        | "Culto"
        | "Encaminhamento"
      raizes_status_type:
        | "Novo"
        | "Aguardando Contato"
        | "Em Contato"
        | "Visita Agendada"
        | "Convidado p/ Culto"
        | "Compareceu ao Culto"
        | "Não Compareceu"
        | "Integrado"
        | "Encerrado"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      raizes_interacao_tipo: [
        "WhatsApp",
        "Ligacao",
        "Visita",
        "Convite",
        "Culto",
        "Encaminhamento",
      ],
      raizes_status_type: [
        "Novo",
        "Aguardando Contato",
        "Em Contato",
        "Visita Agendada",
        "Convidado p/ Culto",
        "Compareceu ao Culto",
        "Não Compareceu",
        "Integrado",
        "Encerrado",
      ],
    },
  },
} as const
