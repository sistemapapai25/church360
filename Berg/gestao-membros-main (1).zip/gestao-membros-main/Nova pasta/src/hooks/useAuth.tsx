import { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  email: string;
  permission: 'ADM' | 'LDR' | 'USR' | 'MTR' | 'OPE';
  memberName?: string;
  idmembro?: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data: profile, error } = await supabase
        .from('usuarios')
        .select('email, permissao, idmembro')
        .eq('auth_uid', userId)
        .maybeSingle();
      
      if (error) throw error;
      if (!profile) return null;

      let memberName = profile.idmembro;
      if (profile.idmembro) {
        const { data: memberData, error: memberError } = await supabase
          .from('membros')
          .select('apelido, nome')
          .eq('idmembro', profile.idmembro)
          .maybeSingle();
        
        if (!memberError && memberData) {
          memberName = memberData.apelido || memberData.nome || profile.idmembro;
        }
      }

      return {
        email: profile.email,
        permission: profile.permissao as 'ADM' | 'LDR' | 'USR' | 'MTR' | 'OPE',
        memberName,
        idmembro: profile.idmembro
      };
    } catch (err) {
      console.error('Error fetching user profile:', err);
      return null;
    }
  };

  useEffect(() => {
    let mounted = true;

    const handleAuthChange = async (session: Session | null) => {
      if (!mounted) return;
      
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        try {
          const profile = await fetchUserProfile(session.user.id);
          if (mounted) setUserProfile(profile);
        } catch (error) {
          console.error('useAuth: Error fetching profile:', error);
          if (mounted) setUserProfile(null);
        }
      } else {
        setUserProfile(null);
      }
      
      if (mounted) setLoading(false);
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_, session) => handleAuthChange(session)
    );

    supabase.auth.getSession().then(
      ({ data: { session } }) => handleAuthChange(session)
    ).catch(err => {
      console.error('useAuth: Error getting initial session:', err);
      if (mounted) setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    return { error };
  };

  const signOut = async () => {
    let logoutError: any = null;
    try {
      const { error } = await supabase.auth.signOut({ scope: 'local' });
      logoutError = error || null;
      // Ignora erro de refresh token ausente, que é comum após revogações
      if (logoutError && String(logoutError.message || '').includes('Refresh Token Not Found')) {
        logoutError = null;
      }
    } catch (err) {
      // Alguns navegadores podem abortar a requisição; ignore e prossiga limpando estado
      console.warn('signOut: requisição abortada ou erro não crítico:', err);
    } finally {
      // Sempre limpa estado local para garantir UI consistente
      setUser(null);
      setSession(null);
      setUserProfile(null);
    }
    return { error: logoutError };
  };

  return {
    user,
    session,
    userProfile,
    loading,
    signIn,
    signOut
  };
}