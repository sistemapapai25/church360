// src/hooks/useUfCidades.ts
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/** Tipagens simples para evitar "any" */
export interface UfRow {
  iduf: string;
  uf: string; // "GO", "SP", ...
}
export interface CidadeRow {
  id: string;       // ex: "MUN902"
  cidade: string;   // ex: "Aparecida de Goiânia"
  uf: string;       // ex: "GO"
}

/**
 * Hook para carregar UFs e Cidades da base.
 * - UFs vêm da tabela "uf" (colunas: iduf, uf)
 * - Cidades vêm da tabela "cidade" (colunas: id, cidade, uf)
 */
export function useUfCidades() {
  const [ufs, setUfs] = useState<UfRow[]>([]);
  const [cidades, setCidades] = useState<CidadeRow[]>([]);
  const [loadingUfs, setLoadingUfs] = useState(false);
  const [loadingCidades, setLoadingCidades] = useState(false);

  /** Carrega todos os UFs */
  const fetchUfs = useCallback(async () => {
    setLoadingUfs(true);
    try {
      const { data, error } = await supabase
        .from("uf")
        .select("iduf, uf")
        .order("uf");
      if (error) throw error;
      setUfs(data || []);
    } catch (err) {
      console.error("Erro ao carregar UFs:", err);
      setUfs([]);
    } finally {
      setLoadingUfs(false);
    }
  }, []);

  /**
   * Carrega todas as cidades do UF informado.
   * Devolve as cidades (caso precise usar diretamente).
   */
  const fetchCidadesByUf = useCallback(async (uf: string) => {
    if (!uf) {
      setCidades([]);
      return [];
    }
    setLoadingCidades(true);
    try {
      const { data, error } = await supabase
        .from("cidade")
        .select("id, cidade, uf")
        .eq("uf", uf)
        .order("cidade");
      if (error) throw error;
      setCidades(data || []);
      return data || [];
    } catch (err) {
      console.error("Erro ao carregar cidades:", err);
      setCidades([]);
      return [];
    } finally {
      setLoadingCidades(false);
    }
  }, []);

  /**
   * Mapa id -> "Cidade - UF" (útil para exibição em listas)
   * Pode ser alimentado com um carregamento amplo quando necessário.
   * Aqui deixo uma função utilitária caso queira popular manualmente.
   */
  const buildCidadeNome = useCallback(
    (rows: CidadeRow[]) =>
      rows.reduce<Record<string, string>>((acc, c) => {
        acc[String(c.id)] = `${c.cidade} - ${c.uf}`;
        return acc;
      }, {}),
    []
  );

  useEffect(() => {
    fetchUfs();
  }, [fetchUfs]);

  return {
    /** dados */
    ufs,
    cidades,
    /** loading flags */
    loadingUfs,
    loadingCidades,
    /** ações */
    fetchUfs,
    fetchCidadesByUf,
    buildCidadeNome,
  };
}
