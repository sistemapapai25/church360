import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface UserData {
  idusuario: string;
  email: string;
  idmembro: string | null;
  permissao: string;
  auth_uid: string;
  nome_membro: string;
  created_at: string;
}

export function useUsers() {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(false);
  const { userProfile } = useAuth();
  const canRead = (userProfile?.permission === 'ADM' || userProfile?.permission === 'OPE');
  const isAdmin = userProfile?.permission === 'ADM';

  const fetchUsers = async () => {
    setLoading(true);
    try {
      // Bloqueia chamada se não tiver permissão
      if (!canRead) {
        toast({
          title: 'Erro ao carregar usuários',
          description: 'Você não tem permissão para visualizar usuários.',
          variant: 'destructive',
        });
        setUsers([]);
        return;
      }

      const { data, error } = await supabase.rpc('list_users');
      if (error) {
        console.error('Erro RPC list_users:', error);
        throw error;
      }
      setUsers(data || []);
    } catch (err) {
      const anyErr = err as any;
      const message =
        (anyErr?.message as string) ||
        (anyErr?.error?.message as string) ||
        (typeof anyErr === 'string' ? anyErr : '') ||
        'Erro desconhecido';

      // Mensagem amigável para erros comuns
      const friendlyMessage =
        /permission denied/i.test(message)
          ? 'Você não tem permissão para visualizar usuários.'
          : /function.*list_users.*not found/i.test(message)
          ? 'Função de listagem não encontrada no banco. Verifique migrações/RPC.'
          : message;

      console.error('Erro ao carregar usuários (detalhes):', anyErr);
      toast({
        title: 'Erro ao carregar usuários',
        description: friendlyMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const createUser = async (email: string, password: string, permissao: string = 'USR', idmembro: string) => {
    try {
      if (!isAdmin) {
        toast({
          title: 'Sem permissão',
          description: 'Apenas administradores podem criar usuários.',
          variant: 'destructive',
        });
        return { success: false, error: 'Sem permissão' };
      }
      // Validações prévias
      if (!idmembro) {
        toast({
          title: 'Dados inválidos',
          description: 'Selecione um membro para criar o usuário.',
          variant: 'destructive',
        });
        return { success: false, error: 'Membro não selecionado' };
      }
      if (!email) {
        toast({
          title: 'Dados inválidos',
          description: 'E-mail do membro é obrigatório.',
          variant: 'destructive',
        });
        return { success: false, error: 'Email ausente' };
      }
      if (!password || password.length < 6) {
        toast({
          title: 'Senha inválida',
          description: 'A senha deve ter ao menos 6 caracteres.',
          variant: 'destructive',
        });
        return { success: false, error: 'Senha fraca' };
      }
      // Checagens locais de duplicidade
      const emailLower = email.toLowerCase();
      const alreadyHasEmail = users.some(u => (u.email || '').toLowerCase() === emailLower);
      if (alreadyHasEmail) {
        toast({
          title: 'Email já cadastrado',
          description: 'Já existe um usuário com este e-mail.',
          variant: 'destructive',
        });
        return { success: false, error: 'Email já cadastrado' };
      }
      const memberHasUser = users.some(u => (u.idmembro || '') === idmembro);
      if (memberHasUser) {
        toast({
          title: 'Membro já possui usuário',
          description: 'Selecione outro membro. Este já tem usuário vinculado.',
          variant: 'destructive',
        });
        return { success: false, error: 'Membro já possui usuário' };
      }
      const { data, error } = await supabase.rpc('create_user_with_profile', {
        p_email: email,
        p_password: password,
        p_permissao: permissao,
        p_idmembro: idmembro
      });

      if (error) throw error;

      toast({
        title: "Usuário criado com sucesso!",
        description: `E-mail: ${email}`,
      });

      // Recarregar lista de usuários
      await fetchUsers();
      return { success: true };
    } catch (err) {
      console.error('Erro ao criar usuário (detalhes):', err);
      const anyErr = err as any;
      const rawMessage =
        (anyErr?.message as string) ||
        (anyErr?.error?.message as string) ||
        (typeof anyErr === 'string' ? anyErr : '') ||
        'Erro ao criar usuário';
      const friendlyMessage =
        /Apenas administradores/i.test(rawMessage)
          ? 'Apenas administradores podem criar usuários.'
          : /Email.*já cadastrado/i.test(rawMessage)
          ? 'Email já cadastrado. Use outro email.'
          : /já possui usuário/i.test(rawMessage)
          ? 'Este membro já possui usuário vinculado.'
          : /permission denied/i.test(rawMessage)
          ? 'Você não tem permissão para criar usuários.'
          : /invalid.*email/i.test(rawMessage)
          ? 'E-mail inválido. Verifique o formato.'
          : /password/i.test(rawMessage)
          ? 'Senha rejeitada. Tente uma senha mais forte.'
          : rawMessage || 'Erro ao criar usuário';
      toast({
        title: 'Erro ao criar usuário',
        description: friendlyMessage,
        variant: 'destructive',
      });
      return { success: false, error: friendlyMessage };
    }
  };

  const resetPassword = async (userId: string | null, email: string, newPassword: string = '123456') => {
    try {
      if (!isAdmin) {
        toast({
          title: 'Sem permissão',
          description: 'Apenas administradores podem resetar senha.',
          variant: 'destructive',
        });
        return { success: false, error: 'Sem permissão' };
      }
      // Verificar se userId é válido
      if (!userId || userId === 'null' || userId === null) {
        throw new Error('Usuário não possui ID de autenticação válido. Entre em contato com o administrador do sistema.');
      }

      console.log('🔄 Resetando senha para usuario ID:', userId);
      
      const { data, error } = await supabase.rpc('reset_user_password', {
        p_user_id: userId,
        p_new_password: newPassword
      });

      if (error) throw error;

      toast({
        title: "Senha resetada com sucesso!",
        description: `Nova senha para ${email}: ${newPassword}`,
      });

      return { success: true };
    } catch (err) {
      console.error('❌ Erro ao resetar senha:', err);
      const message = err instanceof Error ? err.message : 'Erro ao resetar senha';
      toast({
        title: "Erro ao resetar senha",
        description: message,
        variant: "destructive"
      });
      return { success: false, error: message };
    }
  };

  const updateUser = async (idusuario: string, updates: { email?: string; permissao?: string }) => {
    try {
      if (!isAdmin) {
        toast({
          title: 'Sem permissão',
          description: 'Apenas administradores podem atualizar usuários.',
          variant: 'destructive',
        });
        return { success: false, error: 'Sem permissão' };
      }
      const { data, error } = await supabase.rpc('update_user_info' as any, {
        p_idusuario: idusuario,
        p_email: updates.email,
        p_permissao: updates.permissao
      });

      if (error) throw error;

      toast({
        title: "Usuário atualizado com sucesso!",
        description: "As informações do usuário foram atualizadas.",
      });

      // Recarregar lista de usuários
      await fetchUsers();
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro ao atualizar usuário';
      toast({
        title: "Erro ao atualizar usuário",
        description: message,
        variant: "destructive"
      });
      return { success: false, error: message };
    }
  };

  useEffect(() => {
    // Só tenta carregar se permissões já estiverem disponíveis
    if (userProfile) {
      fetchUsers();
    }
  }, [userProfile?.permission]);

  return {
    users,
    loading,
    fetchUsers,
    createUser,
    resetPassword,
    updateUser
  };
}