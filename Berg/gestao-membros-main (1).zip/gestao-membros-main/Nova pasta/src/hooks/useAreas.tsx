import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface Area {
  idarea: string;
  nome: string;
  descricao?: string | null;
  iddepto: string;
  status: string;
  lider1?: string | null;
  lider2?: string | null;
  nome_departamento?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Departamento {
  iddepto: string;
  nome: string;
}

function buildErrorDescription(err: unknown) {
  if (err && typeof err === 'object') {
    const e = err as any;
    const parts = [e.message, e.details, e.hint, e.code].filter(Boolean);
    if (parts.length) return parts.join(' | ');
  }
  return 'Erro desconhecido';
}

export function useAreas() {
  const [areas, setAreas] = useState<Area[]>([]);
  const [departamentos, setDepartamentos] = useState<Departamento[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAreas = async () => {
    setLoading(true);
    try {
      console.log('Buscando áreas ativas...');
      // Áreas ativas - usando .noCache() para evitar problemas de cache
      const { data: areasData, error: areasError } = await supabase
        .from('areas')
        .select('*')
        .eq('status', 'Ativo')
        .order('nome', { ascending: true });

      if (areasError) throw areasError;
      console.log('Áreas encontradas:', areasData);

      // Departamentos (para exibir nome)
      const { data: deptsData, error: deptsError } = await supabase
        .from('departamentos')
        .select('iddepto, nome');

      if (deptsError) throw deptsError;

      const areasWithDeptName =
        areasData?.map((area) => {
          const dept = deptsData?.find((d) => d.iddepto === area.iddepto);
          return { ...area, nome_departamento: dept?.nome } as Area;
        }) || [];

      console.log('Áreas com nomes de departamentos:', areasWithDeptName);
      setAreas(areasWithDeptName);
    } catch (err) {
      toast({
        title: 'Erro ao carregar áreas',
        description: buildErrorDescription(err),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartamentos = async () => {
    try {
      const { data, error } = await supabase
        .from('departamentos')
        .select('iddepto, nome')
        .order('nome', { ascending: true });

      if (error) throw error;
      setDepartamentos(data || []);
    } catch (err) {
      toast({
        title: 'Erro ao carregar departamentos',
        description: buildErrorDescription(err),
        variant: 'destructive',
      });
    }
  };

  const createArea = async (
    nome: string,
    descricao: string,
    iddepto: string,
    lider1?: string | null,
    lider2?: string | null
  ) => {
    try {
      const nomeTrim = (nome || '').trim();
      if (!nomeTrim) {
        toast({ title: 'Informe o nome da área', variant: 'destructive' });
        return { success: false, error: 'Nome obrigatório' };
      }
      if (!iddepto) {
        toast({ title: 'Selecione um departamento', variant: 'destructive' });
        return { success: false, error: 'Departamento obrigatório' };
      }

      const { data, error } = await supabase
        .from('areas')
        .insert({
          nome: nomeTrim,
          descricao: descricao?.trim() || null,
          iddepto,
          status: 'Ativo',
          lider1: lider1 || null,
          lider2: lider2 || null,
        })
        .select('*')
        .single(); // garante retorno da linha inserida

      if (error) throw error;

      toast({
        title: 'Área criada!',
        description: `${data?.nome || nomeTrim} foi criada com sucesso.`,
      });

      await fetchAreas();
      return { success: true };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao criar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const updateArea = async (
    idarea: string,
    nome: string,
    descricao: string,
    iddepto: string,
    lider1?: string | null,
    lider2?: string | null
  ) => {
    try {
      const nomeTrim = (nome || '').trim();
      if (!idarea) return { success: false, error: 'idarea inválido' };
      if (!nomeTrim) {
        toast({ title: 'Informe o nome da área', variant: 'destructive' });
        return { success: false, error: 'Nome obrigatório' };
      }
      if (!iddepto) {
        toast({ title: 'Selecione um departamento', variant: 'destructive' });
        return { success: false, error: 'Departamento obrigatório' };
      }
      
      console.log('Atualizando área:', { idarea, nome: nomeTrim, descricao, iddepto });
      
      // Primeiro, verificamos se a área existe
      const { data: existingArea, error: checkError } = await supabase
        .from('areas')
        .select('*')
        .eq('idarea', idarea)
        .single();
        
      if (checkError) {
        console.error('Erro ao verificar área existente:', checkError);
        throw checkError;
      }
      
      console.log('Área existente antes da atualização:', existingArea);
      
      // Agora atualizamos a área
      const updateData = {
        nome: nomeTrim,
        descricao: descricao?.trim() || null,
        iddepto,
        lider1: lider1 ?? null,
        lider2: lider2 ?? null,
        updated_at: new Date().toISOString(),
      };
      
      console.log('Dados para atualização:', updateData);
      
      const { data, error } = await supabase
        .from('areas')
        .update(updateData)
        .eq('idarea', idarea)
        .select('*');
      
      console.log('Resultado da atualização:', { data, error });

      if (error) throw error;
      
      console.log('Área atualizada com sucesso:', data);

      toast({
        title: 'Área atualizada!',
        description: `${nomeTrim} foi atualizada com sucesso.`,
      });

      // Atualizar o estado local imediatamente
      if (data && data.length > 0) {
        // Encontrar o índice da área atualizada no estado atual
        const updatedAreaIndex = areas.findIndex(a => a.idarea === idarea);
        if (updatedAreaIndex !== -1) {
          // Criar uma cópia do estado atual
          const updatedAreas = [...areas];
          // Atualizar a área específica com os novos dados, garantindo que o nome seja atualizado
          const updatedArea = {
            ...updatedAreas[updatedAreaIndex],
            ...data[0],
            nome: nomeTrim, // Garantir que o nome seja atualizado corretamente
            nome_departamento: updatedAreas[updatedAreaIndex].nome_departamento // Manter o nome do departamento
          };
          updatedAreas[updatedAreaIndex] = updatedArea;
          // Atualizar o estado
          setAreas(updatedAreas);
          console.log('Estado local atualizado com nome:', updatedArea.nome);
        } else {
          console.error('Área não encontrada no estado local:', idarea);
          // Forçar atualização da lista completa
          await fetchAreas();
        }
        return { success: true, data };
      }
      
      // Se não conseguiu atualizar o estado local, forçar atualização da lista de áreas do servidor
      await fetchAreas();
      return { success: true, data };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao atualizar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const deleteArea = async (idarea: string, nome: string) => {
    try {
      if (!idarea) return { success: false, error: 'idarea inválido' };

      // Soft delete (status = Inativo)
      const { error } = await supabase
        .from('areas')
        .update({ status: 'Inativo', updated_at: new Date().toISOString() })
        .eq('idarea', idarea);

      if (error) throw error;

      toast({
        title: 'Área desativada!',
        description: `${nome} foi desativada com sucesso.`,
      });

      await fetchAreas();
      return { success: true };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao desativar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const getAreasByDepartamento = (iddepto: string) =>
    areas.filter((area) => area.iddepto === iddepto);

  useEffect(() => {
    fetchAreas();
    fetchDepartamentos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    areas,
    departamentos,
    loading,
    fetchAreas,
    fetchDepartamentos,
    createArea,
    updateArea,
    deleteArea,
    getAreasByDepartamento,
  };
}
