import { useState, useEffect } from 'react';
import { supabase } from '../integrations/supabase/client';

interface Profissao {
  idprofissao: string;
  profissao: string;
}

export const useProfissoes = () => {
  const [profissoes, setProfissoes] = useState<Profissao[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchProfissoes = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profissao')
        .select('idprofissao, profissao')
        .order('profissao');

      if (error) throw error;
      setProfissoes(data || []);
    } catch (error) {
      console.error('Erro ao carregar profissões:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfissoes();
  }, []);

  const getProfissaoNome = (idprofissao: string | undefined) => {
    if (!idprofissao) return '';
    const profissao = profissoes.find(p => p.idprofissao === idprofissao);
    return profissao?.profissao || idprofissao;
  };

  return { profissoes, loading, getProfissaoNome, fetchProfissoes };
};