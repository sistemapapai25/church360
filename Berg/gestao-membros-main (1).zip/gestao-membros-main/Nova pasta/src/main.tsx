import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Force cache refresh
console.log('App starting with Supabase client...');

const root = document.getElementById("root");
if (!root) throw new Error('Root element not found');

createRoot(root).render(
  <App />
);
