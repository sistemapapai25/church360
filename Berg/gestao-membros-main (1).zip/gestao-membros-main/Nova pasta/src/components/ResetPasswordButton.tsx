import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Mail, RotateCcw } from 'lucide-react';

type Props = {
  /** e-mail já conhecido do usuário (opcional) */
  email?: string;
  /** rota de redirecionamento após resetar a senha */
  redirectPath?: string; // ex: "/reset-password"
};

export default function ResetPasswordButton({ email, redirectPath = '/reset-password' }: Props) {
  const [open, setOpen] = useState(false);
  const [typedEmail, setTypedEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const doReset = async (targetEmail: string) => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(targetEmail, {
        redirectTo: `${window.location.origin}${redirectPath}`,
      });
      if (error) throw error;

      toast({
        title: 'Link enviado',
        description: `Enviamos um e-mail para ${targetEmail} redefinir a senha.`,
      });
      setOpen(false);
      setTypedEmail('');
    } catch (err) {
      toast({
        title: 'Erro ao enviar link',
        description: err instanceof Error ? err.message : 'Erro desconhecido',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClick = () => {
    if (email && email.trim()) {
      doReset(email.trim());
    } else {
      setOpen(true);
    }
  };

  return (
    <>
      <Button onClick={handleClick} disabled={loading} className="bg-gradient-primary">
        <RotateCcw className="w-4 h-4 mr-2" />
        Resetar senha
      </Button>

      {/* Modal para digitar e-mail se não foi passado via props */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Enviar link de redefinição
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="email">E-mail do usuário</Label>
              <Input
                id="email"
                type="email"
                placeholder="usuario@exemplo.com"
                value={typedEmail}
                onChange={(e) => setTypedEmail(e.target.value)}
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setOpen(false)}>
                Cancelar
              </Button>
              <Button
                className="flex-1 bg-gradient-primary"
                disabled={loading || !typedEmail.trim()}
                onClick={() => doReset(typedEmail.trim())}
              >
                Enviar link
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
