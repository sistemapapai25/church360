// src/components/FamilyRelationships.tsx
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Plus, X, Users, Heart } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Membro {
  idmembro: string;
  nome: string;
  apelido?: string;
}

interface Relacionamento {
  id: string;
  membro_id: string;
  parente_id: string;
  tipo_relacionamento: string;
  membro_nome: string;
  parente_nome: string;
}

type ButtonVariant = "default" | "secondary" | "outline" | "ghost" | "link";

interface Props {
  membroId: string;
  membroNome: string;
  /** Quando false, esconde o botão "Adicionar Familiar" (ex.: tela Ver Perfil) */
  allowAdd?: boolean;
  /** ✅ Aparência do botão "Adicionar Familiar" (padrão ghost) */
  addButtonVariant?: ButtonVariant;
  /** ✅ Classes extras para personalização do botão "Adicionar Familiar" */
  addButtonClassName?: string;
}

const TIPOS_RELACIONAMENTO = [
  { value: "pai", label: "Pai" },
  { value: "mae", label: "Mãe" },
  { value: "filho", label: "Filho" },
  { value: "filha", label: "Filha" },
  { value: "irmao", label: "Irmão" },
  { value: "irma", label: "Irmã" },
  { value: "conjuge", label: "Cônjuge" },
  { value: "avo", label: "Avô" },
  { value: "ava", label: "Avó" },
  { value: "neto", label: "Neto" },
  { value: "neta", label: "Neta" },
  { value: "primo", label: "Primo" },
  { value: "prima", label: "Prima" },
  { value: "tio", label: "Tio" },
  { value: "tia", label: "Tia" },
  { value: "sobrinho", label: "Sobrinho" },
  { value: "sobrinha", label: "Sobrinha" },
];

export default function FamilyRelationships({
  membroId,
  membroNome,
  allowAdd = true,
  addButtonVariant = "ghost",
  addButtonClassName = "text-primary/90 hover:text-primary px-0",
}: Props) {
  const [relacionamentos, setRelacionamentos] = useState<Relacionamento[]>([]);
  const [membros, setMembros] = useState<Membro[]>([]);
  const [loading, setLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMembro, setSelectedMembro] = useState<string>("");
  const [selectedTipo, setSelectedTipo] = useState<string>("");

  useEffect(() => {
    // Limpa os estados quando o componente é desmontado ou quando membroId muda
    setRelacionamentos([]);
    setMembros([]);
    setLoading(true);
    
    // Busca os dados apenas se houver um membroId válido
    if (membroId) {
      fetchRelacionamentos();
      fetchMembros();
    } else {
      setLoading(false); // Desativa o loading se não houver membroId
    }

    // Função de limpeza quando o componente é desmontado
    return () => {
      setRelacionamentos([]);
      setMembros([]);
      setLoading(false);
    };
  }, [membroId]);

  const fetchRelacionamentos = async () => {
    if (!membroId) return; // Não busca se não tiver membroId
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("relacionamentos_familiares")
        .select(
          `
          id,
          membro_id,
          parente_id,
          tipo_relacionamento,
          parente:parente_id ( nome )
        `
        )
        .eq("membro_id", membroId);

      if (error) throw error;

      const relacionamentosFormatados = (data || []).map((rel) => ({
        id: rel.id,
        membro_id: rel.membro_id,
        parente_id: rel.parente_id,
        tipo_relacionamento: rel.tipo_relacionamento,
        membro_nome: membroNome,
        parente_nome: (rel as any).parente?.nome || "Nome não encontrado",
      }));

      setRelacionamentos(relacionamentosFormatados);
    } catch (err) {
      console.error('Erro ao carregar relacionamentos:', err);
      toast({
        title: "Erro ao carregar relacionamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMembros = async () => {
    try {
      const { data, error } = await supabase
        .from("membros")
        .select("idmembro, nome, apelido")
        .eq("status", "Ativo")
        .order("nome");

      if (error) throw error;
      setMembros(data || []);
    } catch (err) {
      console.error("Erro ao carregar membros:", err);
    }
  };

  const handleAddRelacionamento = async () => {
    if (!selectedMembro || !selectedTipo) {
      toast({
        title: "Campos obrigatórios",
        description:
          "Por favor, selecione um membro e o tipo de relacionamento",
        variant: "destructive",
      });
      return;
    }

    try {
      const membroSelecionado = membros.find(
        (m) => m.idmembro === selectedMembro
      );
      if (!membroSelecionado) return;

      // Relacionamento principal
      const { error: error1 } = await supabase
        .from("relacionamentos_familiares")
        .insert({
          membro_id: membroId,
          parente_id: selectedMembro,
          tipo_relacionamento: selectedTipo,
        });

      if (error1) throw error1;

      // Sexo do membro atual => define relacionamento inverso
      const { data: membroAtualData } = await supabase
        .from("membros")
        .select("sexo")
        .eq("idmembro", membroId)
        .single();

      const tipoInverso = getTipoInverso(
        selectedTipo,
        membroAtualData?.sexo || "M"
      );
      if (tipoInverso) {
        const { error: error2 } = await supabase
          .from("relacionamentos_familiares")
          .insert({
            membro_id: selectedMembro,
            parente_id: membroId,
            tipo_relacionamento: tipoInverso,
          });

        if (error2 && !error2.message.includes("duplicate")) {
          console.warn("Erro ao criar relacionamento inverso:", error2);
        }
      }

      toast({
        title: "Relacionamento adicionado!",
        description: `${membroSelecionado.nome} foi adicionado como ${TIPOS_RELACIONAMENTO.find(
          (t) => t.value === selectedTipo
        )?.label.toLowerCase()}`,
      });

      setIsDialogOpen(false);
      setSelectedMembro("");
      setSelectedTipo("");
      setSearchTerm("");
      fetchRelacionamentos();
    } catch (err) {
      toast({
        title: "Erro ao adicionar relacionamento",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  };

  const getTipoInverso = (tipo: string, sexoParente: string): string | null => {
    const inversoes: { [key: string]: { [sex: string]: string } } = {
      pai: { M: "filho", F: "filha" },
      mae: { M: "filho", F: "filha" },
      filho: { M: "pai", F: "mae" },
      filha: { M: "pai", F: "mae" },
      irmao: { M: "irmao", F: "irma" },
      irma: { M: "irmao", F: "irma" },
      conjuge: { M: "conjuge", F: "conjuge" },
      avo: { M: "neto", F: "neta" },
      ava: { M: "neto", F: "neta" },
      neto: { M: "avo", F: "ava" },
      neta: { M: "avo", F: "ava" },
      primo: { M: "primo", F: "prima" },
      prima: { M: "primo", F: "prima" },
      tio: { M: "sobrinho", F: "sobrinha" },
      tia: { M: "sobrinho", F: "sobrinha" },
      sobrinho: { M: "tio", F: "tia" },
      sobrinha: { M: "tio", F: "tia" },
    };

    const inverseOptions = inversoes[tipo];
    if (!inverseOptions) return null;

    return inverseOptions[sexoParente] || null;
  };

  const handleRemoveRelacionamento = async (
    relacionamento: Relacionamento
  ) => {
    try {
      // Remove principal
      const { error: error1 } = await supabase
        .from("relacionamentos_familiares")
        .delete()
        .eq("id", relacionamento.id);

      if (error1) throw error1;

      // Sexo do membro atual => remove inverso (se existir)
      const { data: membroAtualData } = await supabase
        .from("membros")
        .select("sexo")
        .eq("idmembro", membroId)
        .single();

      const tipoInverso = getTipoInverso(
        relacionamento.tipo_relacionamento,
        membroAtualData?.sexo || "M"
      );
      if (tipoInverso) {
        await supabase
          .from("relacionamentos_familiares")
          .delete()
          .eq("membro_id", relacionamento.parente_id)
          .eq("parente_id", relacionamento.membro_id)
          .eq("tipo_relacionamento", tipoInverso);
      }

      toast({
        title: "Relacionamento removido!",
        description: `${relacionamento.parente_nome} foi removido dos familiares`,
      });

      fetchRelacionamentos();
    } catch (err) {
      toast({
        title: "Erro ao remover relacionamento",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  };

  const filteredMembros = membros.filter(
    (membro) =>
      membro.idmembro !== membroId &&
      (membro.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (membro.apelido &&
          membro.apelido.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  return (
    <Card className="bg-gradient-card border-border/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-primary" />
            Familiares
          </CardTitle>

          {/* Só mostra se permitido */}
          {allowAdd && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                {/* ✅ Aparência diferenciada do botão */}
                <Button
                  size="sm"
                  variant={addButtonVariant}
                  className={`gap-2 h-8 ${addButtonClassName}`}
                  title="Adicionar familiar"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Familiar
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Adicionar Familiar</DialogTitle>
                </DialogHeader>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="search">Buscar Membro</Label>
                    <Input
                      id="search"
                      placeholder="Digite o nome do membro..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  {searchTerm && (
                    <div className="max-h-48 overflow-y-auto border rounded-md">
                      {filteredMembros.map((membro) => (
                        <button
                          key={membro.idmembro}
                          className={`w-full text-left p-3 hover:bg-muted/50 border-b border-border/30 ${
                            selectedMembro === membro.idmembro ? "bg-primary/10" : ""
                          }`}
                          onClick={() => {
                            setSelectedMembro(membro.idmembro);
                            setSearchTerm(membro.nome);
                          }}
                        >
                          <div className="font-medium">{membro.nome}</div>
                          {membro.apelido && (
                            <div className="text-sm text-muted-foreground">
                              "{membro.apelido}"
                            </div>
                          )}
                        </button>
                      ))}
                      {filteredMembros.length === 0 && (
                        <div className="p-3 text-center text-muted-foreground">
                          Nenhum membro encontrado
                        </div>
                      )}
                    </div>
                  )}

                  <div>
                    <Label htmlFor="tipo">Tipo de Relacionamento</Label>
                    <Select value={selectedTipo} onValueChange={setSelectedTipo}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o relacionamento" />
                      </SelectTrigger>
                      <SelectContent>
                        {TIPOS_RELACIONAMENTO.map((tipo) => (
                          <SelectItem key={tipo.value} value={tipo.value}>
                            {tipo.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsDialogOpen(false);
                        setSelectedMembro("");
                        setSelectedTipo("");
                        setSearchTerm("");
                      }}
                    >
                      Cancelar
                    </Button>
                    <Button onClick={handleAddRelacionamento}>Adicionar</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>

      <CardContent>
        {loading ? (
          <div className="text-center py-4">Carregando...</div>
        ) : relacionamentos.length === 0 ? (
          <div className="text-center text-muted-foreground py-4">
            <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
            Nenhum familiar cadastrado
          </div>
        ) : (
          <div className="space-y-3">
            {relacionamentos.map((rel) => (
              <div
                key={rel.id}
                className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
              >
                <div>
                  <div className="font-medium">{rel.parente_nome}</div>
                  <div className="text-sm text-muted-foreground">
                    {TIPOS_RELACIONAMENTO.find(
                      (t) => t.value === rel.tipo_relacionamento
                    )?.label}
                  </div>
                </div>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                      <X className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remover Familiar</AlertDialogTitle>
                      <AlertDialogDescription>
                        Tem certeza que deseja remover {rel.parente_nome} da
                        lista de familiares?
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => handleRemoveRelacionamento(rel)}
                      >
                        Remover
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
