// src/components/TiposEventosManagement.tsx
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Trash2, Plus } from "lucide-react";

/** ✅ Ajuste de tipos: ambas as chaves são obrigatórias no INSERT */
type EventoInsert = {
  ideventoig: string;
  evento: string;
};

type EventoRow = {
  ideventoig: string;
  evento: string;
  // outras colunas podem existir, mas não são necessárias aqui
  [key: string]: any;
};

function pickEventoLabel(row: any) {
  return row?.evento || row?.nome || row?.titulo || row?.descricao || "Evento";
}

/** ✅ Cria com o shape EXATO exigido pela tabela (ideventoig + evento) */
async function addEventoIgreja(nome: string) {
  try {
    const payload: EventoInsert = {
      ideventoig: crypto.randomUUID(),
      evento: nome.trim(),
    };

    const { error } = await supabase.from("eventos_igreja").insert(payload);
    if (error) throw error;

    return { ok: true, id: payload.ideventoig };
  } catch (e: any) {
    return { ok: false, err: e?.message || "Falha ao inserir em 'eventos_igreja'." };
  }
}

export default function TiposEventosManagement() {
  const [itens, setItens] = useState<EventoRow[]>([]);
  const [nome, setNome] = useState("");
  const [loading, setLoading] = useState(false);

  const carregar = async () => {
    const { data, error } = await supabase
      .from("eventos_igreja")
      .select("*")
      .order("evento", { ascending: true });

    if (error) {
      toast({
        title: "Erro ao carregar",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setItens((data as EventoRow[]) || []);
  };

  const salvar = async () => {
    if (!nome.trim()) return;
    setLoading(true);
    const res = await addEventoIgreja(nome.trim());
    setLoading(false);

    if (!res.ok) {
      toast({
        title: "Não foi possível criar",
        description: res.err || "Verifique o esquema da tabela 'eventos_igreja'.",
        variant: "destructive",
      });
      return;
    }

    setNome("");
    await carregar();
    toast({ title: "Tipo de evento criado!" });
  };

  const excluir = async (row: EventoRow) => {
    const { error } = await supabase
      .from("eventos_igreja")
      .delete()
      .eq("ideventoig", row.ideventoig);

    if (error) {
      toast({
        title: "Erro ao excluir",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    await carregar();
    toast({ title: "Excluído!" });
  };

  useEffect(() => {
    carregar();
  }, []);

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <Label>Nome do tipo de evento</Label>
            <Input
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex.: Culto, Vigília, Reunião..."
            />
          </div>
          <div className="flex items-end">
            <Button onClick={salvar} disabled={loading} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              {loading ? "Salvando..." : "Adicionar"}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-3">
        <div className="divide-y">
          {(itens || []).map((row) => (
            <div key={row.ideventoig} className="flex items-center justify-between py-2">
              <div className="font-medium">{pickEventoLabel(row)}</div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => excluir(row)}
                title="Excluir"
              >
                <Trash2 className="w-4 h-4 text-red-600" />
              </Button>
            </div>
          ))}
          {itens.length === 0 && (
            <div className="py-4 text-sm text-muted-foreground">Sem registros.</div>
          )}
        </div>
      </Card>
    </div>
  );
}
