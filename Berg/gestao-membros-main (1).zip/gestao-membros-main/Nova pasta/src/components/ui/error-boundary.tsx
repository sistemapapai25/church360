import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Button } from './button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './card';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  isConnectionError: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    isConnectionError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    const isConnectionError = error.message.toLowerCase().includes('connection') ||
      error.message.toLowerCase().includes('network') ||
      error.message.toLowerCase().includes('offline');

    return { 
      hasError: true, 
      error,
      isConnectionError 
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Erro na aplicação:', error, errorInfo);
  }

  private handleReload = () => {
    this.setState({ hasError: false, error: null, isConnectionError: false });
    window.location.reload();
  };

  private handleRetry = () => {
    this.setState({ hasError: false, error: null, isConnectionError: false });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center min-h-screen p-4 bg-background">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>
                {this.state.isConnectionError ? 
                  'Erro de Conexão' : 
                  'Ops! Algo deu errado'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {this.state.isConnectionError ?
                  'Não foi possível conectar ao servidor. Verifique sua conexão com a internet.' :
                  'Ocorreu um erro inesperado. Por favor, tente novamente.'}
              </p>
              {this.state.error && !this.state.isConnectionError && (
                <pre className="text-xs bg-muted p-2 rounded overflow-auto max-h-32">
                  {this.state.error.toString()}
                </pre>
              )}
            </CardContent>
            <CardFooter className="flex gap-2">
              <Button 
                onClick={this.handleRetry} 
                variant="outline"
                className="w-full"
              >
                Tentar novamente
              </Button>
              <Button 
                onClick={this.handleReload} 
                className="w-full"
              >
                Recarregar página
              </Button>
            </CardFooter>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;