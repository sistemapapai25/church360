// src/components/PerfilMembro.tsx
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { calculateAge, formatDate, getImageUrl } from "@/lib/utils";
import LiderancaInfo from "@/components/LiderancaInfo";
import FamilyRelationships from "@/components/FamilyRelationships";
import { Mail, Phone, Calendar, Building, User, MapPin, ExternalLink, AlertCircle } from "lucide-react";

type Status = "Ativo" | "Inativo";

interface Member {
  idmembro: string;
  nome: string;
  apelido?: string;
  email?: string;
  telefone?: string;
  nascimento?: string;
  sexo?: string;
  cpf?: string | null;
  cep?: string | null;
  endereco?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  uf?: string | null;
  profissao?: string | null;
  estado_civil?: string | null;
  data_casamento?: string | null;
  conjuge_id?: string | null;
  tipo_membro?: string | null;
  status: Status;
  iddepto?: string | null;
  foto?: string | null;
}

const normalizeMember = (m: any): Member => ({
  idmembro: m.idmembro,
  nome: m.nome,
  apelido: m.apelido ?? undefined,
  email: m.email ?? undefined,
  telefone: m.telefone ?? undefined,
  nascimento: m.nascimento ?? undefined,
  sexo: m.sexo ?? undefined,
  cpf: m.cpf ?? null,
  cep: m.cep ?? null,
  endereco: m.endereco ?? null,
  complemento: m.complemento ?? null,
  bairro: m.bairro ?? null,
  cidade: m.cidade ?? null,
  uf: m.uf ?? null,
  profissao: m.profissao ?? null,
  estado_civil: m.estado_civil ?? null,
  data_casamento: m.data_casamento ?? null,
  conjuge_id: m.conjuge_id ?? null,
  tipo_membro: m.tipo_membro ?? null,
  status: m.status as Status,
  iddepto: m.iddepto ?? null,
  foto: m.foto ?? null,
});

interface Props {
  user: { email: string; permission: string; memberName?: string };
}

export default function PerfilMembro({ user }: Props) {
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [cidadeNamesCache, setCidadeNamesCache] = useState<Record<string, string>>({});
  const [emailCheckDone, setEmailCheckDone] = useState(false);
  const [emailNotFound, setEmailNotFound] = useState(false);
  

  // Auto-seleciona o membro pelo email do usuário logado
  useEffect(() => {
    const fetchByEmail = async () => {
      if (!user?.email) return;
      const { data, error } = await supabase
        .from("membros")
        .select("*")
        .eq("email", user.email)
        .limit(1);
      if (!error) {
        setEmailCheckDone(true);
        if (data && data.length > 0) {
          const m = normalizeMember(data[0]);
          setSelectedMember(m);
          setEmailNotFound(false);
        } else {
          setEmailNotFound(true);
        }
      }
    };
    fetchByEmail();
  }, [user?.email]);

  useEffect(() => {
    const loadAllCidades = async () => {
      try {
        const { data, error } = await supabase
          .from("cidade")
          .select("id, cidade")
          .order("cidade");
        if (error) throw error;
        const cache = (data || []).reduce<Record<string, string>>((acc, c) => {
          acc[c.id] = c.cidade;
          return acc;
        }, {});
        setCidadeNamesCache(cache);
      } catch (err) {
        console.warn("Erro ao carregar cidades", err);
      }
    };
    loadAllCidades();
  }, []);

  const getCidadeNomeSync = useCallback((cidadeValue?: string | null) => {
    if (!cidadeValue) return "";
    if (cidadeValue.startsWith("MUN") && cidadeNamesCache[cidadeValue]) {
      return cidadeNamesCache[cidadeValue];
    }
    return cidadeValue;
  }, [cidadeNamesCache]);

  

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Perfil do Membro
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          

          {!selectedMember && (
            emailCheckDone && emailNotFound ? (
              <div className="mt-6 p-4 border border-border/50 rounded-md bg-muted/30">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Email de login não vinculado a nenhum membro.</p>
                    <p className="text-sm text-muted-foreground">Email: {user.email}</p>
                    <p className="text-sm text-muted-foreground mt-1">Atualize o cadastro na tela "Membros".</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground mt-6">Nenhum membro selecionado.</div>
            )
          )}

          {selectedMember && (
            <div className="space-y-6 mt-6">
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <div className="w-20 h-20 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden">
                  {(() => {
                    const imageUrl = getImageUrl(selectedMember.foto);
                    return imageUrl ? (
                      <img
                        src={imageUrl}
                        alt={selectedMember.nome}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          console.warn("Erro ao carregar imagem:", imageUrl);
                          e.currentTarget.src = "/placeholder.svg";
                        }}
                      />
                    ) : (
                      <User className="w-10 h-10 text-muted-foreground" />
                    );
                  })()}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{selectedMember.nome}</h3>
                  {selectedMember.apelido && (
                    <p className="text-muted-foreground">"{selectedMember.apelido}"</p>
                  )}
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={selectedMember.status === "Ativo" ? "default" : "secondary"}>
                      {selectedMember.status}
                    </Badge>
                    {selectedMember.tipo_membro && (
                      <Badge variant="outline">{selectedMember.tipo_membro}</Badge>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Informações Pessoais</h4>
                  {selectedMember.email && (
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <span>{selectedMember.email}</span>
                    </div>
                  )}
                  {selectedMember.telefone && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <span>{selectedMember.telefone}</span>
                    </div>
                  )}
                  {selectedMember.nascimento && (
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>
                        {formatDate(selectedMember.nascimento)} ({calculateAge(selectedMember.nascimento)})
                      </span>
                    </div>
                  )}
                  {selectedMember.sexo && (
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span>{selectedMember.sexo}</span>
                    </div>
                  )}
                  {selectedMember.profissao && (
                    <div className="flex items-center gap-3">
                      <Building className="w-4 h-4 text-muted-foreground" />
                      <span>{selectedMember.profissao}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Endereço</h4>
                  {(selectedMember.endereco || selectedMember.bairro || selectedMember.cidade || selectedMember.uf) && (
                    <div className="bg-muted/30 p-4 rounded-lg space-y-2">
                      {selectedMember.cep && <p><strong>CEP:</strong> {selectedMember.cep}</p>}
                      {selectedMember.endereco && <p><strong>Endereço:</strong> {selectedMember.endereco}</p>}
                      {selectedMember.complemento && <p><strong>Complemento:</strong> {selectedMember.complemento}</p>}
                      {selectedMember.bairro && <p><strong>Bairro:</strong> {selectedMember.bairro}</p>}
                      <div className="flex gap-4">
                        {selectedMember.cidade && <p><strong>Cidade:</strong> {getCidadeNomeSync(selectedMember.cidade)}</p>}
                        {selectedMember.uf && <p><strong>UF:</strong> {selectedMember.uf}</p>}
                      </div>
                      {(selectedMember.endereco || selectedMember.bairro || selectedMember.cidade || selectedMember.uf) && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-3 gap-2"
                          onClick={() => {
                            const endereco = `${selectedMember.endereco || ""}, ${selectedMember.bairro || ""}, ${getCidadeNomeSync(selectedMember.cidade) || ""}, ${selectedMember.uf || ""}`
                              .replace(/,\s*,/g, ",")
                              .replace(/^,\s*|,\s*$/g, "");
                            window.open(`https://www.google.com/maps/search/${encodeURIComponent(endereco)}`, "_blank");
                          }}
                        >
                          <MapPin className="w-4 h-4" />
                          Ver no Google Maps
                          <ExternalLink className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <LiderancaInfo membroId={selectedMember.idmembro} />

              <div className="mt-6">
                <FamilyRelationships membroId={selectedMember.idmembro} membroNome={selectedMember.nome} allowAdd={false} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}