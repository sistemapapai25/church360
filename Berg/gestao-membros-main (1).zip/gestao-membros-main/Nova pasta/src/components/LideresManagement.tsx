// src/pages/LideresManagement.tsx
import { useState, useEffect, useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  Building,
  Crown,
  Phone,
  Mail,
  MapPin,
  Edit,
  Search,
  X,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { getImageUrl } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

/** Tipagens */
interface LiderAgrupado {
  idmembro: string;
  nome_membro: string;
  apelido_membro?: string;
  email_membro?: string;
  telefone_membro?: string;
  foto_membro?: string;
  departamentos: Array<{
    iddepto: string;
    nome_departamento: string;
    idlider: string;
    idarea?: string | null;
    nome_area?: string;
    status: string; // status do vínculo do líder com o departamento
  }>;
}
interface Member {
  idmembro: string;
  nome: string;
  apelido?: string;
  status: string;
  email?: string;
  telefone?: string;
  foto?: string;
}
interface Department { iddepto: string; nome: string; }
interface Area { 
  idarea: string; 
  nome: string; 
  iddepto: string; 
  status?: string; 
  lider1?: string | null; 
  lider2?: string | null; 
}
interface User { email: string; permission: string; }
interface Props { user: User; }

const NONE = "none";

/** Componente */
export default function LideresManagement({ user }: Props) {
  const [lideres, setLideres] = useState<LiderAgrupado[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [loading, setLoading] = useState(false);
  const [allowedDeptos, setAllowedDeptos] = useState<string[]>([]);

  // Diálogos
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Edição
  const [editingLider, setEditingLider] = useState<{ idlider: string; idmembro: string; iddepto: string; idarea?: string | null } | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const [selectedArea, setSelectedArea] = useState<string>(NONE);
  const [selectedStatus, setSelectedStatus] = useState<"Ativo" | "Inativo" | "Desligado">("Ativo");

  // Busca e filtro de status
  const [searchTerm, setSearchTerm] = useState("");
  const [showInactive, setShowInactive] = useState(false); // <- toggle para mostrar inativos/desligados

  useEffect(() => {
    fetchLideres();
    fetchMembers();
    fetchDepartments();
    fetchAreas();
  }, []);

  // Define departamentos permitidos quando usuário é MONITOR (MTR)
  useEffect(() => {
    const resolveAllowedDepartments = async () => {
      if (user.permission !== "MTR") {
        setAllowedDeptos([]);
        return;
      }

      if (!user.email) {
        setAllowedDeptos([]);
        return;
      }

      try {
        const { data: membroData } = await supabase
          .from("membros")
          .select("idmembro")
          .eq("email", user.email)
          .limit(1);

        const idmembro = membroData && membroData[0]?.idmembro;
        if (!idmembro) {
          setAllowedDeptos([]);
          return;
        }

        const { data: liderancas } = await supabase
          .from("lideres")
          .select("iddepto, status")
          .eq("idmembro", idmembro)
          .eq("status", "Ativo");

        const deptos = (liderancas || [])
          .map((l: any) => String(l.iddepto))
          .filter(Boolean);

        setAllowedDeptos(Array.from(new Set(deptos)));
      } catch (err) {
        console.warn("Falha ao resolver departamentos do monitor:", err);
        setAllowedDeptos([]);
      }
    };

    resolveAllowedDepartments();
  }, [user.permission, user.email]);

  /** Carregar líderes + nomes relacionais (JOIN direto) */
  const fetchLideres = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("lideres")
        .select(`
          *,
          membros:idmembro ( nome, apelido, email, telefone, foto ),
          departamentos:iddepto ( nome ),
          areas:idarea ( idarea, nome, status, iddepto )
        `)
        .order("idlider");

      if (error) throw error;

      const map = new Map<string, LiderAgrupado>();
      (data || []).forEach((l: any) => {
        const membroId = l.idmembro;
        const deptoItem = {
          iddepto: l.iddepto,
          nome_departamento: l.departamentos?.nome || "Sem departamento",
          idlider: l.idlider,
          idarea: l.idarea,
          nome_area: l.areas?.nome,
          status: l.status,
        };

        if (map.has(membroId)) {
          map.get(membroId)!.departamentos.push(deptoItem);
        } else {
          map.set(membroId, {
            idmembro: l.idmembro,
            nome_membro: l.membros?.nome || "Nome não encontrado",
            apelido_membro: l.membros?.apelido,
            email_membro: l.membros?.email,
            telefone_membro: l.membros?.telefone,
            foto_membro: l.membros?.foto,
            departamentos: [deptoItem],
          });
        }
      });

      setLideres(
        Array.from(map.values()).sort((a, b) =>
          a.nome_membro.localeCompare(b.nome_membro)
        )
      );
    } catch (err) {
      toast({
        title: "Erro ao carregar líderes",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMembers = async () => {
    const { data } = await supabase
      .from("membros")
      .select("idmembro, nome, apelido, status, email, telefone, foto")
      .eq("status", "Ativo")
      .order("nome");
    setMembers(data || []);
  };

  const fetchDepartments = async () => {
    const { data } = await supabase.from("departamentos").select("*").order("nome");
    setDepartments(data || []);
  };

  const fetchAreas = async () => {
    const { data } = await supabase
      .from("areas")
      .select("idarea, nome, iddepto, status")
      .eq("status", "Ativo")
      .order("nome");
    setAreas(data || []);
  };

  const getAreasByDepartment = (iddepto: string) => areas.filter((a) => a.iddepto === iddepto);

  /** Salvar edição */
  const handleEditLider = async () => {
    if (!editingLider || !selectedDepartment) {
      toast({ title: "Campos obrigatórios", description: "Selecione um departamento.", variant: "destructive" });
      return;
    }
    try {
      const { error } = await supabase
        .from("lideres")
        .update({
          iddepto: selectedDepartment,
          idarea: selectedArea === NONE ? null : selectedArea,
          status: selectedStatus,
        })
        .eq("idlider", editingLider.idlider);

      if (error) throw error;

      toast({ title: "Líder alterado com sucesso!", description: "As informações do líder foram atualizadas." });
      setIsEditDialogOpen(false);
      setEditingLider(null);
      setSelectedDepartment("");
      setSelectedArea(NONE);
      fetchLideres();
    } catch (err) {
      toast({ title: "Erro ao alterar líder", description: err instanceof Error ? err.message : "Erro desconhecido", variant: "destructive" });
    }
  };

  /** Abrir diálogo Alterar */
  const openEditDialog = async (lider: LiderAgrupado, departamento: { iddepto: string; idlider: string; idarea?: string | null; status: string }) => {
    const currentDept = departamento.iddepto;
    const currentArea = departamento.idarea ?? null;

    setEditingLider({
      idlider: departamento.idlider,
      idmembro: lider.idmembro,
      iddepto: currentDept,
      idarea: currentArea,
    });
    setSelectedDepartment(currentDept);
    setSelectedArea(currentArea ?? NONE);
    setSelectedStatus((departamento.status as any) || "Ativo");
    setIsEditDialogOpen(true);
  };

  /** Imagem pública via util centralizado */

  // --------- FILTROS (status + busca) ----------
  // 1) filtra departamentos visíveis conforme o toggle showInactive
  const leadersWithVisibleDepts = useMemo(() => {
    const byStatus = lideres
      .map((l) => ({
        ...l,
        departamentos: l.departamentos.filter((d) =>
          showInactive ? true : d.status === "Ativo"
        ),
      }));

    if (user.permission === "MTR") {
      const allowed = new Set(allowedDeptos);
      const byAllowed = byStatus
        .map((l) => ({
          ...l,
          departamentos: l.departamentos.filter((d) =>
            allowed.size === 0 ? false : allowed.has(String(d.iddepto))
          ),
        }))
        .filter((l) => l.departamentos.length > 0);
      return byAllowed;
    }

    return byStatus.filter((l) => l.departamentos.length > 0);
  }, [lideres, showInactive, user.permission, allowedDeptos]);

  // 2) aplica a busca em cima da lista já filtrada por status
  const filtered = useMemo(() => {
    const q = searchTerm.toLowerCase();
    if (!q) return leadersWithVisibleDepts;
    return leadersWithVisibleDepts.filter(
      (l) =>
        l.nome_membro.toLowerCase().includes(q) ||
        (l.apelido_membro && l.apelido_membro.toLowerCase().includes(q)) ||
        l.departamentos.some((d) => d.nome_departamento.toLowerCase().includes(q))
    );
  }, [leadersWithVisibleDepts, searchTerm]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Gestão de Líderes
              </CardTitle>

              {/* Toggle mostrar inativos/desligados */}
              <div className="flex items-center gap-2">
                <Switch id="show-inactive" checked={showInactive} onCheckedChange={setShowInactive} />
                <Label htmlFor="show-inactive" className="text-sm">
                  Mostrar inativos/desligados
                </Label>
              </div>
            </div>

            {/* Modal de Edição */}
            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Alterar Líder</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Departamento</label>
                    <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um departamento" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => (
                          <SelectItem key={d.iddepto} value={d.iddepto}>
                            {d.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedDepartment && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Área</label>
                      <Select value={selectedArea} onValueChange={setSelectedArea}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma área" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={NONE}>Nenhuma área</SelectItem>
                          {getAreasByDepartment(selectedDepartment).map((a) => (
                            <SelectItem key={a.idarea} value={a.idarea}>
                              {a.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Status</label>
                    <Select value={selectedStatus} onValueChange={(v) => setSelectedStatus(v as any)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Ativo">Ativo</SelectItem>
                        <SelectItem value="Inativo">Inativo</SelectItem>
                        <SelectItem value="Desligado">Desligado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleEditLider} className="bg-gradient-primary">
                      Alterar Líder
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>

        <CardContent>
          {/* Busca */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar líder por nome ou departamento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-20 w-full rounded-lg" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">
                {searchTerm ? "Nenhum líder encontrado" : "Nenhum líder encontrado com os filtros atuais"}
              </p>
              <p className="text-sm">Ajuste a busca ou ative “Mostrar inativos/desligados”.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {filtered.map((lider) => (
                <Card key={lider.idmembro} className="border border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      {/* Foto */}
                      <div className="flex-shrink-0">
                        <div className="w-16 h-16 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden relative">
                          {(() => {
                            const img = getImageUrl(lider.foto_membro);
                            return img ? (
                              <img 
                                src={img} 
                                alt={lider.nome_membro} 
                                className="w-full h-full object-cover" 
                                onError={(e) => {
                                  console.warn('Erro ao carregar imagem:', img);
                                  e.currentTarget.src = '/placeholder.svg';
                                }}
                              />
                            ) : (
                              <div className="w-full h-full bg-gradient-primary rounded-full flex items-center justify-center">
                                <Crown className="w-8 h-8 text-primary-foreground" />
                              </div>
                            );
                          })()}
                        </div>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-2">
                          <div>
                            <h3 className="font-semibold text-lg leading-tight">{lider.nome_membro}</h3>
                            {lider.apelido_membro && (
                              <p className="text-sm text-muted-foreground">"{lider.apelido_membro}"</p>
                            )}
                          </div>
                          <Badge variant="default" className="text-xs w-fit">Líder</Badge>
                        </div>

                        <div className="space-y-3">
                          <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                            <Building className="w-3 h-3" /> Liderança
                          </h4>

                          {lider.departamentos.map((dept) => (
                            <div key={`${dept.idlider}-${dept.iddepto}`} className="bg-muted/20 border border-border/50 p-3 rounded-lg">
                              <div className="flex items-center justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <Building className="w-4 h-4 text-primary" />
                                    <span className="font-medium text-sm">{dept.nome_departamento}</span>
                                    {dept.status !== "Ativo" && (
                                      <Badge variant="outline" className="text-[10px] uppercase">
                                        {dept.status}
                                      </Badge>
                                    )}
                                  </div>
                                  {dept.nome_area && (
                                    <div className="flex items-center gap-2 ml-6 text-xs text-muted-foreground">
                                      <MapPin className="w-3 h-3" />
                                      <span>
                                        Área: <span className="font-medium">{dept.nome_area}</span>
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {user.permission === "ADM" && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => openEditDialog(lider, dept)}
                                    className="h-7 px-2"
                                  >
                                    <Edit className="w-3 h-3" />
                                  </Button>
                                )}
                              </div>
                            </div>
                          ))}

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                            {lider.email_membro && (
                              <div className="flex items-center gap-2">
                                <Mail className="w-3 h-3 flex-shrink-0" />
                                <span className="truncate">{lider.email_membro}</span>
                              </div>
                            )}
                            {lider.telefone_membro && (
                              <div className="flex items-center gap-2">
                                <Phone className="w-3 h-3 flex-shrink-0" />
                                <span>{lider.telefone_membro}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
