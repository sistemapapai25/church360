import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getImageUrl } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Building, User, Users, MapPin, Search, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Departamento {
  iddepto: string;
  nome: string;
  liderdepto1?: string;
  liderdepto2?: string;
}

interface LiderInfo {
  idmembro: string;
  nome: string;
  apelido?: string;
  foto?: string;
}

interface MembroDepartamento {
  idmembro: string;
  nome: string;
  apelido?: string;
  foto?: string;
  idarea?: string;
}

interface Area {
  idarea: string;
  nome: string;
  descricao?: string;
  status: string;
  iddepto: string;
}

export default function DepartamentosManagement() {
  const [departamentos, setDepartamentos] = useState<Departamento[]>([]);
  const [lideres, setLideres] = useState<LiderInfo[]>([]);
  const [membrosDepartamento, setMembrosDepartamento] = useState<Record<string, MembroDepartamento[]>>({});
  const [areasDepartamento, setAreasDepartamento] = useState<Record<string, Area[]>>({});
  const [lideresPorArea, setLideresPorArea] = useState<Record<string, LiderInfo[]>>({});
  const [loading, setLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDepto, setEditingDepto] = useState<Departamento | null>(null);
  const [formData, setFormData] = useState({ nome: "", liderdepto1: "", liderdepto2: "" });

  const [searchTerm, setSearchTerm] = useState("");

  const fetchDepartamentos = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('departamentos').select('*').order('nome');
      if (error) throw error;
      setDepartamentos(data || []);
    } catch (err) {
      toast({
        title: "Erro ao carregar departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchLideres = async () => {
    try {
      const { data, error } = await supabase
        .from('membros')
        .select('idmembro, nome, apelido, foto')
        .eq('status', 'Ativo');
      if (error) throw error;
      setLideres(data || []);
    } catch (err) {
      toast({
        title: "Erro ao carregar líderes",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const fetchMembrosDepartamento = async () => {
    try {
      const { data, error } = await supabase
        .from('membros')
        .select('idmembro, nome, apelido, foto, iddepto')
        .eq('status', 'Ativo')
        .not('iddepto', 'is', null);
      if (error) throw error;

      const { data: lideresData, error: lideresError } = await supabase
        .from('lideres')
        .select(`
          idarea,
          membros:idmembro ( idmembro, nome, apelido, foto )
        `)
        .eq('status', 'Ativo')
        .not('idarea', 'is', null);
      if (lideresError) throw lideresError;

      const membrosGrouped = (data || []).reduce((acc, membro) => {
        if (!acc[membro.iddepto]) acc[membro.iddepto] = [];
        acc[membro.iddepto].push(membro);
        return acc;
      }, {} as Record<string, MembroDepartamento[]>);

      const lideresGrouped = (lideresData || []).reduce((acc, lider) => {
        if (!lider.idarea || !lider.membros) return acc;
        if (!acc[lider.idarea]) acc[lider.idarea] = [];
        acc[lider.idarea].push({
          idmembro: lider.membros.idmembro,
          nome: lider.membros.nome,
          apelido: lider.membros.apelido,
          foto: lider.membros.foto
        });
        return acc;
      }, {} as Record<string, LiderInfo[]>);

      setMembrosDepartamento(membrosGrouped);
      setLideresPorArea(lideresGrouped);
    } catch (err) {
      toast({
        title: "Erro ao carregar membros dos departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const fetchAreasDepartamento = async () => {
    try {
      const { data, error } = await supabase
        .from('areas')
        .select('*')
        .eq('status', 'Ativo')
        .order('nome');
      if (error) throw error;

      const areasGrouped = (data || []).reduce((acc, area) => {
        if (!acc[area.iddepto]) acc[area.iddepto] = [];
        acc[area.iddepto].push(area);
        return acc;
      }, {} as Record<string, Area[]>);

      setAreasDepartamento(areasGrouped);
    } catch (err) {
      toast({
        title: "Erro ao carregar áreas dos departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const getLiderInfo = (idmembro: string): LiderInfo | null =>
    lideres.find(lider => lider.idmembro === idmembro) || null;

  // getImageUrl centralizado em '@/lib/utils'

  const generateId = () => {
    const maxId = departamentos.reduce((max, dept) => {
      const numericPart = parseInt(dept.iddepto.replace(/\D/g, ''));
      return Math.max(max, isNaN(numericPart) ? 0 : numericPart);
    }, 0);
    return `DEP${(maxId + 1).toString().padStart(3, '0')}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome.trim()) {
      toast({ title: "Nome obrigatório", description: "Por favor, informe o nome do departamento", variant: "destructive" });
      return;
    }

    try {
      if (editingDepto) {
        const { error } = await supabase
          .from('departamentos')
          .update({
            nome: formData.nome,
            liderdepto1: formData.liderdepto1 || null,
            liderdepto2: formData.liderdepto2 || null
          })
          .eq('iddepto', editingDepto.iddepto);
        if (error) throw error;
        toast({ title: "Departamento atualizado!", description: `${formData.nome} foi atualizado com sucesso.` });
      } else {
        const newId = generateId();
        const { error } = await supabase
          .from('departamentos')
          .insert({
            iddepto: newId,
            nome: formData.nome,
            liderdepto1: formData.liderdepto1 || null,
            liderdepto2: formData.liderdepto2 || null
          });
        if (error) throw error;
        toast({ title: "Departamento criado!", description: `${formData.nome} foi criado com sucesso.` });
      }

      setIsDialogOpen(false);
      setEditingDepto(null);
      setFormData({ nome: "", liderdepto1: "", liderdepto2: "" });
      fetchDepartamentos();
    } catch (err) {
      toast({
        title: editingDepto ? "Erro ao atualizar" : "Erro ao criar",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (depto: Departamento) => {
    try {
      const { error } = await supabase.from('departamentos').delete().eq('iddepto', depto.iddepto);
      if (error) throw error;
      toast({ title: "Departamento excluído!", description: `${depto.nome} foi excluído com sucesso.` });
      fetchDepartamentos();
    } catch (err) {
      toast({ title: "Erro ao excluir", description: err instanceof Error ? err.message : "Erro desconhecido", variant: "destructive" });
    }
  };

  const openEditDialog = (depto: Departamento) => {
    setEditingDepto(depto);
    setFormData({
      nome: depto.nome,
      liderdepto1: depto.liderdepto1 || "",
      liderdepto2: depto.liderdepto2 || ""
    });
    setIsDialogOpen(true);
  };

  useEffect(() => {
    fetchDepartamentos();
    fetchLideres();
    fetchMembrosDepartamento();
    fetchAreasDepartamento();
  }, []);

  const normalized = (s?: string) =>
    (s || "").toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");

  const leaderName = (id?: string) => {
    if (!id) return "";
    const l = getLiderInfo(id);
    return l ? normalized(l.apelido || l.nome) : "";
    };

  const filteredDepartamentos = useMemo(() => {
    const q = normalized(searchTerm);
    if (!q) return departamentos;
    return departamentos.filter((d) => {
      const nome = normalized(d.nome);
      const l1 = leaderName(d.liderdepto1);
      const l2 = leaderName(d.liderdepto2);
      return nome.includes(q) || l1.includes(q) || l2.includes(q);
    });
  }, [departamentos, searchTerm, lideres]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <Building className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Gerenciar Departamentos</h2>
        </div>

        {/* Barra de busca */}
        <div className="relative max-w-xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Buscar departamento por nome ou líder..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-10"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                setEditingDepto(null);
                setFormData({ nome: "", liderdepto1: "", liderdepto2: "" });
              }}
              className="bg-primary hover:bg-primary-hover w-fit"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Departamento
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingDepto ? "Editar Departamento" : "Novo Departamento"}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome do Departamento *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                  placeholder="Digite o nome do departamento"
                  required
                />
              </div>

              <div>
                <Label htmlFor="liderdepto1">Líder Principal</Label>
                <Select
                  value={formData.liderdepto1 || undefined}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, liderdepto1: value === "none" ? "" : value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um membro" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {lideres.map((lider) => (
                      <SelectItem key={lider.idmembro} value={lider.idmembro}>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                            {getImageUrl(lider.foto) ? (
                              <img
                                src={getImageUrl(lider.foto)!}
                                alt={lider.nome}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <User className="w-3 h-3 text-muted-foreground" />
                            )}
                          </div>
                          <span>{lider.apelido || lider.nome}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="liderdepto2">Líder Secundário</Label>
                <Select
                  value={formData.liderdepto2 || undefined}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, liderdepto2: value === "none" ? "" : value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um membro" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {lideres.map((lider) => (
                      <SelectItem key={lider.idmembro} value={lider.idmembro}>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                            {getImageUrl(lider.foto) ? (
                              <img
                                src={getImageUrl(lider.foto)!}
                                alt={lider.nome}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <User className="w-3 h-3 text-muted-foreground" />
                            )}
                          </div>
                          <span>{lider.apelido || lider.nome}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">{editingDepto ? "Atualizar" : "Criar"}</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {loading ? (
          <div className="text-center py-8">Carregando...</div>
        ) : (
          filteredDepartamentos.map((depto) => (
            <Card key={depto.iddepto} className="bg-gradient-card border-border/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{depto.nome}</h3>

                    {(depto.liderdepto1 || depto.liderdepto2) && (
                      <div className="mt-3 space-y-2">
                        {depto.liderdepto1 && (() => {
                          const liderInfo = getLiderInfo(depto.liderdepto1);
                          return (
                            <div className="flex items-center gap-2 text-sm">
                              <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                {liderInfo && getImageUrl(liderInfo.foto) ? (
                                  <img
                                    src={getImageUrl(liderInfo.foto)!}
                                    alt={liderInfo.nome}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      console.warn('Erro ao carregar imagem:', getImageUrl(liderInfo.foto));
                                      e.currentTarget.src = '/placeholder.svg';
                                    }}
                                  />
                                ) : null}
                                <User className="w-3 h-3 text-muted-foreground" />
                              </div>
                              <div>
                                <span className="font-medium">Líder Principal: </span>
                                {liderInfo ? (
                                  <span>{liderInfo.apelido || liderInfo.nome}</span>
                                ) : (
                                  <span className="text-muted-foreground">Membro não encontrado</span>
                                )}
                              </div>
                            </div>
                          );
                        })()}

                        {depto.liderdepto2 && (() => {
                          const liderInfo = getLiderInfo(depto.liderdepto2);
                          return (
                            <div className="flex items-center gap-2 text-sm">
                              <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                {liderInfo && getImageUrl(liderInfo.foto) ? (
                                  <img
                                    src={getImageUrl(liderInfo.foto)!}
                                    alt={liderInfo.nome}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      console.warn('Erro ao carregar imagem:', getImageUrl(liderInfo.foto));
                                      e.currentTarget.src = '/placeholder.svg';
                                    }}
                                  />
                                ) : null}
                                <User className="w-3 h-3 text-muted-foreground" />
                              </div>
                              <div>
                                <span className="font-medium">Líder Secundário: </span>
                                {liderInfo ? (
                                  <span>{liderInfo.apelido || liderInfo.nome}</span>
                                ) : (
                                  <span className="text-muted-foreground">Membro não encontrado</span>
                                )}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    )}

                    {areasDepartamento[depto.iddepto] && areasDepartamento[depto.iddepto].length > 0 && (
                      <div className="mt-4">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-muted-foreground">
                            Áreas ({areasDepartamento[depto.iddepto].length})
                          </span>
                        </div>
                        <div className="grid gap-2">
                          {areasDepartamento[depto.iddepto].map((area) => {
                            const areaMembrosCount =
                              membrosDepartamento[depto.iddepto]?.filter((m) =>
                                lideresPorArea[area.idarea]?.some((l) => l.idmembro === m.idmembro)
                              ).length || 0;

                            return (
                              <div key={area.idarea} className="bg-muted/30 rounded-lg p-3 border border-border/30">
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start gap-2 flex-1">
                                    <MapPin className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium text-sm">{area.nome}</span>
                                        <Badge variant="outline" className="text-xs">
                                          {areaMembrosCount} {areaMembrosCount === 1 ? "membro" : "membros"}
                                        </Badge>
                                      </div>
                                      {area.descricao && (
                                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                                          {area.descricao}
                                        </p>
                                      )}

                                      {lideresPorArea[area.idarea] && lideresPorArea[area.idarea].length > 0 && (
                                        <div className="mt-2">
                                          <p className="text-xs font-medium text-muted-foreground mb-1">Líderes:</p>
                                          <div className="flex flex-wrap gap-1">
                                            {lideresPorArea[area.idarea].map((lider) => (
                                              <div key={lider.idmembro} className="flex items-center gap-1 bg-primary/10 rounded-full px-2 py-0.5">
                                                <div className="w-4 h-4 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                                  {getImageUrl(lider.foto) ? (
                                                    <img
                                                      src={getImageUrl(lider.foto)!}
                                                      alt={lider.nome}
                                                      className="w-full h-full object-cover"
                                                      onError={(e) => {
                                                        console.warn('Erro ao carregar imagem:', getImageUrl(lider.foto));
                                                        e.currentTarget.src = '/placeholder.svg';
                                                      }}
                                                    />
                                                  ) : (
                                                    <User className="w-2.5 h-2.5 text-muted-foreground" />
                                                  )}
                                                </div>
                                                <span className="text-xs font-medium text-primary">
                                                  {lider.apelido || lider.nome}
                                                </span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {membrosDepartamento[depto.iddepto] && membrosDepartamento[depto.iddepto].length > 0 && (
                      <div className="mt-4 pt-3 border-t border-border/50">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Users className="w-4 h-4 text-primary" />
                          <span>Total de membros: {membrosDepartamento[depto.iddepto].length}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => openEditDialog(depto)}>
                      <Edit className="w-4 h-4" />
                    </Button>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="destructive">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja excluir o departamento "{depto.nome}"?
                            Esta ação não pode ser desfeita.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(depto)}>
                            Excluir
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}

        {!loading && filteredDepartamentos.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <Building className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum departamento encontrado</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
