import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Crown, Building } from 'lucide-react';

interface LiderancaData {
  idlider: string;
  iddepto: string;
  idarea?: string;
  nome_departamento: string;
  nome_area?: string;
}

interface LiderancaInfoProps {
  membroId: string;
}

export default function LiderancaInfo({ membroId }: LiderancaInfoProps) {
  const [lideranca, setLideranca] = useState<LiderancaData[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchLideranca();
  }, [membroId]);

  const fetchLideranca = async () => {
    if (!membroId) return;
    
    setLoading(true);
    try {
      const { data: lideresData, error: lideresError } = await supabase
        .from('lideres')
        .select(`
          idlider,
          iddepto,
          idarea,
          departamentos:iddepto (nome)
        `)
        .eq('idmembro', membroId)
        .eq('status', 'Ativo');

      if (lideresError) throw lideresError;

      if (lideresData && lideresData.length > 0) {
        // Buscar áreas se necessário
        const { data: areasData, error: areasError } = await supabase
          .from('areas')
          .select('idarea, nome')
          .eq('status', 'Ativo');

        if (areasError) throw areasError;

        const liderancaFormatada = lideresData.map(lider => ({
          idlider: lider.idlider,
          iddepto: lider.iddepto,
          idarea: lider.idarea,
          nome_departamento: (lider.departamentos as any)?.nome || 'Departamento não encontrado',
          nome_area: lider.idarea ? areasData?.find(a => a.idarea === lider.idarea)?.nome : undefined
        }));

        setLideranca(liderancaFormatada);
      } else {
        setLideranca([]);
      }
    } catch (err) {
      console.error('Erro ao carregar informações de liderança:', err);
      setLideranca([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <h4 className="font-semibold text-lg border-b pb-2 flex items-center gap-2">
          <Crown className="w-5 h-5" />
          Liderança
        </h4>
        <p className="text-sm text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (lideranca.length === 0) {
    return null; // Não mostra a seção se não for líder
  }

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-lg border-b pb-2 flex items-center gap-2">
        <Crown className="w-5 h-5 text-amber-500" />
        Liderança
      </h4>
      
      <div className="space-y-3">
        {lideranca.map((lider) => (
          <div key={lider.idlider} className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
            <div className="flex items-center gap-3">
              <Building className="w-4 h-4 text-amber-600" />
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className="bg-amber-100 text-amber-800 border-amber-300">
                    {lider.nome_departamento}
                  </Badge>
                  {lider.nome_area && (
                    <Badge variant="outline" className="border-amber-300 text-amber-700">
                      {lider.nome_area}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Líder {lider.nome_area ? `da área ${lider.nome_area}` : `do departamento ${lider.nome_departamento}`}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}