// AgendaList.tsx — com SELETOR de mês/ano e FILTRO no FRONT (funciona mesmo se a coluna "data" for texto)

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Calendar, Clock, MapPin, User, Plus, Edit, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from '@/components/ui/alert-dialog';

interface AgendaEvent {
  idagenda: string;
  data: string;
  horario_inicial?: string;
  horario_final?: string;
  departamento?: string;
  nome_lider?: string;
  nome_local?: string;
  nome_evento?: string;
  status_evento?: string;
  cor_evento?: string;
  descricao?: string;
  observacao?: string;
}

interface User { email: string; permission: string; }
interface AgendaListProps { user: User; }
interface EventFormData { descricao: string; horario_inicial: string; horario_final: string; observacao: string; }

const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

// Lê "dd/MM/yyyy" OU "yyyy-MM-dd" (ou ISO) sem erro de fuso
const parseDate = (v: string): Date => {
  if (!v) return new Date(0);
  if (v.includes('/')) { const [dd, mm, yyyy] = v.split('/'); return new Date(`${yyyy}-${mm}-${dd}T00:00:00`); }
  const s = v.substring(0, 10); return new Date(`${s}T00:00:00`);
};

export default function AgendaList({ user }: AgendaListProps) {
  const today = new Date();
  const [year, setYear]   = useState<number>(today.getFullYear());
  const [month, setMonth] = useState<number>(today.getMonth()); // 0-11

  const [events, setEvents] = useState<AgendaEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<string | null>(null);

  const [eventForm, setEventForm] = useState<EventFormData>({
    descricao: '', horario_inicial: '09:00', horario_final: '10:00', observacao: ''
  });

  useEffect(() => { fetchAndFilter(year, month); }, [year, month]);

  // Navegação mês anterior/próximo
  const changeMonth = (delta: number) => {
    const d = new Date(year, month + delta, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth());
  };

  // Busca TUDO e filtra no front (garante funcionar com view/strings)
  const fetchAndFilter = async (y: number, m: number) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('agenda_full').select('*');
      if (error) throw error;

      const start = new Date(y, m, 1).getTime();
      const end   = new Date(y, m + 1, 1).getTime(); // exclusivo

      const filtered = (data ?? [])
        .filter((e: any) => {
          const t = parseDate(e.data).getTime();
          return t >= start && t < end;
        })
        .sort((a: any, b: any) => {
          const ta = parseDate(a.data).getTime();
          const tb = parseDate(b.data).getTime();
          if (ta !== tb) return ta - tb; // data ASC
          const ha = (a.horario_inicial ?? '').slice(0,5);
          const hb = (b.horario_inicial ?? '').slice(0,5);
          return ha.localeCompare(hb);   // hora ASC
        });

      setEvents(filtered as AgendaEvent[]);
    } catch (err) {
      toast({ title: 'Erro ao carregar eventos', description: err instanceof Error ? err.message : 'Erro desconhecido', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const handleCreateEvent = async () => {
    if (!eventForm.descricao.trim()) return;
    try {
      const idagenda = crypto.randomUUID();
      const { error } = await supabase.from('agenda').insert({
        idagenda,
        data: new Date().toISOString().split('T')[0],
        descricao: eventForm.descricao,
        horario_inicial: eventForm.horario_inicial,
        horario_final: eventForm.horario_final,
        observacao: eventForm.observacao,
        iddepto: '', idlider: '', idlocal: '', ideventoig: '', idstatus: ''
      });
      if (error) throw error;
      toast({ title: 'Compromisso criado', description: 'Adicionado à agenda' });
      setShowCreateModal(false);
      setEventForm({ descricao:'', horario_inicial:'09:00', horario_final:'10:00', observacao:'' });
      fetchAndFilter(year, month);
    } catch (err) {
      toast({ title: 'Erro ao criar compromisso', description: err instanceof Error ? err.message : 'Erro desconhecido', variant: 'destructive' });
    }
  };

  const handleDeleteEvent = async () => {
    if (!eventToDelete) return;
    try {
      const { error } = await supabase.from('agenda').delete().eq('idagenda', eventToDelete);
      if (error) throw error;
      toast({ title: 'Compromisso excluído', description: 'Removido da agenda' });
      setShowDeleteDialog(false);
      setEventToDelete(null);
      fetchAndFilter(year, month);
    } catch (err) {
      toast({ title: 'Erro ao excluir compromisso', description: err instanceof Error ? err.message : 'Erro desconhecido', variant: 'destructive' });
    }
  };

  const formatDateLong = (s: string) =>
    parseDate(s).toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  const formatTime = (t?: string) => (!t ? '' : t.substring(0,5));

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Agenda — {MESES[month]} / {year}
            </CardTitle>

            {/* SELETOR + Navegação */}
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => changeMonth(-1)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>

              <select
                className="border rounded-md px-2 py-1 text-sm"
                value={month}
                onChange={(e) => setMonth(Number(e.target.value))}
              >
                {MESES.map((mName, i) => (
                  <option key={mName} value={i}>{mName}</option>
                ))}
              </select>

              <select
                className="border rounded-md px-2 py-1 text-sm"
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
              >
                {Array.from({ length: 7 }).map((_, idx) => {
                  const y = today.getFullYear() - 1 + idx; // ano passado até +5
                  return <option key={y} value={y}>{y}</option>;
                })}
              </select>

              <Button variant="outline" size="sm" onClick={() => changeMonth(1)}>
                <ChevronRight className="w-4 h-4" />
              </Button>

              {user.permission === 'ADM' && (
                <Button
                  onClick={() => { setEventForm({ descricao:'', horario_inicial:'09:00', horario_final:'10:00', observacao:'' }); setShowCreateModal(true); }}
                  className="bg-gradient-primary text-primary-foreground hover:shadow-primary ml-2"
                >
                  <Plus className="w-4 h-4 mr-2" /> Incluir
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {loading ? (
            <div className="text-center py-12 text-muted-foreground">
              <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>Carregando compromissos...</p>
            </div>
          ) : events.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Calendar className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Nenhum compromisso neste período</p>
            </div>
          ) : (
            <div className="space-y-4">
              {events.map((event) => (
                <Card key={event.idagenda} className="border border-border/50 hover:shadow-sm transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-3">
                          <h3 className="font-semibold text-lg">
                            {event.nome_evento || event.descricao || 'Compromisso'}
                          </h3>
                          {event.status_evento && (
                            <Badge style={{ backgroundColor: event.cor_evento || '#3B82F6' }} className="text-white border-0">
                              {event.status_evento}
                            </Badge>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Calendar className="w-4 h-4" />
                            <span>{formatDateLong(event.data)}</span>
                          </div>

                          {(event.horario_inicial || event.horario_final) && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Clock className="w-4 h-4" />
                              <span>
                                {formatTime(event.horario_inicial)}
                                {event.horario_final && ` - ${formatTime(event.horario_final)}`}
                              </span>
                            </div>
                          )}

                          {event.nome_local && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              <span>{event.nome_local}</span>
                            </div>
                          )}

                          {event.nome_lider && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <User className="w-4 h-4" />
                              <span>{event.nome_lider}</span>
                            </div>
                          )}
                        </div>

                        {event.descricao && <p className="text-sm mb-3">{event.descricao}</p>}

                        {event.observacao && (
                          <div className="p-3 bg-muted/50 rounded-lg">
                            <p className="text-sm"><strong>Observações:</strong> {event.observacao}</p>
                          </div>
                        )}
                      </div>

                      {user.permission === 'ADM' && (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm"><Edit className="w-4 h-4" /></Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => { setEventToDelete(event.idagenda); setShowDeleteDialog(true); }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal Criar Compromisso */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" /> Novo Compromisso
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="descricao">Descrição *</Label>
              <Textarea id="descricao" value={eventForm.descricao} onChange={(e) => setEventForm((p) => ({ ...p, descricao: e.target.value }))} rows={3} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="horario_inicial">Horário Inicial</Label>
                <Input id="horario_inicial" type="time" value={eventForm.horario_inicial} onChange={(e) => setEventForm((p) => ({ ...p, horario_inicial: e.target.value }))} />
              </div>
              <div>
                <Label htmlFor="horario_final">Horário Final</Label>
                <Input id="horario_final" type="time" value={eventForm.horario_final} onChange={(e) => setEventForm((p) => ({ ...p, horario_final: e.target.value }))} />
              </div>
            </div>

            <div>
              <Label htmlFor="observacao">Observações</Label>
              <Textarea id="observacao" value={eventForm.observacao} onChange={(e) => setEventForm((p) => ({ ...p, observacao: e.target.value }))} rows={2} />
            </div>

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={() => setShowCreateModal(false)} className="flex-1">Cancelar</Button>
              <Button onClick={handleCreateEvent} disabled={!eventForm.descricao.trim()} className="flex-1 bg-gradient-primary">Criar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmação de Exclusão */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Compromisso</AlertDialogTitle>
            <AlertDialogDescription>Tem certeza? Esta ação não pode ser desfeita.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteEvent} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
