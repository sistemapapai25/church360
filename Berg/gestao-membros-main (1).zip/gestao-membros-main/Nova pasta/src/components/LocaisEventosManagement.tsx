import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Trash2, Plus } from "lucide-react";

/** Tipos alinhados ao schema gerado do Supabase */
type LocalRow = {
  idlocal: string;
  local: string;
  contato?: string | null;
  fone?: string | null;
};

type LocalInsert = {
  idlocal: string;
  local: string;
  contato?: string | null;
  fone?: string | null;
};

function pickLabel(row: Partial<LocalRow>) {
  return row.local || "Local";
}

async function addLocal(nome: string) {
  try {
    const payload: LocalInsert = {
      idlocal: crypto.randomUUID(), // requerido pelo tipo
      local: nome.trim(),           // requerido pelo tipo
      // contato: null,
      // fone: null,
    };

    // ✅ Objeto com as chaves exatas esperadas pelo tipo
    const { error } = await supabase.from("locais").insert(payload);
    if (error) throw error;

    return { ok: true as const, id: payload.idlocal };
  } catch (e: any) {
    return { ok: false as const, err: e?.message || "Falha ao inserir em 'locais'." };
  }
}

export default function LocaisEventosManagement() {
  const [itens, setItens] = useState<LocalRow[]>([]);
  const [nome, setNome] = useState("");
  const [loading, setLoading] = useState(false);

  const carregar = async () => {
    const { data, error } = await supabase
      .from("locais")
      .select("idlocal, local, contato, fone")
      .order("local", { ascending: true });

    if (error) {
      toast({ title: "Erro ao carregar", description: error.message, variant: "destructive" });
      return;
    }
    setItens((data as LocalRow[]) || []);
  };

  const salvar = async () => {
    if (!nome.trim()) return;
    setLoading(true);
    const res = await addLocal(nome.trim());
    setLoading(false);

    if (!res.ok) {
      toast({
        title: "Não foi possível criar",
        description: res.err || "Verifique o schema da tabela 'locais'.",
        variant: "destructive",
      });
      return;
    }

    setNome("");
    await carregar();
    toast({ title: "Local criado com sucesso!" });
  };

  const excluir = async (row: LocalRow) => {
    const { error } = await supabase.from("locais").delete().eq("idlocal", row.idlocal);
    if (error) {
      toast({ title: "Erro ao excluir", description: error.message, variant: "destructive" });
      return;
    }
    await carregar();
    toast({ title: "Excluído!" });
  };

  useEffect(() => {
    carregar();
  }, []);

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <Label>Nome do local</Label>
            <Input
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex.: Templo, Salão Social, Anexo..."
            />
          </div>
          <div className="flex items-end">
            <Button onClick={salvar} disabled={loading} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              {loading ? "Salvando..." : "Adicionar"}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-3">
        <div className="divide-y">
          {(itens || []).map((row) => (
            <div key={row.idlocal} className="flex items-center justify-between py-2">
              <div className="font-medium">{pickLabel(row)}</div>
              <Button variant="ghost" size="icon" onClick={() => excluir(row)} title="Excluir">
                <Trash2 className="w-4 h-4 text-red-600" />
              </Button>
            </div>
          ))}
          {itens.length === 0 && (
            <div className="py-4 text-sm text-muted-foreground">Sem registros.</div>
          )}
        </div>
      </Card>
    </div>
  );
}
