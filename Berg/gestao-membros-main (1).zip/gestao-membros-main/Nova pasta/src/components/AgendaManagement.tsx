// src/components/ui/AgendaManagement.tsx
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import CalendarView from "./CalendarView";

interface User {
  email: string;
  permission: string;
}

interface AgendaManagementProps {
  user: User;
}

const MESES = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];

export default function AgendaManagement({ user }: AgendaManagementProps) {
  const today = new Date();
  const [year, setYear] = useState<number>(today.getFullYear());
  const [month, setMonth] = useState<number>(today.getMonth()); // 0-11

  const changeMonth = (delta: number) => {
    const d = new Date(year, month + delta, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth());
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex flex-col items-center gap-3">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Agenda Igreja
            </CardTitle>

            {/* Controles de mês/ano */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => changeMonth(-1)}
                aria-label="Mês anterior"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>

              <select
                className="border rounded-md px-2 py-1 text-sm"
                value={month}
                onChange={(e) => setMonth(Number(e.target.value))}
                aria-label="Selecionar mês"
              >
                {MESES.map((m, i) => (
                  <option key={m} value={i}>
                    {m}
                  </option>
                ))}
              </select>

              <select
                className="border rounded-md px-2 py-1 text-sm"
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                aria-label="Selecionar ano"
              >
                {Array.from({ length: 7 }).map((_, idx) => {
                  const y = today.getFullYear() - 1 + idx; // ano passado até +5
                  return (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  );
                })}
              </select>

              <Button
                variant="outline"
                size="sm"
                onClick={() => changeMonth(1)}
                aria-label="Próximo mês"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {/* Calendário mensal filtrado pelo mês/ano acima */}
          <CalendarView user={user} month={month} year={year} />
        </CardContent>
      </Card>
    </div>
  );
}
