import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, LogIn } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import ResetPasswordButton from "@/components/ResetPasswordButton";

export default function LoginForm() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setLoading(true);
    setError(undefined);

    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      toast({ title: "Login realizado com sucesso!", description: "Bem-vindo ao sistema" });
      navigate("/");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erro inesperado ao fazer login";
      setError(message);
      toast({ title: "Erro no login", description: message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-primary/10 to-secondary/10">
      <Card className="w-full max-w-md bg-gradient-card shadow-2xl border-0 backdrop-blur-sm">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto mb-6">
            <img
              src="/lovable-uploads/9d9229f3-fb14-4b21-9692-6a6aa36e1d16.png"
              alt="Igreja Águas Purificadoras"
              className="w-20 h-20 mx-auto shadow-xl"
            />
          </div>

          {/* Títulos solicitados */}
          <CardTitle className="text-xl font-bold leading-snug">
            Igreja Apostólica e Profética Águas Purificadoras
          </CardTitle>
          <p className="text-sm text-muted-foreground mt-1">Gestão de Membros</p>

          <p className="text-muted-foreground text-base mt-4">
            Faça login para acessar o sistema
          </p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="w-4 h-4" /> E-mail
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="transition-smooth focus:shadow-elegant"
                disabled={loading}
                autoComplete="email"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="flex items-center gap-2">
                <Lock className="w-4 h-4" /> Senha
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="transition-smooth focus:shadow-elegant"
                disabled={loading}
                autoComplete="current-password"
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button
              type="submit"
              className="w-full bg-gradient-primary hover:shadow-primary transition-smooth"
              disabled={loading || !email || !password}
              size="lg"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Entrando...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <LogIn className="w-4 h-4" />
                  Entrar
                </div>
              )}
            </Button>
          </form>

          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Esqueceu a senha?</span>
            <ResetPasswordButton />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
