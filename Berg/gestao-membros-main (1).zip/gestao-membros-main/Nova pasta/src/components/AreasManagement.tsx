// src/pages/AreasManagement.tsx
import { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, MapPin, Building, Search, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAreas, type Area } from "@/hooks/useAreas";
import { supabase } from "@/integrations/supabase/client";

export default function AreasManagement() {
  const {
    areas,
    departamentos,
    loading,
    createArea,
    updateArea,
    deleteArea,
    fetchAreas,
  } = useAreas();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [formData, setFormData] = useState({ nome: "", descricao: "", iddepto: "", lider1: "", lider2: "" });
  const [searchTerm, setSearchTerm] = useState("");

  // Membros disponíveis para seleção quando o departamento for Capelania
  const [availableMembers, setAvailableMembers] = useState<Array<{ idmembro: string; nome: string; apelido?: string }>>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);

  // Mapa de membros por id para exibir nomes nas listagens
  const [membersMap, setMembersMap] = useState<Record<string, { idmembro: string; nome: string; apelido?: string }>>({});

  const resetForm = () => {
    setEditingArea(null);
    setFormData({ nome: "", descricao: "", iddepto: "", lider1: "", lider2: "" });
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (area: Area) => {
    setEditingArea(area);
    setFormData({
      nome: area.nome,
      descricao: area.descricao || "",
      iddepto: area.iddepto,
      lider1: (area as any).lider1 || "",
      lider2: (area as any).lider2 || "",
    });
    setIsDialogOpen(true);
  };

  // Helper para identificar Capelania por nome do departamento
  const isCapelaniaDept = (iddepto: string) => {
    const dept = departamentos.find((d) => d.iddepto === iddepto);
    if (!dept?.nome) return false;
    return dept.nome.trim().toLowerCase() === "capelania";
  };

  // Helper: ordenar alfabeticamente pelo nome de exibição (apelido ou nome)
  const sortByDisplayName = (
    a: { nome: string; apelido?: string },
    b: { nome: string; apelido?: string }
  ) => {
    const da = (a.apelido ?? a.nome).trim().toLowerCase();
    const db = (b.apelido ?? b.nome).trim().toLowerCase();
    return da.localeCompare(db);
  };

  // Carregar opções de líderes quando for Capelania
  // Em edição: listar apenas líderes já vinculados à área
  // Em criação: listar membros ativos do departamento selecionado
  useEffect(() => {
    const loadAvailableLeaders = async () => {
      if (!formData.iddepto || !isCapelaniaDept(formData.iddepto)) {
        setAvailableMembers([]);
        return;
      }

      setLoadingMembers(true);
      try {
        if (editingArea?.idarea) {
          // Editando uma área: pegar somente líderes já vinculados à área
          const { data, error } = await supabase
            .from("lideres")
            .select(`
              idmembro,
              status,
              membros:idmembro ( idmembro, nome, apelido )
            `)
            .eq("status", "Ativo")
            .eq("idarea", editingArea.idarea);
          if (error) throw error;
          const mapped = (data || []).map((l: any) => ({
            idmembro: String(l?.membros?.idmembro || l.idmembro),
            nome: String(l?.membros?.nome || ""),
            apelido: l?.membros?.apelido ? String(l.membros.apelido) : undefined,
          }));
          // Remover duplicatas por idmembro
          const unique = Array.from(new Map(mapped.map(m => [m.idmembro, m])).values());
          unique.sort(sortByDisplayName);
          setAvailableMembers(unique);
        } else {
          // Criando nova área: listar membros ativos do departamento
          const { data, error } = await supabase
            .from("membros")
            .select("idmembro, nome, apelido")
            .eq("iddepto", formData.iddepto)
            .eq("status", "Ativo")
            .order("nome");
          if (error) throw error;
          const mapped = (data || []).map((m: any) => ({ idmembro: m.idmembro, nome: m.nome, apelido: m.apelido }));
          mapped.sort(sortByDisplayName);
          setAvailableMembers(mapped);
        }
      } catch (err) {
        console.error("[AreasManagement] Erro ao carregar opções de líderes:", err);
        setAvailableMembers([]);
      } finally {
        setLoadingMembers(false);
      }
    };
    loadAvailableLeaders();
  }, [formData.iddepto, departamentos, editingArea?.idarea]);

  // Carregar nomes dos líderes para exibição nas listagens
  useEffect(() => {
    const ids = Array.from(new Set(
      areas.flatMap((a) => [ (a as any).lider1, (a as any).lider2 ].filter(Boolean))
    ));
    if (ids.length === 0) {
      setMembersMap({});
      return;
    }
    (async () => {
      const { data, error } = await supabase
        .from("membros")
        .select("idmembro, nome, apelido")
        .in("idmembro", ids as string[]);
      if (error) {
        console.error("[AreasManagement] Erro ao carregar nomes dos líderes:", error);
        return;
      }
      const map: Record<string, { idmembro: string; nome: string; apelido?: string }> = {};
      (data || []).forEach((m: any) => { map[m.idmembro] = { idmembro: m.idmembro, nome: m.nome, apelido: m.apelido }; });
      setMembersMap(map);
    })();
  }, [areas]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    if (!formData.nome.trim()) {
      toast({ title: "Nome obrigatório", description: "Informe o nome da área.", variant: "destructive" });
      return;
    }
    if (!formData.iddepto) {
      toast({ title: "Departamento obrigatório", description: "Selecione um departamento válido.", variant: "destructive" });
      return;
    }

    // Validação: Capelania exige Líder Principal; Secundário é opcional
    const isCapelania = isCapelaniaDept(formData.iddepto);
    if (isCapelania) {
      if (!formData.lider1) {
        toast({ title: "Capelania exige Líder Principal", description: "Selecione o Líder Principal.", variant: "destructive" });
        return;
      }
      if (formData.lider2 && formData.lider1 === formData.lider2) {
        toast({ title: "Líderes devem ser distintos", description: "Se escolher o Secundário, selecione alguém diferente do Principal.", variant: "destructive" });
        return;
      }
    }

    setSubmitting(true);

    let result;
    if (editingArea) {
      const nomeTrimmed = formData.nome.trim();
      result = await updateArea(editingArea.idarea, nomeTrimmed, formData.descricao, formData.iddepto, formData.lider1 || null, formData.lider2 || null);
    } else {
      result = await createArea(formData.nome, formData.descricao, formData.iddepto, formData.lider1 || null, formData.lider2 || null);
    }
    
    setSubmitting(false);

    if (result.success) {
      console.log('Operação concluída com sucesso:', result);
      
      // Atualizar o estado local imediatamente para refletir a mudança
      if (editingArea && result.data) {
        // Se estamos editando, atualizamos a área no estado local
        const updatedArea = result.data[0];
        console.log('Área atualizada:', updatedArea);
      }
      
      // Fechar o diálogo e resetar o formulário apenas após a conclusão da operação
      setIsDialogOpen(false);
      resetForm();
      
      // Forçar atualização da lista de áreas para garantir que as alterações sejam exibidas
      setTimeout(() => {
        fetchAreas();
      }, 500);
    }
  };

  const handleDelete = async (area: Area) => {
    await deleteArea(area.idarea, area.nome);
  };

  // --- Busca ---
  const normalize = (s?: string) => {
    if (!s) return "";
    try {
      return s.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
    } catch {
      return s
        .toLowerCase()
        .replace(/[áàãâä]/g, "a").replace(/[éèêë]/g, "e")
        .replace(/[íìîï]/g, "i").replace(/[óòõôö]/g, "o")
        .replace(/[úùûü]/g, "u").replace(/[ç]/g, "c");
    }
  };

  const filteredAreas = useMemo(() => {
    const q = normalize(searchTerm);
    if (!q) return areas;
    return areas.filter((a) => {
      const nome = normalize(a.nome);
      const desc = normalize(a.descricao || "");
      const dep = normalize((a as any).nome_departamento || "");
      return nome.includes(q) || desc.includes(q) || dep.includes(q);
    });
  }, [areas, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Cabeçalho + Ações */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <MapPin className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Gerenciar Áreas</h2>
        </div>

        {/* Barra de busca */}
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Buscar área por nome, descrição ou departamento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-10"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreateDialog} className="bg-primary">
                <Plus className="w-4 h-4 mr-2" />
                Nova Área
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingArea ? "Editar Área" : "Nova Área"}</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="nome">Nome da Área *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                    placeholder="Ex.: Hospital São Silvestre - Terça"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="iddepto">Departamento *</Label>
                  <Select
                    value={formData.iddepto}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, iddepto: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          departamentos.length === 0 ? "Nenhum departamento encontrado" : "Selecione o departamento"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {departamentos.map((dept) => (
                        <SelectItem key={dept.iddepto} value={dept.iddepto}>
                          {dept.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {departamentos.length === 0 && (
                    <p className="mt-1 text-xs text-muted-foreground">
                      Cadastre departamentos antes de criar áreas.
                    </p>
                  )}

                  {formData.iddepto && isCapelaniaDept(formData.iddepto) && (
                    <div className="mt-3 space-y-3">
                      <p className="text-xs text-muted-foreground">
                        Capelania: Líder Principal é obrigatório; Secundário é opcional. {editingArea ? "Somente líderes já vinculados à área em edição." : "Lista mostra membros ativos do departamento."}
                      </p>
                      <div>
                        <Label htmlFor="lider1">Líder Principal *</Label>
                        <Select
                          value={formData.lider1}
                          onValueChange={(value) => setFormData((prev) => ({ ...prev, lider1: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={loadingMembers ? "Carregando membros..." : "Selecione o Líder Principal"} />
                          </SelectTrigger>
                          <SelectContent>
                            {availableMembers.map((m) => (
                              <SelectItem key={m.idmembro} value={m.idmembro}>
                                {m.nome}{m.apelido ? ` (${m.apelido})` : ""}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="lider2">Líder Secundário (opcional)</Label>
                        <Select
                          value={formData.lider2}
                          onValueChange={(value) => setFormData((prev) => ({ ...prev, lider2: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder={loadingMembers ? "Carregando membros..." : "Selecione o Líder Secundário"} />
                          </SelectTrigger>
                          <SelectContent>
                            {availableMembers.map((m) => (
                              <SelectItem key={m.idmembro} value={m.idmembro}>
                                {m.nome}{m.apelido ? ` (${m.apelido})` : ""}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="descricao">Descrição</Label>
                  <Textarea
                    id="descricao"
                    value={formData.descricao}
                    onChange={(e) => setFormData((prev) => ({ ...prev, descricao: e.target.value }))}
                    placeholder="Descreva as atividades e objetivos desta área"
                    rows={3}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={submitting || !formData.nome.trim() || !formData.iddepto || departamentos.length === 0}
                  >
                    {submitting ? "Salvando..." : editingArea ? "Atualizar" : "Criar"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Lista de Áreas */}
      <div className="grid gap-4">
        {loading ? (
          <div className="text-center py-8">Carregando...</div>
        ) : filteredAreas.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma área encontrada</p>
            </CardContent>
          </Card>
        ) : (
          filteredAreas.map((area) => (
            <Card key={`area-${area.idarea}-${area.updated_at || Date.now()}`} className="bg-gradient-card border-border/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Building className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium text-primary truncate">
                        {(area as any).nome_departamento || "Departamento"}
                      </span>
                    </div>
                    <h3 className="font-semibold text-lg break-words">{area.nome}</h3>
                    {area.descricao && (
                      <p className="text-sm text-muted-foreground mt-2 leading-relaxed whitespace-pre-wrap">
                        {area.descricao}
                      </p>
                    )}
                  </div>

                  <div className="flex gap-2 shrink-0">
                    <Button size="sm" variant="outline" onClick={() => openEditDialog(area)} title="Editar">
                      <Edit className="w-4 h-4" />
                    </Button>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="destructive" title="Desativar">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Confirmar desativação</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja desativar a área <strong>"{area.nome}"</strong>? Você pode reativá-la depois.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDelete(area)}>Desativar</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>

                {/* Exibição de líderes da área (se houver) */}
                {((area as any).lider1 || (area as any).lider2) && (
                  <div className="mt-2 space-y-1">
                    {(area as any).lider1 && (
                      <p className="text-sm text-muted-foreground">
                        Líder Principal: <span className="font-medium text-foreground">
                          {membersMap[(area as any).lider1]?.apelido || membersMap[(area as any).lider1]?.nome || (area as any).lider1}
                        </span>
                      </p>
                    )}
                    {(area as any).lider2 && (
                      <p className="text-sm text-muted-foreground">
                        Líder Secundário: <span className="font-medium text-foreground">
                          {membersMap[(area as any).lider2]?.apelido || membersMap[(area as any).lider2]?.nome || (area as any).lider2}
                        </span>
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
