
// src/components/MemberManagement.tsx
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Combobox } from "@/components/ui/combobox";
import { calculateAge, formatDate, getImageUrl } from "@/lib/utils";

import {
  Plus, Edit, Search, X, User, Users, Calendar,
  Mail, Phone, Building, MapPin, ExternalLink
} from "lucide-react";

import FamilyRelationships from "@/components/FamilyRelationships";
import LiderancaInfo from "@/components/LiderancaInfo";
import { useUfCidades } from "@/hooks/useUfCidades";
import { useProfissoes } from "@/hooks/useProfissoes";

/* =========================
   Tipagens
========================= */
type Status = "Ativo" | "Inativo";

interface Member {
  idmembro: string;
  nome: string;
  apelido?: string;
  email?: string;
  telefone?: string;
  nascimento?: string;
  sexo?: string;
  cpf?: string | null;
  cep?: string | null;
  endereco?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null; // Nome da cidade ou ID da tabela cidade
  uf?: string | null;     // "SP", "GO"
  profissao?: string | null;
  estado_civil?: string | null; // Solteiro(a), Casado(a)...
  data_casamento?: string | null;
  conjuge_id?: string | null;
  tipo_membro?: string | null;
  status: Status;
  iddepto?: string | null;
  foto?: string | null;
  ficha_pdf?: string | null;
  entrevista?: string | null;
  entrevistador?: string | null;
  credencial?: string | null;
  created_at?: string;
  updated_at?: string;
  relacionamentos?: Array<{ tipo_relacionamento: string; parente: { nome: string } }>;
}

interface Department { iddepto: string; nome: string; }
interface TipoMembro { tipo: string; }
interface CidadeRow { id: string; uf: string; cidade: string; }

/* =========================
   Helpers de mapeamento
========================= */
const toSexoCode = (v?: string | null) => {
  if (!v) return undefined;
  if (v === "M" || v === "F") return v;
  if (v.toLowerCase().startsWith("masc")) return "M";
  if (v.toLowerCase().startsWith("fem")) return "F";
  return v; // mantém valor cru se for algo diferente
};

const sexoLabel = (v?: string | null) => {
  if (!v) return "";
  if (v === "M") return "Masculino";
  if (v === "F") return "Feminino";
  return v; // se já vier como "Masculino/Feminino" mantém
};

const normalizeMember = (member: any): Member => {
  return {
    ...member,
    status: member.status || "Ativo",
    relacionamentos: member.relacionamentos || []
  };
};

/* =========================
   Componente
========================= */
export default function MemberManagement() {
  /* ------------ estado base ------------ */
  const [members, setMembers] = useState<Member[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [tiposMembro, setTiposMembro] = useState<TipoMembro[]>([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Partial<Member>>({});
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  /* ------------ hooks auxiliares ------------ */
  const { ufs, cidades, fetchCidadesByUf, loadingCidades, buildCidadeNome } = useUfCidades();
  const { profissoes, getProfissaoNome, loading: loadingProfissoes, fetchProfissoes } = useProfissoes();

  useEffect(() => {
    fetchProfissoes();
    fetchTiposMembro();
  }, []);

  const fetchTiposMembro = async () => {
    try {
      const { data, error } = await supabase
        .from("tipos_membro")
        .select("*")
        .order("tipo");

      if (error) throw error;
      setTiposMembro(data || []);
    } catch (err) {
      console.error('Erro ao carregar tipos de membro:', err);
      toast({
        title: "Erro ao carregar tipos de membro",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  useEffect(() => {
    if (formData.uf) {
      fetchCidadesByUf(formData.uf);
      // Reseta a cidade quando o UF muda
      setFormData(prev => ({ ...prev, cidade: null }));
    }
  }, [formData.uf, fetchCidadesByUf]);

  const cidadeNomes = useMemo(() => buildCidadeNome(cidades), [cidades, buildCidadeNome]);

  // Cache para nomes de cidades já buscados
  const [cidadeNamesCache, setCidadeNamesCache] = useState<Record<string, string>>({});

  // Carrega todas as cidades na inicialização para melhor performance
  useEffect(() => {
    const loadAllCidades = async () => {
      try {
        const { data, error } = await supabase
          .from('cidade')
          .select('id, cidade')
          .order('cidade');
        
        if (error) throw error;
        
        const cache = data?.reduce<Record<string, string>>((acc, cidade) => {
          acc[cidade.id] = cidade.cidade;
          return acc;
        }, {}) || {};
        
        setCidadeNamesCache(cache);
      } catch (err) {
        console.error('Erro ao carregar cidades:', err);
      }
    };
    
    loadAllCidades();
  }, []);

  // Função para obter o nome da cidade baseado no ID ou retornar o próprio valor se já for nome
  const getCidadeNome = useCallback((cidadeValue?: string | null) => {
    if (!cidadeValue) return '';
    
    // Se é um ID e temos no cache, retorna o nome
    if (cidadeValue.startsWith('MUN') && cidadeNamesCache[cidadeValue]) {
      return cidadeNamesCache[cidadeValue];
    }
    
    // Se é um ID mas não temos no cache, retorna o ID mesmo
    if (cidadeValue.startsWith('MUN')) {
      return cidadeValue;
    }
    
    // Se já é um nome, retorna direto
    return cidadeValue;
  }, [cidadeNamesCache]);

  // Função síncrona que usa cache
  const getCidadeNomeSync = useCallback((cidadeValue?: string | null) => {
    return getCidadeNome(cidadeValue);
  }, [getCidadeNome]);

  /* ------------ UI estados ------------ */
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showInativos, setShowInativos] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [viewingMember, setViewingMember] = useState<Member | null>(null);

  /* =========================
     Filtragem (busca + inativos)
  ========================= */
  const filteredMembers = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    return members.filter((member) => {
      const matchesSearch =
        member.nome.toLowerCase().includes(term) ||
        (member.apelido && member.apelido.toLowerCase().includes(term));

      // Switch: desligado => só Ativo. Ligado => mostra todos.
      const matchesStatus = showInativos ? true : member.status === "Ativo";

      return matchesSearch && matchesStatus;
    });
  }, [members, searchTerm, showInativos]);

  /* =========================
     Ações do formulário
  ========================= */
  const { userProfile } = useAuth();

  const handleSubmit = async () => {
    if (!formData.nome || !userProfile || !['ADM', 'OPE'].includes(userProfile.permission)) {
      toast({
        title: "Erro ao salvar membro",
        description: !formData.nome ? "Nome é obrigatório" : 
                    !userProfile ? "Usuário não autenticado" : 
                    "Você não tem permissão para salvar membros",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const conjugeId = formData.conjuge_id && !formData.conjuge_id.startsWith('MEM') ?
        members.find(m => m.nome.toLowerCase() === formData.conjuge_id?.toLowerCase())?.idmembro ?? null :
        formData.conjuge_id;

      const profissaoValue = formData.profissao && !formData.profissao.startsWith('prof') ?
        profissoes.find(p => p.profissao.toLowerCase() === formData.profissao?.toLowerCase())?.idprofissao ?? null :
        formData.profissao;

      const memberData = {
        nome: formData.nome,
        apelido: formData.apelido ?? null,
        email: formData.email ?? null,
        telefone: formData.telefone ?? null,
        nascimento: formData.nascimento ?? null,
        sexo: toSexoCode(formData.sexo) ?? null,
        cpf: formData.cpf ?? null,
        cep: formData.cep ?? null,
        endereco: formData.endereco ?? null,
        complemento: formData.complemento ?? null,
        bairro: formData.bairro ?? null,
        cidade: formData.cidade ?? null,
        uf: formData.uf ?? null,
        profissao: profissaoValue ?? null,
        estado_civil: formData.estado_civil ?? null,
        data_casamento: formData.data_casamento ?? null,
        conjuge_id: conjugeId ?? null,
        tipo_membro: formData.tipo_membro ?? null,
        status: (formData.status as Status) ?? "Ativo",
        foto: formData.foto ?? null,
        ficha_pdf: formData.ficha_pdf ?? null,
        entrevista: formData.entrevista ?? null,
        entrevistador: formData.entrevistador ?? null,
        credencial: formData.credencial ?? null,
        updated_at: new Date().toISOString(),
      };

      let result;
      if (editingMember) {
        result = await supabase
          .from("membros")
          .update(memberData)
          .eq("idmembro", editingMember.idmembro);

        if (result.error) throw result.error;
        toast({ title: "Membro atualizado!", description: `${formData.nome} foi atualizado.` });
      } else {
        const { data: lastMember } = await supabase
          .from("membros")
          .select("idmembro")
          .order("idmembro", { ascending: false })
          .limit(1);

        const newId = lastMember && lastMember.length > 0 ?
          `MEM${(parseInt(lastMember[0].idmembro.replace(/\D/g, ""), 10) + 1).toString().padStart(6, "0")}` :
          "MEM000001";

        result = await supabase.from("membros").insert({
          idmembro: newId,
          ...memberData,
          created_at: new Date().toISOString(),
        });

        if (result.error) throw result.error;
        toast({ title: "Membro criado!", description: `${formData.nome} foi adicionado.` });
      }

      setIsDialogOpen(false);
      setEditingMember(null);
      setFormData({
        nome: "",
        apelido: "",
        email: "",
        telefone: "",
        nascimento: "",
        sexo: undefined,
        cpf: null,
        cep: null,
        endereco: null,
        complemento: null,
        bairro: null,
        cidade: null,
        uf: null,
        profissao: null,
        credencial: null,
        estado_civil: null,
        data_casamento: null,
        conjuge_id: null,
        tipo_membro: null,
        status: "Ativo",
        foto: null,
        ficha_pdf: null,
        entrevista: null,
        entrevistador: null,
      });
      await fetchMembers();
    } catch (err) {
      console.error('Erro ao salvar membro:', err);
      toast({
        title: "Erro ao salvar membro",
        description: err instanceof Error ? 
          err.message : 
          typeof err === 'object' && err !== null && 'message' in err ? 
            String(err.message) : 
            "Erro desconhecido ao salvar membro. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("membros")
        .select(`
          *,
          relacionamentos:relacionamentos_familiares!membro_id(
            tipo_relacionamento,
            parente:membros!parente_id(nome)
          )
        `)
        .order("nome");

      if (error) throw error;

      const normalized = (data || []).map(normalizeMember);
      setMembers(normalized);
    } catch (err) {
      toast({
        title: "Erro ao carregar membros",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const openEditDialog = (member: Member) => {
    try {
      setEditingMember(member);
      setFormData({ 
        ...member, 
        sexo: toSexoCode(member.sexo),
        profissao: member.profissao, // usa o ID diretamente
        conjuge_id: member.conjuge_id, // usa o ID diretamente
        cidade: member.cidade // mantém o ID da cidade
      });
      if (member.uf) fetchCidadesByUf(member.uf);
      setIsDialogOpen(true);
    } catch (error) {
      console.error('Error in openEditDialog:', error);
      toast({
        title: "Erro ao abrir edição",
        description: "Não foi possível abrir o formulário de edição",
        variant: "destructive",
      });
    }
  };

  const openViewDialog = (member: Member) => {
    setViewingMember(member);
    setIsViewDialogOpen(true);
  };

  /* =========================
     Render
  ========================= */
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Gestão de Membros
            </CardTitle>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch id="show-inativos" checked={showInativos} onCheckedChange={setShowInativos} />
                <Label htmlFor="show-inativos" className="text-sm text-muted-foreground">
                  Mostrar inativos/desligados
                </Label>
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    className="bg-gradient-primary text-primary-foreground hover:shadow-primary w-full sm:w-auto"
                    onClick={() => {
                      setEditingMember(null);
                      setFormData({
                        nome: "",
                        apelido: "",
                        email: "",
                        telefone: "",
                        nascimento: "",
                        sexo: undefined,
                        cpf: null,
                        cep: null,
                        endereco: null,
                        complemento: null,
                        bairro: null,
                        cidade: null,
                        uf: null,
                        profissao: null,
                        credencial: null,
                        estado_civil: null,
                        data_casamento: null,
                        conjuge_id: null,
                        tipo_membro: null,
                        status: "Ativo",
                        foto: null,
                        ficha_pdf: null,
                        entrevista: null,
                        entrevistador: null,
                      });
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Novo Membro
                  </Button>
                </DialogTrigger>

                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto mt-16 sm:mt-0" onOpenAutoFocus={(e) => e.preventDefault()}>
                  <DialogHeader>
                    <DialogTitle>{editingMember ? "Editar Membro" : "Novo Membro"}</DialogTitle>
                    <DialogDescription>
                      {editingMember ? "Atualize as informações do membro abaixo." : "Preencha as informações para cadastrar um novo membro."}
                    </DialogDescription>
                  </DialogHeader>

                  {/* Cabeçalho do membro em edição */}
                  {editingMember && (
                    <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                      <div className="w-20 h-20 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden">
                        {(() => {
                          const imageUrl = getImageUrl(editingMember.foto);
                          return imageUrl ? (
                            <>
                              <img
                                src={imageUrl}
                                alt={editingMember.nome}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  console.warn('Erro ao carregar imagem:', imageUrl);
                                  e.currentTarget.src = '/placeholder.svg';
                                }}
                              />
                              <div className="w-full h-full bg-muted rounded-full flex items-center justify-center absolute" style={{ display: "none" }}>
                                <User className="w-10 h-10 text-muted-foreground" />
                              </div>
                            </>
                          ) : (
                            <User className="w-10 h-10 text-muted-foreground" />
                          );
                        })()}
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{editingMember.nome}</h3>
                        {editingMember.apelido && <p className="text-sm text-muted-foreground">"{editingMember.apelido}"</p>}
                        {editingMember.nascimento && (
                          <p className="text-sm text-muted-foreground">
                            <Calendar className="w-3 h-3 inline mr-1" />
                            {calculateAge(editingMember.nascimento)}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Formulário */}
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    handleSubmit();
                  }} className="space-y-6">
                    {/* Linha 1: nome / apelido */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="nome">Nome *</Label>
                        <Input id="nome" value={formData.nome || ""} onChange={(e) => setFormData({ ...formData, nome: e.target.value })} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="apelido">Apelido</Label>
                        <Input id="apelido" value={formData.apelido || ""} onChange={(e) => setFormData({ ...formData, apelido: e.target.value })} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">E-mail</Label>
                        <Input id="email" type="email" value={formData.email || ""} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="telefone">Telefone</Label>
                        <Input id="telefone" value={formData.telefone || ""} onChange={(e) => setFormData({ ...formData, telefone: e.target.value })} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="nascimento">Nascimento</Label>
                        <Input
                          id="nascimento"
                          type="date"
                          value={formData.nascimento || ""}
                          onChange={(e) => setFormData({ ...formData, nascimento: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="sexo">Sexo</Label>
                        <Select value={toSexoCode(formData.sexo) || undefined} onValueChange={(v) => setFormData({ ...formData, sexo: v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="M">Masculino</SelectItem>
                            <SelectItem value="F">Feminino</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="cpf">CPF</Label>
                        <Input id="cpf" value={formData.cpf || ""} onChange={(e) => setFormData({ ...formData, cpf: e.target.value })} placeholder="000.000.000-00" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="cep">CEP</Label>
                        <Input id="cep" value={formData.cep || ""} onChange={(e) => setFormData({ ...formData, cep: e.target.value })} placeholder="00000-000" />
                      </div>
                      <div className="space-y-2 sm:col-span-1">
                        <Label htmlFor="endereco">Endereço</Label>
                        <Input id="endereco" value={formData.endereco || ""} onChange={(e) => setFormData({ ...formData, endereco: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="complemento">Complemento</Label>
                        <Input id="complemento" value={formData.complemento || ""} onChange={(e) => setFormData({ ...formData, complemento: e.target.value })} />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="bairro">Bairro</Label>
                        <Input id="bairro" value={formData.bairro || ""} onChange={(e) => setFormData({ ...formData, bairro: e.target.value })} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="uf">UF</Label>
                        <Select value={formData.uf || ""} onValueChange={(v) => setFormData({ ...formData, uf: v, cidade: null })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            {ufs.map((uf) => (
                              <SelectItem key={uf.uf} value={uf.uf}>{uf.uf}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cidade">Cidade</Label>
                        <Select value={formData.cidade || ""} onValueChange={(v) => setFormData({ ...formData, cidade: v })} disabled={!formData.uf}>
                          <SelectTrigger>
                            <SelectValue placeholder={formData.uf ? (loadingCidades ? "Carregando cidades..." : "Selecione a cidade") : "Selecione primeiro o UF"} />
                          </SelectTrigger>
                          <SelectContent>
                            {cidades.map((cidade) => (
                              <SelectItem key={cidade.id} value={cidade.id}>{`${cidade.cidade} - ${cidade.uf}`}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Linha 6: Profissão / Tipo de Membro */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="profissao">Profissão</Label>
                        <Select value={formData.profissao || undefined} onValueChange={(v) => setFormData({ ...formData, profissao: v })}>
                          <SelectTrigger><SelectValue placeholder={loadingProfissoes ? "Carregando profissões..." : "Selecione a profissão"} /></SelectTrigger>
                          <SelectContent>
                            {profissoes.map((p) => (
                              <SelectItem key={p.idprofissao} value={p.idprofissao}>{p.profissao}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="tipo_membro">Tipo de Membro</Label>
                        <Select value={formData.tipo_membro || undefined} onValueChange={(v) => setFormData({ ...formData, tipo_membro: v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            {tiposMembro.map((t) => (
                              <SelectItem key={t.tipo} value={t.tipo}>{t.tipo}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="estado_civil">Estado Civil</Label>
                        <Select
                          value={formData.estado_civil || undefined}
                          onValueChange={(v) => setFormData({ ...formData, estado_civil: v })}
                        >
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Solteiro(a)">Solteiro(a)</SelectItem>
                            <SelectItem value="Casado(a)">Casado(a)</SelectItem>
                            <SelectItem value="Divorciado(a)">Divorciado(a)</SelectItem>
                            <SelectItem value="Viúvo(a)">Viúvo(a)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="data_casamento">Data do Casamento</Label>
                        <Input
                          id="data_casamento"
                          type="date"
                          value={formData.data_casamento || ""}
                          onChange={(e) => setFormData({ ...formData, data_casamento: e.target.value })}
                          disabled={formData.estado_civil !== "Casado(a)"}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="status">Status</Label>
                        <Select value={formData.status || "Ativo"} onValueChange={(v) => setFormData({ ...formData, status: v as Status })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Ativo">Ativo</SelectItem>
                            <SelectItem value="Inativo">Inativo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="credencial">Credencial</Label>
                        <Input
                          id="credencial"
                          type="date"
                          value={formData.credencial || ""}
                          onChange={(e) => setFormData({ ...formData, credencial: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="entrevista">Entrevista</Label>
                        <Select value={formData.entrevista || undefined} onValueChange={(v) => setFormData({ ...formData, entrevista: v === "none" ? null : v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">Selecionar</SelectItem>
                            <SelectItem value="Sim">Sim</SelectItem>
                            <SelectItem value="Não">Não</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="entrevistador">Entrevistador</Label>
                        <Select value={formData.entrevistador || undefined} onValueChange={(v) => setFormData({ ...formData, entrevistador: v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Não">Não</SelectItem>
                            <SelectItem value="Sim">Sim</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="foto">Foto (arquivo ou URL)</Label>
                        <div className="flex gap-2">
                          <Input
                            id="foto"
                            value={formData.foto || ""}
                            onChange={(e) => setFormData({ ...formData, foto: e.target.value })}
                            placeholder="URL da foto"
                            className="flex-1"
                          />
                          <input
                            id="foto-upload"
                            type="file"
                            accept="image/png,image/jpeg,image/jpg"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              try {
                                setUploading(true);
                                // Sanitiza o nome do arquivo para evitar espaços e caracteres especiais
                                const baseName = file.name
                                  .normalize('NFKD')
                                  .replace(/[^\w.-]+/g, '-')
                                  .replace(/\s+/g, '-')
                                  .toLowerCase();
                                const fileName = `${Date.now()}-${baseName}`;
                                const { error } = await supabase.storage.from("member-photos").upload(fileName, file, {
                                  contentType: file.type || 'image/jpeg',
                                  upsert: true,
                                });
                                if (error) throw error;
                                setFormData({ ...formData, foto: fileName });
                                toast({ title: "Foto enviada com sucesso!" });
                              } catch {
                                toast({ title: "Erro no upload da foto", variant: "destructive" });
                              } finally {
                                setUploading(false);
                              }
                            }}
                          />
                          <Button type="button" variant="outline" onClick={() => document.getElementById("foto-upload")?.click()}>
                            📁
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="ficha_pdf">Ficha PDF (arquivo ou URL)</Label>
                        <div className="flex gap-2">
                          <Input
                            id="ficha_pdf"
                            value={formData.ficha_pdf || ""}
                            onChange={(e) => setFormData({ ...formData, ficha_pdf: e.target.value })}
                            placeholder="URL da ficha PDF"
                            className="flex-1"
                          />
                          <input
                            id="ficha-pdf-upload"
                            type="file"
                            accept="application/pdf"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              try {
                                setUploading(true);
                                const baseName = file.name
                                  .normalize('NFKD')
                                  .replace(/[^\w.-]+/g, '-')
                                  .replace(/\s+/g, '-')
                                  .toLowerCase();
                                const fileName = `${Date.now()}-${baseName}`;
                                const { error } = await supabase.storage.from("member-files").upload(fileName, file, {
                                  contentType: 'application/pdf',
                                  upsert: true,
                                });
                                if (error) throw error;
                                setFormData({ ...formData, ficha_pdf: fileName });
                                toast({ title: "Ficha PDF enviada com sucesso!" });
                              } catch {
                                toast({ title: "Erro no upload da ficha PDF", variant: "destructive" });
                              } finally {
                                setUploading(false);
                              }
                            }}
                          />
                          <Button type="button" variant="outline" onClick={() => document.getElementById("ficha-pdf-upload")?.click()}>
                            📁
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Familiares (apenas quando editando) */}
                    {editingMember && (
                      <div className="mt-6 pt-6 border-t">
                        <FamilyRelationships membroId={editingMember.idmembro} membroNome={editingMember.nome} />
                      </div>
                    )}

                    <div className="flex flex-col sm:flex-row justify-end gap-2 pt-6">
                      <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button type="submit" className="bg-gradient-primary" disabled={uploading}>
                        {uploading ? "Salvando..." : editingMember ? "Atualizar" : "Criar"} Membro
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {/* Busca */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar por nome ou apelido..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-4 w-[200px]" />
                  <Skeleton className="h-4 w-[150px]" />
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-4 w-[120px]" />
                </div>
              ))}
            </div>
          ) : filteredMembers.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Nenhum membro encontrado</p>
              <p className="text-sm">{searchTerm || !showInativos ? "Tente ajustar os filtros" : "Cadastre o primeiro membro"}</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {filteredMembers.map((member) => (
                <Card key={member.idmembro} className="p-4 border border-border/50">
                  <div className="flex items-start gap-4">
                    {/* Foto */}
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                      {(() => {
                        const imageUrl = getImageUrl(member.foto);
                        return imageUrl ? (
                          <img
                            src={imageUrl}
                            alt={member.nome}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              console.warn('Erro ao carregar imagem:', imageUrl);
                              e.currentTarget.src = '/placeholder.svg';
                            }}
                          />
                        ) : (
                          <User className="w-8 h-8 text-muted-foreground" />
                        );
                      })()}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-lg leading-tight">{member.nome}</h3>
                        <div className="hidden sm:flex gap-2 ml-4">
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => openViewDialog(member)}
                            className="h-8 px-3 text-xs bg-gradient-primary hover:shadow-primary"
                          >
                            <User className="w-3 h-3 mr-1" />
                            Ver Perfil
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => openEditDialog(member)} className="h-8 px-3 text-xs hover:bg-muted">
                            <Edit className="w-3 h-3 mr-1" />
                            Editar
                          </Button>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 mb-3">
                        {member.apelido && <span className="text-sm text-muted-foreground">"{member.apelido}"</span>}
                        <Badge variant={member.status === "Ativo" ? "default" : "secondary"} className="text-xs w-fit">
                          {member.status}
                        </Badge>
                        {member.tipo_membro && (
                          <Badge variant="outline" className="text-xs w-fit">
                            {member.tipo_membro}
                          </Badge>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                        {member.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="w-3 h-3 flex-shrink-0" />
                            <span className="truncate">{member.email}</span>
                          </div>
                        )}
                        {member.telefone && (
                          <div className="flex items-center gap-2">
                            <Phone className="w-3 h-3 flex-shrink-0" />
                            <span>{member.telefone}</span>
                          </div>
                        )}

                        {member.sexo && (
                          <div className="flex items-center gap-2">
                            <User className="w-3 h-3 flex-shrink-0" />
                            <span>{sexoLabel(member.sexo)}</span>
                          </div>
                        )}

                        {member.nascimento && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-3 h-3 flex-shrink-0" />
                            <span>{calculateAge(member.nascimento)}</span>
                          </div>
                        )}

                        {(member.cidade || member.uf) && (
                          <div className="flex items-center gap-2 col-span-full sm:col-span-1">
                            <MapPin className="w-3 h-3 flex-shrink-0" />
                            <span>
                              {getCidadeNomeSync(member.cidade)}
                              {member.uf ? ` - ${member.uf}` : ""}
                            </span>
                          </div>
                        )}

                        {/* --- Família no Card (resumo) --- */}
                        {member.relacionamentos && member.relacionamentos.length > 0 && (
                          <div className="col-span-full">
                            <div className="flex items-start gap-2">
                              <Users className="w-3 h-3 flex-shrink-0 text-blue-500 mt-0.5" />
                              <div className="text-xs">
                                <span className="font-medium">Família:</span>
                                <div className="mt-1 space-y-1">
                                  {member.relacionamentos.slice(0, 3).map((rel, index) => (
                                    <div key={index} className="text-muted-foreground">
                                      • {rel.parente.nome} ({rel.tipo_relacionamento})
                                    </div>
                                  ))}
                                  {member.relacionamentos.length > 3 && (
                                    <div className="text-muted-foreground">
                                      • +{member.relacionamentos.length - 3} outros familiares
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Ações (mobile) */}
                      <div className="flex gap-2 mt-3 sm:hidden">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => openViewDialog(member)}
                          className="h-8 px-2 text-xs flex-1 bg-gradient-primary hover:shadow-primary"
                        >
                          <User className="w-3 h-3 mr-1" />
                          Ver Perfil
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => openEditDialog(member)} className="h-8 px-2 text-xs flex-1 hover:bg-muted">
                          <Edit className="w-3 h-3 mr-1" />
                          Editar
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de visualização */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto mt-16 sm:mt-0" onOpenAutoFocus={(e) => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle>Visualizar Membro</DialogTitle>
          </DialogHeader>

          {viewingMember && (
            <div className="space-y-6">
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <div className="w-20 h-20 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden">
                  {(() => {
                    const imageUrl = getImageUrl(viewingMember.foto);
                    return imageUrl ? (
                      <img 
                        src={imageUrl} 
                        alt={viewingMember.nome} 
                        className="w-full h-full object-cover" 
                        onError={(e) => {
                          console.warn('Erro ao carregar imagem:', imageUrl);
                          e.currentTarget.src = '/placeholder.svg';
                        }}
                      />
                    ) : (
                      <User className="w-10 h-10 text-muted-foreground" />
                    );
                  })()}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{viewingMember.nome}</h3>
                  {viewingMember.apelido && <p className="text-muted-foreground">"{viewingMember.apelido}"</p>}
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={viewingMember.status === "Ativo" ? "default" : "secondary"}>{viewingMember.status}</Badge>
                    {viewingMember.tipo_membro && <Badge variant="outline">{viewingMember.tipo_membro}</Badge>}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Informações Pessoais</h4>
                  {viewingMember.email && (
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <span>{viewingMember.email}</span>
                    </div>
                  )}
                  {viewingMember.telefone && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <span>{viewingMember.telefone}</span>
                    </div>
                  )}
                  {viewingMember.nascimento && (
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>
                        {formatDate(viewingMember.nascimento)} ({calculateAge(viewingMember.nascimento)})
                      </span>
                    </div>
                  )}
                  {viewingMember.sexo && (
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span>{sexoLabel(viewingMember.sexo)}</span>
                    </div>
                  )}
                  {viewingMember.profissao && (
                    <div className="flex items-center gap-3">
                      <Building className="w-4 h-4 text-muted-foreground" />
                      <span>{getProfissaoNome(viewingMember.profissao)}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Endereço</h4>
                  {(viewingMember.endereco || viewingMember.bairro || viewingMember.cidade || viewingMember.uf) && (
                    <div className="bg-muted/30 p-4 rounded-lg space-y-2">
                      {viewingMember.cep && <p><strong>CEP:</strong> {viewingMember.cep}</p>}
                      {viewingMember.endereco && <p><strong>Endereço:</strong> {viewingMember.endereco}</p>}
                      {viewingMember.complemento && <p><strong>Complemento:</strong> {viewingMember.complemento}</p>}
                      {viewingMember.bairro && <p><strong>Bairro:</strong> {viewingMember.bairro}</p>}
                      <div className="flex gap-4">
                        {viewingMember.cidade && <p><strong>Cidade:</strong> {getCidadeNomeSync(viewingMember.cidade)}</p>}
                        {viewingMember.uf && <p><strong>UF:</strong> {viewingMember.uf}</p>}
                      </div>
                      {(viewingMember.endereco || viewingMember.bairro || viewingMember.cidade || viewingMember.uf) && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-3 gap-2"
                          onClick={() => {
                            const endereco = `${viewingMember.endereco || ""}, ${viewingMember.bairro || ""}, ${getCidadeNomeSync(viewingMember.cidade) || ""}, ${viewingMember.uf || ""}`
                              .replace(/,\s*,/g, ",")
                              .replace(/^,\s*|,\s*$/g, "");
                            window.open(`https://www.google.com/maps/search/${encodeURIComponent(endereco)}`, "_blank");
                          }}
                        >
                          <MapPin className="w-4 h-4" />
                          Ver no Google Maps
                          <ExternalLink className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <LiderancaInfo membroId={viewingMember.idmembro} />

              <div className="mt-6">
                <FamilyRelationships membroId={viewingMember.idmembro} membroNome={viewingMember.nome} allowAdd={false} />
              </div>

              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Fechar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
