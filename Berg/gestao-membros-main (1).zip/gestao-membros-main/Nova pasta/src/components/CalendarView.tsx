import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { toast } from "@/hooks/use-toast";
import {
  Calendar,
  MapPin,
  Clock,
  X,
  Plus,
  ChevronsUpDown,
  Check,
  Circle,
  Pencil,
  Trash2,
  Camera,
  Images,
} from "lucide-react";
import { cn } from "@/lib/utils";

/** Tipagens básicas */
interface User {
  email: string;
  permission: string;
}
interface CalendarViewProps {
  user: User;
  month: number; // 0-11
  year: number;  // ex.: 2025
}
export interface AgendaItem {
  idagenda: string;
  data: string;
  horario_inicial?: string | null;
  horario_final?: string | null;
  observacao?: string | null;
  descricao?: string | null;

  idlocal?: string | null;
  iddepto?: string | null;
  ideventoig?: string | null;
  idstatus?: string | null;
  idlider?: string | null;

  nome_evento?: string;
  nome_local?: string;
  departamento?: string;
  status_evento?: string;
  cor_evento?: string;
  nome_lider?: string;
}
type Option = { id: string; label: string; extra?: any };

const WEEK_DAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

/* ===== Helpers de data/cores ===== */
const parseDate = (v?: string): Date => {
  if (!v) return new Date(0);
  if (v.includes("/")) {
    const [dd, mm, yyyy] = v.split("/");
    return new Date(`${yyyy}-${mm}-${dd}T00:00:00`);
  }
  const s = v.substring(0, 10);
  return new Date(`${s}T00:00:00`);
};
const formatTime = (t?: string | null) => (t ? t.slice(0, 5) : "");
const formatDateBR = (d: Date) =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" }).format(d);
const toISODate = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const colorFromKey = (key: string, lightness = 85) => {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) % 360;
  return `hsl(${h},70%,${lightness}%)`;
};

const pickLabel = (row: any, keys: string[], fallback = "") => {
  for (const k of keys) {
    const v = row?.[k];
    if (v != null && String(v).trim() !== "") return String(v);
  }
  return fallback;
};
const byLabelAsc = (a: Option, b: Option) =>
  a.label.localeCompare(b.label, "pt-BR", { sensitivity: "base" });

/* ===== Quick-create helpers (corrigidos) ===== */
async function addEventoIgreja(nome: string): Promise<{ ok: boolean; id?: string; err?: string }> {
  // Tentativas com mais nomes comuns de coluna
  const candidates = [
    "nome",
    "nome_evento",
    "titulo",
    "evento",
    "descricao",
    "descricao_evento",
    "tipo",
    "tipo_evento",
  ] as const;

  for (const col of candidates) {
    try {
      const payload: any = { [col]: nome };
      const { data, error } = await supabase
        .from("eventos_igreja")
        .insert(payload)
        .select("ideventoig")
        .single();

      if (!error) {
        return { ok: true, id: data?.ideventoig ? String(data.ideventoig) : undefined };
      }
    } catch {
      // tenta próxima coluna
    }
  }

  return {
    ok: false,
    err: "Não consegui gravar em nenhuma coluna (nome/nome_evento/titulo/evento/descricao/descricao_evento/tipo/tipo_evento).",
  };
}

async function addLocal(nome: string): Promise<{ ok: boolean; id?: string; err?: string }> {
  const candidates = [
    "nome",
    "nomelocal",
    "nome_local",
    "nome_do_local",
    "local",
    "titulo",
    "descricao",
    "descricao_local",
    "apelido",
  ] as const;

  for (const col of candidates) {
    try {
      const payload: any = { [col]: nome };
      const { data, error } = await supabase
        .from("locais")
        .insert(payload)
        .select("idlocal")
        .single();

      if (!error) {
        return { ok: true, id: data?.idlocal ? String(data.idlocal) : undefined };
      }
    } catch {
      // tenta próxima coluna
    }
  }

  return {
    ok: false,
    err: "Não consegui gravar em nenhuma coluna (nome/nomelocal/nome_local/nome_do_local/local/titulo/descricao/descricao_local/apelido).",
  };
}

/* ===== Fotos do evento (bucket: agenda-photos) ===== */
type PhotoCache = Record<string, string[]>;
type PhotoLoading = Record<string, boolean>;

export default function CalendarView({ user, month, year }: CalendarViewProps) {
  const [allEvents, setAllEvents] = useState<AgendaItem[]>([]);
  const [loading, setLoading] = useState(false);

  const [selectedDay, setSelectedDay] = useState<Date | null>(null);

  const [locais, setLocais] = useState<Option[]>([]);
  const [departamentos, setDepartamentos] = useState<Option[]>([]);
  const [eventosIgreja, setEventosIgreja] = useState<Option[]>([]);
  const [statusAgenda, setStatusAgenda] = useState<Option[]>([]);
  const [lideres, setLideres] = useState<Option[]>([]);

  const [openLeaderBox, setOpenLeaderBox] = useState(false);
  const [openEventoBox, setOpenEventoBox] = useState(false);
  const [openLocalBox, setOpenLocalBox] = useState(false);
  const [openDeptoBox, setOpenDeptoBox] = useState(false);
  const [openStatusBox, setOpenStatusBox] = useState(false);

  const [openCreate, setOpenCreate] = useState(false);
  const [createForm, setCreateForm] = useState({
    data: "",
    horario_inicial: "",
    horario_final: "",
    idlocal: "",
    iddepto: "",
    ideventoig: "",
    idstatus: "",
    idlider: "",
    observacao: "",
    descricao: "",
  });
  const [saving, setSaving] = useState(false);

  const [openEdit, setOpenEdit] = useState(false);
  const [editing, setEditing] = useState<AgendaItem | null>(null);
  const [editForm, setEditForm] = useState({
    idagenda: "",
    data: "",
    horario_inicial: "",
    horario_final: "",
    idlocal: "",
    iddepto: "",
    ideventoig: "",
    idstatus: "",
    idlider: "",
    observacao: "",
    descricao: "",
  });
  const [updating, setUpdating] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [openAddEvento, setOpenAddEvento] = useState(false);
  const [openAddLocal, setOpenAddLocal] = useState(false);
  const [novoEvento, setNovoEvento] = useState("");
  const [novoLocal, setNovoLocal] = useState("");
  const [adding, setAdding] = useState(false);

  const [photoCache, setPhotoCache] = useState<PhotoCache>({});
  const [photoLoading, setPhotoLoading] = useState<PhotoLoading>({});
  const [hoverPreview, setHoverPreview] = useState<{ id?: string; x: number; y: number } | null>(null);
  const hoverTimers = useRef<Record<string, number>>({});

  /* ========= Carregar dicionários ========= */
  const loadDictionaries = async () => {
    const { data: loc } = await supabase.from("locais").select("*");
    const locOpts: Option[] =
      (loc || []).map((r: any) => {
        let label =
          pickLabel(r, ["nome", "nomelocal", "nome_local", "local", "apelido", "label", "titulo", "descricao"], "") ||
          "";
        if (!label) {
          const parts = [r.endereco, r.bairro, r.cidade, r.uf].filter(Boolean);
          label = parts.join(" • ");
        }
        if (!label) label = "Local";
        return { id: String(r.idlocal ?? r.id ?? r.codigo ?? ""), label };
      }) || [];
    setLocais(locOpts.sort(byLabelAsc));

    const { data: dept } = await supabase.from("departamentos").select("*");
    const deptOpts: Option[] =
      (dept || []).map((r: any) => ({
        id: String(r.iddepto ?? r.id ?? ""),
        label: pickLabel(r, ["nome", "descricao", "titulo"], "Departamento"),
      })) || [];
    setDepartamentos(deptOpts.sort(byLabelAsc));

    const { data: ev } = await supabase.from("eventos_igreja").select("*");
    const evOpts: Option[] =
      (ev || []).map((r: any) => ({
        id: String(r.ideventoig ?? r.id ?? ""),
        label: pickLabel(r, ["nome", "nome_evento", "evento", "titulo", "descricao"], "Evento"),
      })) || [];
    setEventosIgreja(evOpts.sort(byLabelAsc));

    const { data: st } = await supabase.from("status_agenda").select("*");
    const stOpts: Option[] =
      (st || []).map((r: any) => ({
        id: String(r.idstatus ?? r.id ?? ""),
        label: pickLabel(r, ["status", "nome", "titulo"], "Status"),
        extra: { cor: r.cor || "" },
      })) || [];
    setStatusAgenda(stOpts.sort(byLabelAsc));

    const { data: lid } = await supabase
      .from("lideres")
      .select("idlider, status, membros:idmembro (idmembro, nome, apelido)")
      .eq("status", "Ativo");

    const mapByMember = new Map<string, Option>();
    (lid || []).forEach((r: any) => {
      const idmembro = String(r?.membros?.idmembro || "");
      if (!idmembro) return;
      if (mapByMember.has(idmembro)) return;
      const label = pickLabel(r?.membros || {}, ["apelido", "nome"], "Líder");
      mapByMember.set(idmembro, { id: String(r.idlider), label, extra: { idmembro } });
    });
    const lidOpts = Array.from(mapByMember.values()).sort(byLabelAsc);
    setLideres(lidOpts);

    const byId = (arr: Option[]) => Object.fromEntries(arr.map((o) => [o.id, o]));
    return {
      mapLoc: byId(locOpts),
      mapDept: byId(deptOpts),
      mapEv: byId(evOpts),
      mapSt: Object.fromEntries(stOpts.map((o) => [o.id, { label: o.label, cor: o.extra?.cor || "" }])),
      mapLid: byId(lidOpts),
    } as const;
  };

  /* ========= Carregar agenda ========= */
  const fetchAgenda = async () => {
    setLoading(true);
    try {
      const dicts = await loadDictionaries();
      const { data, error } = await supabase
        .from("agenda")
        .select("idagenda,data,horario_inicial,horario_final,observacao,descricao,idlocal,iddepto,ideventoig,idstatus,idlider");
      if (error) throw error;

      const rows = (data || []) as any[];
      const resolved: AgendaItem[] = rows.map((r) => {
        const evOpt = dicts.mapEv[String(r.ideventoig)];
        const locOpt = dicts.mapLoc[String(r.idlocal)];
        const deptOpt = dicts.mapDept[String(r.iddepto)];
        const stObj = dicts.mapSt[String(r.idstatus)] || { label: "", cor: "" };
        const lidOpt = dicts.mapLid[String(r.idlider)];
        return {
          idagenda: String(r.idagenda),
          data: String(r.data),
          horario_inicial: r.horario_inicial || null,
          horario_final: r.horario_final || null,
          observacao: r.observacao || null,
          descricao: r.descricao || null,
          idlocal: r.idlocal || null,
          iddepto: r.iddepto || null,
          ideventoig: r.ideventoig || null,
          idstatus: r.idstatus || null,
          idlider: r.idlider || null,
          nome_evento: evOpt?.label || "",
          nome_local: locOpt?.label || "",
          departamento: deptOpt?.label || "",
          status_evento: stObj.label || "",
          cor_evento: stObj.cor || "",
          nome_lider: lidOpt?.label || "",
        };
      });

      setAllEvents(resolved);
    } catch (err) {
      toast({
        title: "Erro ao carregar agenda",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAgenda();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ========= Faixas de mês e agrupamento ========= */
  const range = useMemo(() => {
    const start = new Date(year, month, 1).getTime();
    const end = new Date(year, month + 1, 1).getTime();
    return { start, end };
  }, [month, year]);

  const events = useMemo(() => {
    return (allEvents || [])
      .filter((e) => {
        const t = parseDate(e.data).getTime();
        return t >= range.start && t < range.end;
      })
      .sort((a, b) => {
        const ta = parseDate(a.data).getTime();
        const tb = parseDate(b.data).getTime();
        if (ta !== tb) return ta - tb;
        return (a.horario_inicial || "").localeCompare(b.horario_inicial || "");
      });
  }, [allEvents, range]);

  const eventsByDay = useMemo(() => {
    const map: Record<number, AgendaItem[]> = {};
    for (const ev of events) {
      const d = parseDate(ev.data).getDate();
      (map[d] ||= []).push(ev);
    }
    return map;
  }, [events]);

  const calendarMatrix = useMemo(() => {
    const firstDay = new Date(year, month, 1);
    const lastDayNum = new Date(year, month + 1, 0).getDate();
    const startWeekday = firstDay.getDay();

    const blanks = Array.from({ length: startWeekday }, (_, i) => ({ blank: true, key: `b-${i}` })) as any[];
    const days = Array.from({ length: lastDayNum }, (_, i) => ({ date: new Date(year, month, i + 1), day: i + 1 }));

    const cells = [...blanks, ...days];
    const rows: any[][] = [];
    for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
    return rows;
  }, [month, year]);

  const selectedDayEvents = useMemo(() => {
    if (!selectedDay) return [];
    return eventsByDay[selectedDay.getDate()] || [];
  }, [selectedDay, eventsByDay]);

  /* ========= Cores por evento ========= */
  const eventColors = (ev: AgendaItem) => {
    const baseKey = ev.ideventoig || ev.idagenda || "x";
    const border = ev.cor_evento || colorFromKey(String(baseKey), 45);
    const bg = ev.cor_evento ? colorFromKey(ev.cor_evento + baseKey, 92) : colorFromKey(String(baseKey), 90);
    return { border, bg };
  };

  /* ========= Criação ========= */
  const openCreateDialog = () => {
    const hoje = toISODate(new Date());
    setCreateForm((p) => ({
      ...p,
      data: hoje,
      idstatus: p.idstatus || statusAgenda[0]?.id || "",
    }));
    setOpenCreate(true);
  };

  const handleCreateEvent = async () => {
    if (!createForm.data || !createForm.ideventoig) {
      return toast({
        title: "Campos obrigatórios",
        description: "Selecione a data e o nome do evento.",
        variant: "destructive",
      });
    }
    const finalStatus = createForm.idstatus || (statusAgenda[0]?.id ?? "");
    const toNull = (v: string) => (v && v.trim() !== "" ? v : null);

    const payload: any = {
      data: createForm.data,
      horario_inicial: toNull(createForm.horario_inicial),
      horario_final: toNull(createForm.horario_final),
      observacao: toNull(createForm.observacao),
      descricao: toNull(createForm.descricao),
      idlocal: toNull(createForm.idlocal),
      iddepto: toNull(createForm.iddepto),
      ideventoig: toNull(createForm.ideventoig),
      idstatus: toNull(finalStatus),
      idlider: toNull(createForm.idlider),
    };

    setSaving(true);
    try {
      const { error } = await supabase.from("agenda").insert([payload]);
      if (error) throw error;
      toast({ title: "Evento criado!", description: "A agenda foi atualizada." });
      setOpenCreate(false);
      setCreateForm({
        data: toISODate(new Date()),
        horario_inicial: "",
        horario_final: "",
        idlocal: "",
        iddepto: "",
        ideventoig: "",
        idstatus: statusAgenda[0]?.id || "",
        idlider: "",
        observacao: "",
        descricao: "",
      });
      await fetchAgenda();
    } catch (e: any) {
      toast({
        title: "Erro ao criar evento",
        description: e?.message || "Falha ao salvar o evento",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  /* ========= Edição ========= */
  const openEditDialog = (ev: AgendaItem) => {
    setEditing(ev);
    setEditForm({
      idagenda: ev.idagenda,
      data: ev.data ? ev.data.substring(0, 10) : "",
      horario_inicial: ev.horario_inicial || "",
      horario_final: ev.horario_final || "",
      idlocal: ev.idlocal || "",
      iddepto: ev.iddepto || "",
      ideventoig: ev.ideventoig || "",
      idstatus: ev.idstatus || "",
      idlider: ev.idlider || "",
      observacao: ev.observacao || "",
      descricao: ev.descricao || "",
    });
    setOpenEdit(true);
  };

  const handleUpdateEvent = async () => {
    if (!editForm.idagenda) return;
    const toNull = (v: string) => (v && v.trim() !== "" ? v : null);
    const payload: any = {
      data: editForm.data,
      horario_inicial: toNull(editForm.horario_inicial),
      horario_final: toNull(editForm.horario_final),
      observacao: toNull(editForm.observacao),
      descricao: toNull(editForm.descricao),
      idlocal: toNull(editForm.idlocal),
      iddepto: toNull(editForm.iddepto),
      ideventoig: toNull(editForm.ideventoig),
      idstatus: toNull(editForm.idstatus),
      idlider: toNull(editForm.idlider),
    };
    setUpdating(true);
    try {
      const { error } = await supabase.from("agenda").update(payload).eq("idagenda", editForm.idagenda);
      if (error) throw error;
      toast({ title: "Evento atualizado!" });
      setOpenEdit(false);
      setEditing(null);
      await fetchAgenda();
    } catch (e: any) {
      toast({
        title: "Erro ao atualizar",
        description: e?.message || "Falha ao salvar alterações",
        variant: "destructive",
      });
    } finally {
      setUpdating(false);
    }
  };

  const handleDeleteEvent = async (idagenda: string) => {
    if (!confirm("Tem certeza que deseja excluir este evento?")) return;
    setDeletingId(idagenda);
    try {
      const { error } = await supabase.from("agenda").delete().eq("idagenda", idagenda);
      if (error) throw error;
      toast({ title: "Evento excluído!" });
      await fetchAgenda();
    } catch (e: any) {
      toast({
        title: "Erro ao excluir",
        description: e?.message || "Falha ao excluir o evento",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  /* ========= Fotos ========= */
  const ensurePhotos = async (idagenda: string) => {
    if (photoCache[idagenda] || photoLoading[idagenda]) return;
    setPhotoLoading((p) => ({ ...p, [idagenda]: true }));
    try {
      const { data, error } = await supabase.storage
        .from("agenda-photos")
        .list(`${idagenda}`, { sortBy: { column: "name", order: "asc" } });
      if (error) throw error;

      const urls =
        (data || [])
          .filter((f) => f.name && !f.name.endsWith("/"))
          .slice(0, 6)
          .map((f) => {
            const { data: pub } = supabase.storage.from("agenda-photos").getPublicUrl(`${idagenda}/${f.name}`);
            return pub.publicUrl;
          }) || [];
      setPhotoCache((p) => ({ ...p, [idagenda]: urls }));
    } catch {
      /* silencioso */
    } finally {
      setPhotoLoading((p) => ({ ...p, [idagenda]: false }));
    }
  };

  const onEventMouseEnter = (ev: AgendaItem, e: React.MouseEvent) => {
    const id = ev.idagenda;
    const t = window.setTimeout(() => {
      ensurePhotos(id);
      const rect = (e.target as HTMLElement).getBoundingClientRect();
      setHoverPreview({ id, x: rect.left + rect.width + 8, y: rect.top });
    }, 120);
    hoverTimers.current[id] = t;
  };
  const onEventMouseLeave = (ev: AgendaItem) => {
    const id = ev.idagenda;
    const t = hoverTimers.current[id];
    if (t) window.clearTimeout(t);
    setHoverPreview((cur) => (cur?.id === id ? null : cur));
  };

  /* ========= Render ========= */
  return (
    <div className="w-full relative">
      {/* Ações */}
      <div className="flex items-center justify-end mb-2 gap-2">
        <Dialog open={openCreate} onOpenChange={setOpenCreate}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog} className="bg-gradient-primary hover:shadow-primary">
              <Plus className="w-4 h-4 mr-2" />
              Incluir Evento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Novo Evento</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              {/* Data/Horas */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <Label>Data *</Label>
                  <Input
                    type="date"
                    value={createForm.data}
                    onChange={(e) => setCreateForm((p) => ({ ...p, data: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label>Hora início</Label>
                  <Input
                    type="time"
                    value={createForm.horario_inicial}
                    onChange={(e) => setCreateForm((p) => ({ ...p, horario_inicial: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Hora fim</Label>
                  <Input
                    type="time"
                    value={createForm.horario_final}
                    onChange={(e) => setCreateForm((p) => ({ ...p, horario_final: e.target.value }))}
                  />
                </div>
              </div>

              {/* Evento + Local */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Evento + */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <Label>Nome do evento *</Label>
                    <Dialog open={openAddEvento} onOpenChange={setOpenAddEvento}>
                      <DialogTrigger asChild>
                        {/* botão + bonito */}
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          className="h-9 w-9 rounded-full border-primary/30 hover:bg-primary/10 hover:border-primary/60 shadow-sm"
                          title="Adicionar evento"
                        >
                          <Plus className="w-5 h-5 text-primary" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle>Novo evento</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-3">
                          <Input
                            placeholder="Nome do evento"
                            value={novoEvento}
                            onChange={(e) => setNovoEvento(e.target.value)}
                          />
                        </div>
                        <DialogFooter className="gap-2">
                          <Button variant="outline" onClick={() => setOpenAddEvento(false)}>
                            Cancelar
                          </Button>
                          <Button
                            onClick={async () => {
                              if (!novoEvento.trim()) return;
                              setAdding(true);
                              const res = await addEventoIgreja(novoEvento.trim());
                              setAdding(false);
                              if (!res.ok) {
                                toast({
                                  title: "Não foi possível criar o evento",
                                  description: res.err,
                                  variant: "destructive",
                                });
                                return;
                              }
                              toast({ title: "Evento criado!" });
                              setOpenAddEvento(false);
                              setNovoEvento("");
                              await fetchAgenda();
                              if (res.id) setCreateForm((p) => ({ ...p, ideventoig: res.id! }));
                            }}
                            disabled={adding}
                          >
                            {adding ? "Salvando..." : "Adicionar"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <Popover open={openEventoBox} onOpenChange={setOpenEventoBox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openEventoBox}
                        className="w-full justify-between"
                      >
                        <span className="truncate max-w-[85%]">
                          {createForm.ideventoig
                            ? eventosIgreja.find((o) => o.id === createForm.ideventoig)?.label
                            : "Selecione o evento"}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                      <Command>
                        <CommandInput placeholder="Buscar evento..." />
                        <CommandList>
                          <CommandEmpty>Nenhum evento encontrado.</CommandEmpty>
                          <CommandGroup>
                            {eventosIgreja.map((o) => (
                              <CommandItem
                                key={o.id}
                                value={o.label}
                                onSelect={() => {
                                  setCreateForm((p) => ({ ...p, ideventoig: o.id }));
                                  setOpenEventoBox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    createForm.ideventoig === o.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <span className="truncate">{o.label}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Local + (mesmo efeito do evento) */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <Label>Local</Label>
                    <Dialog open={openAddLocal} onOpenChange={setOpenAddLocal}>
                      <DialogTrigger asChild>
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          className="h-9 w-9 rounded-full border-primary/30 hover:bg-primary/10 hover:border-primary/60 shadow-sm"
                          title="Adicionar local"
                        >
                          <Plus className="w-5 h-5 text-primary" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle>Novo local</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-3">
                          <Input
                            placeholder="Nome do local"
                            value={novoLocal}
                            onChange={(e) => setNovoLocal(e.target.value)}
                          />
                        </div>
                        <DialogFooter className="gap-2">
                          <Button variant="outline" onClick={() => setOpenAddLocal(false)}>
                            Cancelar
                          </Button>
                          <Button
                            onClick={async () => {
                              if (!novoLocal.trim()) return;
                              setAdding(true);
                              const res = await addLocal(novoLocal.trim());
                              setAdding(false);
                              if (!res.ok) {
                                toast({
                                  title: "Não foi possível criar o local",
                                  description: res.err,
                                  variant: "destructive",
                                });
                                return;
                              }
                              toast({ title: "Local criado!" });
                              setOpenAddLocal(false);
                              setNovoLocal("");
                              await fetchAgenda();
                              if (res.id) setCreateForm((p) => ({ ...p, idlocal: res.id! }));
                            }}
                            disabled={adding}
                          >
                            {adding ? "Salvando..." : "Adicionar"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <Popover open={openLocalBox} onOpenChange={setOpenLocalBox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openLocalBox}
                        className="w-full justify-between"
                      >
                        <span className="truncate max-w-[85%]">
                          {createForm.idlocal
                            ? locais.find((o) => o.id === createForm.idlocal)?.label
                            : "Selecione o local"}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                      <Command>
                        <CommandInput placeholder="Buscar local..." />
                        <CommandList>
                          <CommandEmpty>Nenhum local encontrado.</CommandEmpty>
                          <CommandGroup>
                            {locais.map((o) => (
                              <CommandItem
                                key={o.id}
                                value={o.label}
                                onSelect={() => {
                                  setCreateForm((p) => ({ ...p, idlocal: o.id }));
                                  setOpenLocalBox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    createForm.idlocal === o.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <span className="truncate">{o.label}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Departamento & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Departamento</Label>
                  <Popover open={openDeptoBox} onOpenChange={setOpenDeptoBox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openDeptoBox}
                        className="w-full justify-between"
                      >
                        <span className="truncate max-w-[85%]">
                          {createForm.iddepto
                            ? departamentos.find((d) => d.id === createForm.iddepto)?.label
                            : "Selecione o departamento"}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                      <Command>
                        <CommandInput placeholder="Buscar departamento..." />
                        <CommandList>
                          <CommandEmpty>Nenhum departamento encontrado.</CommandEmpty>
                          <CommandGroup>
                            {departamentos.map((d) => (
                              <CommandItem
                                key={d.id}
                                value={d.label}
                                onSelect={() => {
                                  setCreateForm((p) => ({ ...p, iddepto: d.id }));
                                  setOpenDeptoBox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    createForm.iddepto === d.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <span className="truncate">{d.label}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-1">
                  <Label>Status</Label>
                  <Popover open={openStatusBox} onOpenChange={setOpenStatusBox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openStatusBox}
                        className="w-full justify-between"
                      >
                        <span className="flex items-center gap-2 truncate max-w-[85%]">
                          {createForm.idstatus ? (
                            <>
                              <span
                                className="inline-block w-2.5 h-2.5 rounded-full"
                                style={{
                                  backgroundColor:
                                    statusAgenda.find((s) => s.id === createForm.idstatus)?.extra?.cor ||
                                    "#6b7280",
                                }}
                              />
                              <span className="truncate">
                                {statusAgenda.find((s) => s.id === createForm.idstatus)?.label}
                              </span>
                            </>
                          ) : (
                            "Selecione o status"
                          )}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                      <Command>
                        <CommandInput placeholder="Buscar status..." />
                        <CommandList>
                          <CommandEmpty>Nenhum status encontrado.</CommandEmpty>
                          <CommandGroup>
                            {statusAgenda.map((s) => (
                              <CommandItem
                                key={s.id}
                                value={s.label}
                                onSelect={() => {
                                  setCreateForm((p) => ({ ...p, idstatus: s.id }));
                                  setOpenStatusBox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    createForm.idstatus === s.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <Circle
                                  className="mr-2 h-3 w-3"
                                  style={{ color: s.extra?.cor || "#6b7280" }}
                                  fill={s.extra?.cor || "#6b7280"}
                                />
                                <span className="truncate">{s.label}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              {/* Líder + Observação */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Nome do líder</Label>
                  <Popover open={openLeaderBox} onOpenChange={setOpenLeaderBox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openLeaderBox}
                        className="w-full justify-between"
                      >
                        <span className="truncate max-w-[85%]">
                          {createForm.idlider
                            ? lideres.find((l) => l.id === createForm.idlider)?.label
                            : "Selecione o líder"}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                      <Command>
                        <CommandInput placeholder="Digite para filtrar..." />
                        <CommandList>
                          <CommandEmpty>Nenhum líder encontrado.</CommandEmpty>
                          <CommandGroup>
                            {lideres.map((l) => (
                              <CommandItem
                                key={l.id}
                                value={l.label}
                                onSelect={() => {
                                  setCreateForm((p) => ({ ...p, idlider: l.id }));
                                  setOpenLeaderBox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    createForm.idlider === l.id ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                <span className="truncate">{l.label}</span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <Label>Observação</Label>
                  <Input
                    value={createForm.observacao}
                    onChange={(e) => setCreateForm((p) => ({ ...p, observacao: e.target.value }))}
                    placeholder="Informação rápida"
                  />
                </div>
              </div>

              <div>
                <Label>Descrição</Label>
                <Textarea
                  value={createForm.descricao}
                  onChange={(e) => setCreateForm((p) => ({ ...p, descricao: e.target.value }))}
                  rows={3}
                  placeholder="Detalhes do evento..."
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setOpenCreate(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleCreateEvent} disabled={saving}>
                  {saving ? "Salvando..." : "Criar Evento"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Cabeçalho semana */}
      <div className="grid grid-cols-7 text-xs font-medium text-muted-foreground mb-2">
        {WEEK_DAYS.map((w) => (
          <div key={w} className="text-center py-1">
            {w}
          </div>
        ))}
      </div>

      {/* Grade calendário */}
      <div className="grid grid-cols-7 gap-2 relative">
        {calendarMatrix.map((week, wi) =>
          week.map((cell: any, ci: number) => {
            if (cell.blank) {
              return (
                <div key={`${wi}-${ci}`} className="min-h-[110px] rounded-lg border border-border/40 bg-muted/20" />
              );
            }
            const dayNumber = cell.day as number;
            const dayDate = cell.date as Date;
            const dayEvents = eventsByDay[dayNumber] || [];
            const selected = !!selectedDay && selectedDay.getTime() === dayDate.getTime();

            return (
              <button
                key={`${wi}-${ci}-${dayNumber}`}
                type="button"
                onClick={() => setSelectedDay(dayDate)}
                className={[
                  "min-h-[110px] rounded-lg border p-2 flex flex-col gap-1 text-left focus:outline-none focus:ring-2 focus:ring-primary/60",
                  selected ? "border-primary shadow-sm" : "border-border/60",
                  "bg-background hover:bg-muted/30 transition-colors",
                ].join(" ")}
                aria-pressed={selected}
                aria-label={`Dia ${dayNumber} com ${dayEvents.length} eventos`}
              >
                <div className="text-xs font-semibold text-muted-foreground flex items-center justify-between">
                  <span>{dayNumber}</span>
                  {dayEvents.length > 0 && (
                    <Badge variant="outline" className="h-4 px-1 text-[10px]">
                      {dayEvents.length}
                    </Badge>
                  )}
                </div>

                <div className="flex-1 space-y-1 overflow-y-auto">
                  {loading && <div className="text-[11px] text-muted-foreground">Carregando...</div>}
                  {!loading && dayEvents.length === 0 && (
                    <div className="text-[11px] text-muted-foreground/70">— sem eventos —</div>
                  )}

                  {dayEvents.map((ev) => {
                    const { border, bg } = eventColors(ev);
                    return (
                      <div
                        key={ev.idagenda}
                        className="rounded-md p-2 text-[11px] leading-snug border relative"
                        style={{ borderColor: border, backgroundColor: bg }}
                        onMouseEnter={(e) => onEventMouseEnter(ev, e)}
                        onMouseLeave={() => onEventMouseLeave(ev)}
                      >
                        <div className="font-medium truncate flex items-center gap-2">
                          <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: border }} />
                          <span className="truncate">{ev.nome_evento || "Evento"}</span>
                          <Images className="w-3.5 h-3.5 opacity-70" />
                        </div>
                        {(ev.horario_inicial || ev.horario_final) && (
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            <span>
                              {formatTime(ev.horario_inicial)}
                              {ev.horario_final && ` - ${formatTime(ev.horario_final)}`}
                            </span>
                          </div>
                        )}
                        {ev.nome_local && (
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            <span className="truncate">{ev.nome_local}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </button>
            );
          })
        )}

        {/* Preview de fotos flutuante */}
        {hoverPreview?.id && (
          <div
            className="fixed z-50 bg-background border rounded-md shadow-xl p-2 w-[220px]"
            style={{ left: Math.max(8, hoverPreview.x), top: Math.max(8, hoverPreview.y) }}
            onMouseLeave={() => setHoverPreview(null)}
          >
            <div className="flex items-center gap-2 mb-2">
              <Camera className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium">Fotos do evento</span>
            </div>
            {photoLoading[hoverPreview.id] && (
              <div className="text-xs text-muted-foreground">Carregando fotos...</div>
            )}
            {!photoLoading[hoverPreview.id] && (photoCache[hoverPreview.id]?.length || 0) === 0 && (
              <div className="text-xs text-muted-foreground/70">Sem fotos neste evento.</div>
            )}
            <div className="grid grid-cols-3 gap-1">
              {(photoCache[hoverPreview.id] || []).map((url) => (
                <img key={url} src={url} alt="foto do evento" className="w-full h-16 object-cover rounded-sm" />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Painel de detalhes do dia selecionado */}
      {selectedDay && (
        <Card className="mt-4 border border-border/60">
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Eventos de {formatDateBR(selectedDay)}</h3>
              </div>
              <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setSelectedDay(null)} title="Fechar detalhes">
                <X className="w-4 h-4" />
              </Button>
            </div>

            {selectedDayEvents.length === 0 ? (
              <p className="text-sm text-muted-foreground">Não há eventos nesta data.</p>
            ) : (
              <div className="space-y-3">
                {selectedDayEvents.map((ev) => {
                  const { border, bg } = eventColors(ev);
                  return (
                    <div key={ev.idagenda} className="rounded-lg p-3" style={{ border: `1px solid ${border}`, backgroundColor: bg }}>
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0 flex items-center gap-2">
                          <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: border }} />
                          <span className="font-semibold text-sm truncate">{ev.nome_evento || "Evento"}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8"
                            title="Ver fotos"
                            onClick={() => {
                              ensurePhotos(ev.idagenda);
                              setHoverPreview({ id: ev.idagenda, x: 16, y: 16 });
                            }}
                          >
                            <Camera className="w-4 h-4" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8" title="Editar" onClick={() => openEditDialog(ev)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-red-600"
                            title="Excluir"
                            onClick={() => handleDeleteEvent(ev.idagenda)}
                            disabled={deletingId === ev.idagenda}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground mt-2">
                        <div className="flex gap-1 items-center">
                          <span className="font-medium text-foreground">Horário:</span>
                          <span>
                            {formatTime(ev.horario_inicial)}
                            {ev.horario_final && ` - ${formatTime(ev.horario_final)}`}
                          </span>
                        </div>
                        {ev.nome_local && (
                          <div className="flex gap-1 items-center">
                            <span className="font-medium text-foreground">Local:</span>
                            <span>{ev.nome_local}</span>
                          </div>
                        )}
                        {ev.nome_lider && (
                          <div className="flex gap-1 items-center">
                            <span className="font-medium text-foreground">Líder:</span>
                            <span>{ev.nome_lider}</span>
                          </div>
                        )}
                        {ev.departamento && (
                          <div className="flex gap-1 items-center">
                            <span className="font-medium text-foreground">Departamento:</span>
                            <span>{ev.departamento}</span>
                          </div>
                        )}
                        {ev.status_evento && (
                          <div className="flex gap-1 items-center">
                            <span className="font-medium text-foreground">Status:</span>
                            <Badge className="h-4 px-1 text-[10px]" style={{ backgroundColor: border, color: "white" }}>
                              {ev.status_evento}
                            </Badge>
                          </div>
                        )}
                      </div>

                      {(ev.descricao || ev.observacao) && (
                        <div className="mt-2 text-xs text-muted-foreground space-y-1">
                          {ev.descricao && (
                            <p>
                              <span className="font-medium text-foreground">Descrição: </span>
                              {ev.descricao}
                            </p>
                          )}
                          {ev.observacao && (
                            <p>
                              <span className="font-medium text-foreground">Observação: </span>
                              {ev.observacao}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Diálogo de Edição */}
      <Dialog open={openEdit} onOpenChange={setOpenEdit}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Evento</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Data/Horas */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <Label>Data *</Label>
                <Input type="date" value={editForm.data} onChange={(e) => setEditForm((p) => ({ ...p, data: e.target.value }))} required />
              </div>
              <div>
                <Label>Hora início</Label>
                <Input type="time" value={editForm.horario_inicial} onChange={(e) => setEditForm((p) => ({ ...p, horario_inicial: e.target.value }))} />
              </div>
              <div>
                <Label>Hora fim</Label>
                <Input type="time" value={editForm.horario_final} onChange={(e) => setEditForm((p) => ({ ...p, horario_final: e.target.value }))} />
              </div>
            </div>

            {/* Evento/Local/Departamento/Status/Líder */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Nome do evento *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <span className="truncate max-w-[85%]">
                        {editForm.ideventoig
                          ? eventosIgreja.find((o) => o.id === editForm.ideventoig)?.label
                          : "Selecione o evento"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Buscar evento..." />
                      <CommandList>
                        <CommandEmpty>Nenhum evento encontrado.</CommandEmpty>
                        <CommandGroup>
                          {eventosIgreja.map((o) => (
                            <CommandItem key={o.id} value={o.label} onSelect={() => setEditForm((p) => ({ ...p, ideventoig: o.id }))}>
                              <Check className={cn("mr-2 h-4 w-4", editForm.ideventoig === o.id ? "opacity-100" : "opacity-0")} />
                              <span className="truncate">{o.label}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-1">
                <Label>Local</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <span className="truncate max-w-[85%]">
                        {editForm.idlocal ? locais.find((o) => o.id === editForm.idlocal)?.label : "Selecione o local"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Buscar local..." />
                      <CommandList>
                        <CommandEmpty>Nenhum local encontrado.</CommandEmpty>
                        <CommandGroup>
                          {locais.map((o) => (
                            <CommandItem key={o.id} value={o.label} onSelect={() => setEditForm((p) => ({ ...p, idlocal: o.id }))}>
                              <Check className={cn("mr-2 h-4 w-4", editForm.idlocal === o.id ? "opacity-100" : "opacity-0")} />
                              <span className="truncate">{o.label}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-1">
                <Label>Departamento</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <span className="truncate max-w-[85%]">
                        {editForm.iddepto ? departamentos.find((d) => d.id === editForm.iddepto)?.label : "Selecione o departamento"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Buscar departamento..." />
                      <CommandList>
                        <CommandEmpty>Nenhum departamento encontrado.</CommandEmpty>
                        <CommandGroup>
                          {departamentos.map((d) => (
                            <CommandItem key={d.id} value={d.label} onSelect={() => setEditForm((p) => ({ ...p, iddepto: d.id }))}>
                              <Check className={cn("mr-2 h-4 w-4", editForm.iddepto === d.id ? "opacity-100" : "opacity-0")} />
                              <span className="truncate">{d.label}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-1">
                <Label>Status</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <span className="flex items-center gap-2 truncate max-w-[85%]">
                        {editForm.idstatus ? (
                          <>
                            <span
                              className="inline-block w-2.5 h-2.5 rounded-full"
                              style={{
                                backgroundColor:
                                  statusAgenda.find((s) => s.id === editForm.idstatus)?.extra?.cor || "#6b7280",
                              }}
                            />
                            <span className="truncate">{statusAgenda.find((s) => s.id === editForm.idstatus)?.label}</span>
                          </>
                        ) : (
                          "Selecione o status"
                        )}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Buscar status..." />
                      <CommandList>
                        <CommandEmpty>Nenhum status encontrado.</CommandEmpty>
                        <CommandGroup>
                          {statusAgenda.map((s) => (
                            <CommandItem key={s.id} value={s.label} onSelect={() => setEditForm((p) => ({ ...p, idstatus: s.id }))}>
                              <Check className={cn("mr-2 h-4 w-4", editForm.idstatus === s.id ? "opacity-100" : "opacity-0")} />
                              <Circle className="mr-2 h-3 w-3" style={{ color: s.extra?.cor || "#6b7280" }} fill={s.extra?.cor || "#6b7280"} />
                              <span className="truncate">{s.label}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-1">
                <Label>Nome do líder</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      <span className="truncate max-w-[85%]">
                        {editForm.idlider ? lideres.find((l) => l.id === editForm.idlider)?.label : "Selecione o líder"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
                    <Command>
                      <CommandInput placeholder="Digite para filtrar..." />
                      <CommandList>
                        <CommandEmpty>Nenhum líder encontrado.</CommandEmpty>
                        <CommandGroup>
                          {lideres.map((l) => (
                            <CommandItem key={l.id} value={l.label} onSelect={() => setEditForm((p) => ({ ...p, idlider: l.id }))}>
                              <Check className={cn("mr-2 h-4 w-4", editForm.idlider === l.id ? "opacity-100" : "opacity-0")} />
                              <span className="truncate">{l.label}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div>
              <Label>Observação</Label>
              <Input value={editForm.observacao} onChange={(e) => setEditForm((p) => ({ ...p, observacao: e.target.value }))} placeholder="Informação rápida" />
            </div>

            <div>
              <Label>Descrição</Label>
              <Textarea value={editForm.descricao} onChange={(e) => setEditForm((p) => ({ ...p, descricao: e.target.value }))} rows={3} placeholder="Detalhes do evento..." />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpenEdit(false)}>
                Cancelar
              </Button>
              <Button onClick={handleUpdateEvent} disabled={updating}>
                {updating ? "Salvando..." : "Atualizar Evento"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
