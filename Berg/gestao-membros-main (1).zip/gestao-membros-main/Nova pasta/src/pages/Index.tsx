import { useState } from "react";
import Login from "./Login";
import MainLayout from "@/components/MainLayout";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";

/** Mini ErrorBoundary só pra esta página */
function ErrorBox({ error }: { error: unknown }) {
  const msg =
    error instanceof Error ? `${error.name}: ${error.message}` : String(error);
  return (
    <div className="min-h-screen grid place-items-center p-6">
      <div className="max-w-xl w-full space-y-3 border rounded-lg p-4 bg-red-50 text-red-700">
        <h2 className="text-lg font-semibold">Erro ao renderizar layout</h2>
        <pre className="text-sm whitespace-pre-wrap">{msg}</pre>
        <button
          onClick={() => window.location.reload()}
          className="px-3 py-2 rounded bg-red-600 text-white"
        >
          Recarregar
        </button>
      </div>
    </div>
  );
}

export default function Index() {
  const { user, userProfile, loading, signOut } = useAuth();
  const [layoutError, setLayoutError] = useState<unknown>(null);

  // Debug logs
  console.log('Index render - user:', !!user, 'userProfile:', !!userProfile, 'loading:', loading);

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <div className="space-y-4 w-full max-w-md">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-8 w-1/2" />
        </div>
      </div>
    );
  }

  // Not logged in - show login
  if (!user) {
    return <Login />;
  }

  // Logged in but no profile - show waiting
  if (!userProfile) {
    return (
      <div className="min-h-screen grid place-items-center p-6">
        <div className="max-w-md w-full text-center space-y-3">
          <Skeleton className="h-10 w-full" />
          <p className="text-muted-foreground">
            Carregando perfil do usuário…
          </p>
          <button
            className="mt-2 px-3 py-2 rounded bg-gray-800 text-white"
            onClick={() => window.location.reload()}
          >
            Recarregar
          </button>
          <button
            className="mt-2 ml-2 px-3 py-2 rounded border"
            onClick={signOut}
          >
            Sair
          </button>
        </div>
      </div>
    );
  }

  // Logged in + profile loaded - render layout
  try {
    return <MainLayout user={userProfile} onLogout={signOut} />;
  } catch (err) {
    console.error('Index: Error rendering MainLayout:', err);
    setLayoutError(err);
    return <ErrorBox error={err} />;
  }
}