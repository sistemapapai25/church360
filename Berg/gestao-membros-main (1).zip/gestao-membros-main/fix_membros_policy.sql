-- Script para corrigir a política RLS do membros que está causando erro 409
-- Este script corrige o problema onde usuários ADM não conseguem atualizar registros

-- 1. Primeiro, vamos remover a política problemática
DROP POLICY IF EXISTS "membros_admin_write" ON public.membros;

-- 2. Criar uma nova política mais robusta que verifica diretamente na tabela usuarios
CREATE POLICY "membros_admin_write" 
ON public.membros FOR ALL 
USING (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.permissao IN ('ADM', 'OPE')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.permissao IN ('ADM', 'OPE')
  )
);

-- 3. Verificar se a política foi criada corretamente
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'membros' AND policyname = 'membros_admin_write';

-- 4. Testar a política com uma consulta de verificação
SELECT 
  'Policy test' as test_type,
  CASE 
    WHEN EXISTS (
      SELECT 1 
      FROM public.usuarios u 
      WHERE u.auth_uid = auth.uid() 
      AND u.permissao IN ('ADM', 'OPE')
    ) THEN 'PASS - User has ADM/OPE permission'
    ELSE 'FAIL - User does not have ADM/OPE permission'
  END as result;