-- Script para verificar TODOS os relacionamentos de cônjuges
-- Execute no Supabase SQL Editor

-- 1. Mostrar todos os membros com cônjuge definido
SELECT 'Todos os membros com cônjuge definido:' as info;
SELECT 
  m.nome as membro,
  conjuge.nome as conjuge_nome,
  CASE 
    WHEN conjuge.conjuge_id = m.idmembro THEN '✅ RECÍPROCO'
    WHEN conjuge.conjuge_id IS NULL THEN '❌ SEM RECÍPROCO'
    WHEN conjuge.conjuge_id != m.idmembro THEN '⚠️ RECÍPROCO INCORRETO'
    ELSE '❓ SITUAÇÃO DESCONHECIDA'
  END as status
FROM membros m
LEFT JOIN membros conjuge ON m.conjuge_id = conjuge.idmembro
WHERE m.conjuge_id IS NOT NULL
ORDER BY m.nome;

-- 2. Mostrar apenas os que PRECISAM de correção
SELECT 'Relacionamentos que PRECISAM de correção:' as info;
SELECT 
  m.nome as membro,
  m.idmembro,
  conjuge.nome as conjuge_nome,
  conjuge.idmembro as conjuge_id,
  conjuge.conjuge_id as conjuge_tem_como_conjuge,
  CASE 
    WHEN conjuge.conjuge_id IS NULL THEN 'Cônjuge não tem recíproco'
    WHEN conjuge.conjuge_id != m.idmembro THEN 'Cônjuge tem outro como cônjuge'
    ELSE 'Situação desconhecida'
  END as problema
FROM membros m
LEFT JOIN membros conjuge ON m.conjuge_id = conjuge.idmembro
WHERE m.conjuge_id IS NOT NULL
  AND (conjuge.conjuge_id != m.idmembro OR conjuge.conjuge_id IS NULL);

-- 3. Estatísticas gerais
SELECT 'Estatísticas de relacionamentos:' as info;
SELECT 
  COUNT(*) as total_com_conjuge,
  SUM(CASE WHEN conjuge.conjuge_id = m.idmembro THEN 1 ELSE 0 END) as reciprocos_corretos,
  SUM(CASE WHEN conjuge.conjuge_id IS NULL THEN 1 ELSE 0 END) as sem_reciproco,
  SUM(CASE WHEN conjuge.conjuge_id IS NOT NULL AND conjuge.conjuge_id != m.idmembro THEN 1 ELSE 0 END) as reciproco_incorreto
FROM membros m
LEFT JOIN membros conjuge ON m.conjuge_id = conjuge.idmembro
WHERE m.conjuge_id IS NOT NULL;