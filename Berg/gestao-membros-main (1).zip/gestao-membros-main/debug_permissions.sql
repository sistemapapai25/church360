-- Script de diagnóstico para problemas de permissão
-- Execute no Supabase SQL Editor

-- 1. Verificar se a view 'me' está funcionando corretamente
SELECT 'Dados da view me:' as info;
SELECT * FROM me;

-- 2. Verificar seu usuário na tabela usuarios
SELECT 'Dados do usuário na tabela usuarios:' as info;
SELECT idusuario, email, permissao, auth_uid, idmembro 
FROM usuarios 
WHERE email = 'prbergnterra@gmail.com';

-- 3. Verificar se auth.uid() está correto
SELECT 'auth.uid() atual:' as info, auth.uid() as current_auth_uid;

-- 4. Verificar políticas ativas na tabela membros
SELECT 'Políticas ativas na tabela membros:' as info;
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies 
WHERE tablename = 'membros' 
ORDER BY policyname;

-- 5. Testar se a política está funcionando
SELECT 'Teste da política membros_admin_write:' as info;
SELECT EXISTS (SELECT 1 FROM me WHERE permissao IN ('ADM', 'OPE')) as policy_check;

-- 6. Verificar se há conflitos de políticas
SELECT 'Verificando conflitos de políticas:' as info;
SELECT COUNT(*) as total_policies_membros
FROM pg_policies 
WHERE tablename = 'membros' AND cmd = 'UPDATE';

-- 7. Verificar RLS está habilitado
SELECT 'Status RLS da tabela membros:' as info;
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE tablename = 'membros';

-- 8. Teste direto de UPDATE (para diagnóstico)
-- ATENÇÃO: Este comando pode falhar, é esperado para diagnóstico
SELECT 'Tentando UPDATE direto (pode falhar):' as info;
-- UPDATE membros SET nome = nome WHERE idmembro = '1' LIMIT 1;