-- Script para corrigir permissões do usuário ref4e
-- Execute estes comandos no Supabase SQL Editor

-- 1. Primeiro, vamos verificar o usuário atual
SELECT idusuario, email, permissao, nome 
FROM usuarios 
WHERE email = 'prbergnterra@gmail.com' OR idusuario = 'ref4e';

-- 2. Atualizar permissão para ADM (Administrador)
UPDATE usuarios 
SET permissao = 'ADM' 
WHERE email = 'prbergnterra@gmail.com';

-- 3. Verificar se a atualização funcionou
SELECT idusuario, email, permissao, nome 
FROM usuarios 
WHERE email = 'prbergnterra@gmail.com';

-- 4. (Opcional) Ver todos os usuários e suas permissões
SELECT idusuario, email, permissao, nome 
FROM usuarios 
ORDER BY permissao, email;