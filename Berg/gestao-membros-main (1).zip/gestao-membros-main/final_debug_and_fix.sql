-- Script final de debug e correção para resolver o problema de autenticação
-- Este script investiga todas as possibilidades e aplica múltiplas correções

-- 1. Debug completo do estado atual
SELECT 
  'Debug: Current Auth State' as debug_step,
  auth.uid() as current_auth_uid,
  (SELECT email FROM auth.users WHERE id = auth.uid()) as current_auth_email,
  (SELECT role FROM auth.users WHERE id = auth.uid()) as current_auth_role;

-- 2. Verificar TODOS os usuários na tabela usuarios
SELECT 
  'Debug: All Users in usuarios table' as debug_step,
  u.idusuario,
  u.email,
  u.permissao,
  u.auth_uid,
  u.created_at,
  CASE 
    WHEN u.auth_uid = auth.uid() THEN 'CURRENT USER'
    ELSE 'OTHER USER'
  END as is_current_user
FROM public.usuarios u 
ORDER BY u.created_at;

-- 3. Verificar se o problema é com a view 'me'
SELECT 
  'Debug: ME View Direct Test' as debug_step,
  CASE 
    WHEN EXISTS (SELECT 1 FROM me) THEN 'ME view returns data'
    ELSE 'ME view returns NO data'
  END as me_view_status;

-- 4. Tentar SELECT direto na view me
SELECT 
  'Debug: ME View Content' as debug_step,
  me.email,
  me.permissao,
  me.idmembro
FROM me
LIMIT 1;

-- 5. CORREÇÃO ALTERNATIVA 1: Recriar a política com uma abordagem diferente
DROP POLICY IF EXISTS "membros_admin_write" ON public.membros;

-- Criar política mais permissiva temporariamente para teste
CREATE POLICY "membros_admin_write_temp" 
ON public.membros FOR ALL 
TO authenticated
USING (true)
WITH CHECK (true);

-- 6. Testar se a política permissiva funciona
SELECT 
  'Test: Permissive Policy' as test_step,
  'Should always PASS with permissive policy' as expected_result;

-- 7. CORREÇÃO ALTERNATIVA 2: Política baseada em email direto
DROP POLICY IF EXISTS "membros_admin_write_temp" ON public.membros;

CREATE POLICY "membros_admin_write_email_based" 
ON public.membros FOR ALL 
TO authenticated
USING (
  (SELECT email FROM auth.users WHERE id = auth.uid()) IN (
    SELECT email FROM public.usuarios WHERE permissao IN ('ADM', 'OPE')
  )
)
WITH CHECK (
  (SELECT email FROM auth.users WHERE id = auth.uid()) IN (
    SELECT email FROM public.usuarios WHERE permissao IN ('ADM', 'OPE')
  )
);

-- 8. Testar a política baseada em email
SELECT 
  'Test: Email-based Policy' as test_step,
  CASE 
    WHEN (SELECT email FROM auth.users WHERE id = auth.uid()) IN (
      SELECT email FROM public.usuarios WHERE permissao IN ('ADM', 'OPE')
    ) THEN 'PASS - Email-based policy should work'
    ELSE 'FAIL - Email not found in ADM/OPE users'
  END as result;

-- 9. CORREÇÃO ALTERNATIVA 3: Forçar atualização do auth_uid para TODOS os usuários ADM
UPDATE public.usuarios 
SET auth_uid = (
  SELECT id FROM auth.users au 
  WHERE au.email = usuarios.email 
  LIMIT 1
)
WHERE permissao = 'ADM' 
  AND email IN (SELECT email FROM auth.users);

-- 10. Verificar se algum usuário ADM foi atualizado
SELECT 
  'Post-Update: ADM Users Status' as update_step,
  u.email,
  u.permissao,
  u.auth_uid,
  CASE 
    WHEN u.auth_uid = auth.uid() THEN 'CURRENT USER - FIXED'
    WHEN u.auth_uid IS NOT NULL THEN 'HAS AUTH_UID'
    ELSE 'NO AUTH_UID'
  END as status
FROM public.usuarios u 
WHERE u.permissao = 'ADM';

-- 11. Teste final com a política original
DROP POLICY IF EXISTS "membros_admin_write_email_based" ON public.membros;

CREATE POLICY "membros_admin_write" 
ON public.membros FOR ALL 
TO authenticated
USING (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.permissao IN ('ADM', 'OPE')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM public.usuarios u 
    WHERE u.auth_uid = auth.uid() 
    AND u.permissao IN ('ADM', 'OPE')
  )
);

-- 12. Teste final da política
SELECT 
  'Final Test: Original Policy' as final_step,
  CASE 
    WHEN EXISTS (
      SELECT 1 
      FROM public.usuarios u 
      WHERE u.auth_uid = auth.uid() 
      AND u.permissao IN ('ADM', 'OPE')
    ) THEN 'SUCCESS - Policy now works!'
    ELSE 'STILL FAILING - Need manual intervention'
  END as final_result;

-- 13. Informações para debug manual se ainda falhar
SELECT 
  'Manual Debug Info' as info_type,
  'Current auth.uid(): ' || COALESCE(auth.uid()::text, 'NULL') as auth_uid_info,
  'Auth email: ' || COALESCE((SELECT email FROM auth.users WHERE id = auth.uid()), 'NULL') as auth_email_info,
  'Matching usuarios: ' || (SELECT COUNT(*)::text FROM public.usuarios WHERE auth_uid = auth.uid()) as matching_count;