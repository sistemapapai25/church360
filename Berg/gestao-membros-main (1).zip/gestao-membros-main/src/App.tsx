import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom";
import ErrorBoundary from "@/components/ui/error-boundary";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";

import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import ResetPasswordPage from "./pages/reset-password";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
    },
    mutations: {
      retry: 1,
    },
  },
});

// Componente de proteção de rota
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Verificando autenticação...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const App = () => {
  const [supabaseReady, setSupabaseReady] = useState(false);

  useEffect(() => {
    // Test Supabase connectivity
    try {
      import('@/integrations/supabase/client').then((module) => {
        console.log('Supabase client loaded successfully:', !!module.supabase);
        setSupabaseReady(true);
      }).catch(err => {
        console.error('Failed to load Supabase client:', err);
        setSupabaseReady(true); // Still proceed to avoid blocking
      });
    } catch (err) {
      console.error('Error importing Supabase:', err);
      setSupabaseReady(true); // Still proceed to avoid blocking
    }
  }, []);

  if (!supabaseReady) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Carregando aplicação...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            {/** Redirect to reset-password when arriving with Supabase recovery hash */}
            {/** This ensures email links open the correct page even if the route is different */}
            {(() => {
              const RecoveryRedirector = () => {
                const location = useLocation();
                const navigate = useNavigate();
                
                useEffect(() => {
                  const hash = window.location.hash || '';
                  if (hash.includes('type=recovery') && location.pathname !== '/reset-password') {
                    navigate('/reset-password', { replace: true });
                  }
                }, [location, navigate]);
                return null;
              };
              return <RecoveryRedirector />;
            })()}
            {/* Removido o redirecionamento automático do /login para permitir abrir a tela de login mesmo autenticado */}
            {/* (antes havia um AuthRedirector aqui) */}
            {(() => {
              const GlobalGuard = () => {
                const { user, loading } = useAuth();
                const location = useLocation();
                const navigate = useNavigate();
                useEffect(() => {
                  const isPublic = location.pathname === '/login' || location.pathname === '/reset-password';
                  if (!loading && !user && !isPublic) {
                    navigate('/login', { replace: true });
                    return;
                  }
                  const t = setTimeout(() => {
                    if (loading && !user && !isPublic) {
                      navigate('/login', { replace: true });
                    }
                  }, 2500);
                  return () => clearTimeout(t);
                }, [loading, user, location.pathname, navigate]);
                return null;
              };
              return <GlobalGuard />;
            })()}
            <Routes>
              <Route path="/" element={<Navigate to="/login" replace />} />
              <Route path="/login" element={<Login />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />
              
              {/* Rotas protegidas */}
              <Route path="/dashboard" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/membros" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/agenda" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/lideres" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/departamentos" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/areas" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/perfil-membro" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/tipos-eventos" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/locais-eventos" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/usuarios" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/relatorios-dons" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/relatorio-casais" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              <Route path="/correcao-conjuges" element={<ProtectedRoute><Index /></ProtectedRoute>} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

export default App;