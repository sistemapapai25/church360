/**
 * Formata número de telefone removendo zero extra se houver
 * e aplicando máscara (XX) XXXXX-XXXX
 */
export function formatPhone(phone: string | null | undefined): string {
  if (!phone) return '';
  
  // Remove tudo que não é número
  let cleaned = phone.replace(/\D/g, '');
  
  // Se termina com 0 e tem 12 dígitos, remove o último zero
  if (cleaned.length === 12 && cleaned.endsWith('0')) {
    cleaned = cleaned.slice(0, -1);
  }
  
  // Se tem 11 dígitos (DDD + 9 + 8 dígitos)
  if (cleaned.length === 11) {
    return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
  }
  
  // Se tem 10 dígitos (DDD + 8 dígitos - telefone fixo)
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 6)}-${cleaned.slice(6)}`;
  }
  
  // Se não corresponder ao padrão esperado, retorna como está
  return phone;
}
