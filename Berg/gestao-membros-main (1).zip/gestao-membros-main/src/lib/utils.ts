import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { supabase } from "@/integrations/supabase/client"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function getImageUrl(fileName: string | null | undefined): string | null {
  if (!fileName) return null;
  
  // Se já for uma URL completa, retorna ela mesma
  if (fileName.startsWith('http://') || fileName.startsWith('https://')) {
    return fileName;
  }
  
  // Caso contrário, gera a URL do Supabase Storage
  const { data } = supabase.storage
    .from('member-photos')
    .getPublicUrl(fileName);
  
  return data.publicUrl;
}

export function calculateAge(birthDate: string | null | undefined): string {
  if (!birthDate) return "";
  
  const birth = new Date(birthDate);
  const today = new Date();
  
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return `${age} anos`;
}

export function formatDate(date: string | null | undefined): string {
  if (!date) return "";
  
  // Usar split para evitar problemas de timezone
  const [ano, mes, dia] = date.split('-');
  return `${dia}/${mes}/${ano}`;
}
