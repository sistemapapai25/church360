export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      agenda: {
        Row: {
          created_at: string | null
          created_by: string | null
          data: string
          descricao: string | null
          horario_final: string | null
          horario_inicial: string | null
          idagenda: string
          iddepto: string | null
          ideventoig: string | null
          idlider: string | null
          idlocal: string | null
          idstatus: string | null
          observacao: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          data: string
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda?: string
          iddepto?: string | null
          ideventoig?: string | null
          idlider?: string | null
          idlocal?: string | null
          idstatus?: string | null
          observacao?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          data?: string
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda?: string
          iddepto?: string | null
          ideventoig?: string | null
          idlider?: string | null
          idlocal?: string | null
          idstatus?: string | null
          observacao?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "agenda_ideventoig_fkey"
            columns: ["ideventoig"]
            isOneToOne: false
            referencedRelation: "eventos_igreja"
            referencedColumns: ["ideventoig"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlocal_fkey"
            columns: ["idlocal"]
            isOneToOne: false
            referencedRelation: "locais"
            referencedColumns: ["idlocal"]
          },
          {
            foreignKeyName: "agenda_idstatus_fkey"
            columns: ["idstatus"]
            isOneToOne: false
            referencedRelation: "status_agenda"
            referencedColumns: ["idstatus"]
          },
        ]
      }
      app_user_status: {
        Row: {
          app_id: string
          created_at: string | null
          id: string
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          app_id: string
          created_at?: string | null
          id?: string
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          app_id?: string
          created_at?: string | null
          id?: string
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_user_status_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "me"
            referencedColumns: ["idusuario"]
          },
          {
            foreignKeyName: "app_user_status_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "usuarios"
            referencedColumns: ["idusuario"]
          },
        ]
      }
      areas: {
        Row: {
          created_at: string | null
          descricao: string | null
          idarea: string
          iddepto: string
          lider1: string | null
          lider2: string | null
          nome: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          descricao?: string | null
          idarea?: string
          iddepto: string
          lider1?: string | null
          lider2?: string | null
          nome: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          descricao?: string | null
          idarea?: string
          iddepto?: string
          lider1?: string | null
          lider2?: string | null
          nome?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_areas_lider1"
            columns: ["lider1"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "fk_areas_lider2"
            columns: ["lider2"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      aulas: {
        Row: {
          atividade_planejada: string | null
          created_at: string | null
          data_aula: string
          faixa_etaria: string
          idaula: string
          idlider: string
          materiais_necessarios: string | null
          material_arquivo: string[] | null
          objetivo: string | null
          observacoes_pos_aula: string | null
          resumo: string | null
          status: string | null
          tema_biblico: string
          titulo: string
          updated_at: string | null
          versiculo_chave: string | null
        }
        Insert: {
          atividade_planejada?: string | null
          created_at?: string | null
          data_aula: string
          faixa_etaria: string
          idaula?: string
          idlider: string
          materiais_necessarios?: string | null
          material_arquivo?: string[] | null
          objetivo?: string | null
          observacoes_pos_aula?: string | null
          resumo?: string | null
          status?: string | null
          tema_biblico: string
          titulo: string
          updated_at?: string | null
          versiculo_chave?: string | null
        }
        Update: {
          atividade_planejada?: string | null
          created_at?: string | null
          data_aula?: string
          faixa_etaria?: string
          idaula?: string
          idlider?: string
          materiais_necessarios?: string | null
          material_arquivo?: string[] | null
          objetivo?: string | null
          observacoes_pos_aula?: string | null
          resumo?: string | null
          status?: string | null
          tema_biblico?: string
          titulo?: string
          updated_at?: string | null
          versiculo_chave?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_aulas_lideres"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "fk_aulas_lideres"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
        ]
      }
      cidade: {
        Row: {
          cidade: string
          id: string
          uf: string
        }
        Insert: {
          cidade: string
          id: string
          uf: string
        }
        Update: {
          cidade?: string
          id?: string
          uf?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_cidade_uf"
            columns: ["uf"]
            isOneToOne: false
            referencedRelation: "uf"
            referencedColumns: ["uf"]
          },
        ]
      }
      departamentos: {
        Row: {
          iddepto: string
          liderdepto1: string | null
          liderdepto2: string | null
          nome: string
          observacao: string | null
          pertence_capelania: boolean
        }
        Insert: {
          iddepto: string
          liderdepto1?: string | null
          liderdepto2?: string | null
          nome: string
          observacao?: string | null
          pertence_capelania?: boolean
        }
        Update: {
          iddepto?: string
          liderdepto1?: string | null
          liderdepto2?: string | null
          nome?: string
          observacao?: string | null
          pertence_capelania?: boolean
        }
        Relationships: []
      }
      depto_funcoes: {
        Row: {
          created_at: string | null
          id: string
          iddepto: string
          idfuncao: string
          obrigatoria: boolean | null
          vagas_padrao: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          iddepto: string
          idfuncao: string
          obrigatoria?: boolean | null
          vagas_padrao?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          iddepto?: string
          idfuncao?: string
          obrigatoria?: boolean | null
          vagas_padrao?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "depto_funcoes_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "depto_funcoes_idfuncao_fkey"
            columns: ["idfuncao"]
            isOneToOne: false
            referencedRelation: "funcao"
            referencedColumns: ["idfuncao"]
          },
        ]
      }
      dons: {
        Row: {
          codigo: string
          iddom: string
          nome: string
        }
        Insert: {
          codigo: string
          iddom: string
          nome: string
        }
        Update: {
          codigo?: string
          iddom?: string
          nome?: string
        }
        Relationships: []
      }
      dons_avaliacoes: {
        Row: {
          atualizado_em: string
          criado_em: string
          idavaliacao: string
          idmembro: string
          status: string
        }
        Insert: {
          atualizado_em?: string
          criado_em?: string
          idavaliacao?: string
          idmembro: string
          status?: string
        }
        Update: {
          atualizado_em?: string
          criado_em?: string
          idavaliacao?: string
          idmembro?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "dons_avaliacoes_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      dons_frases: {
        Row: {
          idfrase: string
          ordem: number
          texto: string
        }
        Insert: {
          idfrase?: string
          ordem: number
          texto: string
        }
        Update: {
          idfrase?: string
          ordem?: number
          texto?: string
        }
        Relationships: []
      }
      dons_mapeamento: {
        Row: {
          iddom: string
          idfrase: string
        }
        Insert: {
          iddom: string
          idfrase: string
        }
        Update: {
          iddom?: string
          idfrase?: string
        }
        Relationships: [
          {
            foreignKeyName: "dons_mapeamento_iddom_fkey"
            columns: ["iddom"]
            isOneToOne: false
            referencedRelation: "dons"
            referencedColumns: ["iddom"]
          },
          {
            foreignKeyName: "dons_mapeamento_idfrase_fkey"
            columns: ["idfrase"]
            isOneToOne: true
            referencedRelation: "dons_frases"
            referencedColumns: ["idfrase"]
          },
        ]
      }
      dons_respostas: {
        Row: {
          idavaliacao: string
          idfrase: string
          valor: number
        }
        Insert: {
          idavaliacao: string
          idfrase: string
          valor: number
        }
        Update: {
          idavaliacao?: string
          idfrase?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "dons_respostas_idavaliacao_fkey"
            columns: ["idavaliacao"]
            isOneToOne: false
            referencedRelation: "dons_avaliacoes"
            referencedColumns: ["idavaliacao"]
          },
          {
            foreignKeyName: "dons_respostas_idfrase_fkey"
            columns: ["idfrase"]
            isOneToOne: false
            referencedRelation: "dons_frases"
            referencedColumns: ["idfrase"]
          },
        ]
      }
      dons_resultados: {
        Row: {
          idavaliacao: string
          iddom: string
          pontuacao: number
        }
        Insert: {
          idavaliacao: string
          iddom: string
          pontuacao: number
        }
        Update: {
          idavaliacao?: string
          iddom?: string
          pontuacao?: number
        }
        Relationships: [
          {
            foreignKeyName: "dons_resultados_idavaliacao_fkey"
            columns: ["idavaliacao"]
            isOneToOne: false
            referencedRelation: "dons_avaliacoes"
            referencedColumns: ["idavaliacao"]
          },
          {
            foreignKeyName: "dons_resultados_iddom_fkey"
            columns: ["iddom"]
            isOneToOne: false
            referencedRelation: "dons"
            referencedColumns: ["iddom"]
          },
        ]
      }
      escala: {
        Row: {
          created_at: string | null
          created_by: string | null
          data: string | null
          descricao: string | null
          horario_final: string | null
          horario_inicial: string | null
          idagenda: string
          idaula: string | null
          iddepto: string
          idescala: string
          idsala: string | null
          idturma: string | null
          status: string | null
          titulo: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          data?: string | null
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda: string
          idaula?: string | null
          iddepto: string
          idescala?: string
          idsala?: string | null
          idturma?: string | null
          status?: string | null
          titulo?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          data?: string | null
          descricao?: string | null
          horario_final?: string | null
          horario_inicial?: string | null
          idagenda?: string
          idaula?: string | null
          iddepto?: string
          idescala?: string
          idsala?: string | null
          idturma?: string | null
          status?: string | null
          titulo?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_idagenda_fkey"
            columns: ["idagenda"]
            isOneToOne: false
            referencedRelation: "agenda"
            referencedColumns: ["idagenda"]
          },
          {
            foreignKeyName: "escala_idagenda_fkey"
            columns: ["idagenda"]
            isOneToOne: false
            referencedRelation: "agenda_full"
            referencedColumns: ["idagenda"]
          },
          {
            foreignKeyName: "escala_idaula_fkey"
            columns: ["idaula"]
            isOneToOne: false
            referencedRelation: "aulas"
            referencedColumns: ["idaula"]
          },
          {
            foreignKeyName: "escala_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "escala_idsala_fkey"
            columns: ["idsala"]
            isOneToOne: false
            referencedRelation: "salas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "escala_idturma_fkey"
            columns: ["idturma"]
            isOneToOne: false
            referencedRelation: "turmas"
            referencedColumns: ["idturma"]
          },
        ]
      }
      escala_alocacoes: {
        Row: {
          confirmado: boolean | null
          created_at: string | null
          created_by: string | null
          id: string
          idlider: string
          observacoes: string | null
          presente: boolean | null
          slot_id: string
          updated_at: string | null
        }
        Insert: {
          confirmado?: boolean | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          idlider: string
          observacoes?: string | null
          presente?: boolean | null
          slot_id: string
          updated_at?: string | null
        }
        Update: {
          confirmado?: boolean | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          idlider?: string
          observacoes?: string | null
          presente?: boolean | null
          slot_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_alocacoes_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "escala_alocacoes_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "escala_alocacoes_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: false
            referencedRelation: "escala_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      escala_diaconato: {
        Row: {
          checklist_itens: string[] | null
          configuracao_cadeiras: string | null
          created_at: string | null
          idescala: string
          observacoes_logisticas: string | null
          plano_limpeza: string | null
          responsavel_chaves: string | null
          updated_at: string | null
        }
        Insert: {
          checklist_itens?: string[] | null
          configuracao_cadeiras?: string | null
          created_at?: string | null
          idescala: string
          observacoes_logisticas?: string | null
          plano_limpeza?: string | null
          responsavel_chaves?: string | null
          updated_at?: string | null
        }
        Update: {
          checklist_itens?: string[] | null
          configuracao_cadeiras?: string | null
          created_at?: string | null
          idescala?: string
          observacoes_logisticas?: string | null
          plano_limpeza?: string | null
          responsavel_chaves?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_diaconato_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escala"
            referencedColumns: ["idescala"]
          },
          {
            foreignKeyName: "escala_diaconato_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escalas_completas"
            referencedColumns: ["idescala"]
          },
        ]
      }
      escala_infantil: {
        Row: {
          atividades: string[] | null
          created_at: string | null
          faixa_etaria: string | null
          idescala: string
          material_didatico: string[] | null
          observacoes_pedagogicas: string | null
          tema_aula: string | null
          updated_at: string | null
        }
        Insert: {
          atividades?: string[] | null
          created_at?: string | null
          faixa_etaria?: string | null
          idescala: string
          material_didatico?: string[] | null
          observacoes_pedagogicas?: string | null
          tema_aula?: string | null
          updated_at?: string | null
        }
        Update: {
          atividades?: string[] | null
          created_at?: string | null
          faixa_etaria?: string | null
          idescala?: string
          material_didatico?: string[] | null
          observacoes_pedagogicas?: string | null
          tema_aula?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_infantil_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escala"
            referencedColumns: ["idescala"]
          },
          {
            foreignKeyName: "escala_infantil_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escalas_completas"
            referencedColumns: ["idescala"]
          },
        ]
      }
      escala_louvor: {
        Row: {
          created_at: string | null
          horario_ensaio: string | null
          idescala: string
          local_ensaio: string | null
          observacoes_tecnicas: string | null
          repertorio: string[] | null
          tom_principal: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          horario_ensaio?: string | null
          idescala: string
          local_ensaio?: string | null
          observacoes_tecnicas?: string | null
          repertorio?: string[] | null
          tom_principal?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          horario_ensaio?: string | null
          idescala?: string
          local_ensaio?: string | null
          observacoes_tecnicas?: string | null
          repertorio?: string[] | null
          tom_principal?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_louvor_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escala"
            referencedColumns: ["idescala"]
          },
          {
            foreignKeyName: "escala_louvor_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: true
            referencedRelation: "escalas_completas"
            referencedColumns: ["idescala"]
          },
        ]
      }
      escala_slots: {
        Row: {
          created_at: string | null
          id: string
          idescala: string
          idfuncao: string
          observacoes: string | null
          quantidade: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          idescala: string
          idfuncao: string
          observacoes?: string | null
          quantidade?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          idescala?: string
          idfuncao?: string
          observacoes?: string | null
          quantidade?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_slots_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: false
            referencedRelation: "escala"
            referencedColumns: ["idescala"]
          },
          {
            foreignKeyName: "escala_slots_idescala_fkey"
            columns: ["idescala"]
            isOneToOne: false
            referencedRelation: "escalas_completas"
            referencedColumns: ["idescala"]
          },
          {
            foreignKeyName: "escala_slots_idfuncao_fkey"
            columns: ["idfuncao"]
            isOneToOne: false
            referencedRelation: "funcao"
            referencedColumns: ["idfuncao"]
          },
        ]
      }
      eventos_igreja: {
        Row: {
          evento: string
          ideventoig: string
        }
        Insert: {
          evento: string
          ideventoig: string
        }
        Update: {
          evento?: string
          ideventoig?: string
        }
        Relationships: []
      }
      funcao: {
        Row: {
          created_at: string | null
          descricao: string | null
          idfuncao: string
          nome: string
          requer_habilidade: boolean | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          descricao?: string | null
          idfuncao?: string
          nome: string
          requer_habilidade?: boolean | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          descricao?: string | null
          idfuncao?: string
          nome?: string
          requer_habilidade?: boolean | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      lideres: {
        Row: {
          idarea: string | null
          iddepto: string | null
          idlider: string
          idmembro: string
          idposicao: string | null
          status: string | null
        }
        Insert: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string
          idmembro: string
          idposicao?: string | null
          status?: string | null
        }
        Update: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string
          idmembro?: string
          idposicao?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lideres_idarea_fkey"
            columns: ["idarea"]
            isOneToOne: false
            referencedRelation: "areas"
            referencedColumns: ["idarea"]
          },
          {
            foreignKeyName: "lideres_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "lideres_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      lideres_backup: {
        Row: {
          idarea: string | null
          iddepto: string | null
          idlider: string | null
          idmembro: string | null
          idposicao: string | null
          status: string | null
        }
        Insert: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string | null
          idmembro?: string | null
          idposicao?: string | null
          status?: string | null
        }
        Update: {
          idarea?: string | null
          iddepto?: string | null
          idlider?: string | null
          idmembro?: string | null
          idposicao?: string | null
          status?: string | null
        }
        Relationships: []
      }
      locais: {
        Row: {
          contato: string | null
          fone: string | null
          idlocal: string
          local: string
        }
        Insert: {
          contato?: string | null
          fone?: string | null
          idlocal: string
          local: string
        }
        Update: {
          contato?: string | null
          fone?: string | null
          idlocal?: string
          local?: string
        }
        Relationships: []
      }
      membros: {
        Row: {
          apelido: string | null
          bairro: string | null
          cep: string | null
          cidade: string | null
          complemento: string | null
          conjuge_id: string | null
          cpf: string | null
          created_at: string | null
          credencial: string | null
          data_casamento: string | null
          email: string | null
          endereco: string | null
          entrevista: string | null
          entrevistador: string | null
          estado_civil: string | null
          ficha_pdf: string | null
          foto: string | null
          iddepto: string | null
          idmembro: string
          nascimento: string | null
          nome: string
          profissao: string | null
          sexo: string | null
          status: string | null
          telefone: string | null
          tipo_membro: string | null
          uf: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          apelido?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          conjuge_id?: string | null
          cpf?: string | null
          created_at?: string | null
          credencial?: string | null
          data_casamento?: string | null
          email?: string | null
          endereco?: string | null
          entrevista?: string | null
          entrevistador?: string | null
          estado_civil?: string | null
          ficha_pdf?: string | null
          foto?: string | null
          iddepto?: string | null
          idmembro: string
          nascimento?: string | null
          nome: string
          profissao?: string | null
          sexo?: string | null
          status?: string | null
          telefone?: string | null
          tipo_membro?: string | null
          uf?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          apelido?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          complemento?: string | null
          conjuge_id?: string | null
          cpf?: string | null
          created_at?: string | null
          credencial?: string | null
          data_casamento?: string | null
          email?: string | null
          endereco?: string | null
          entrevista?: string | null
          entrevistador?: string | null
          estado_civil?: string | null
          ficha_pdf?: string | null
          foto?: string | null
          iddepto?: string | null
          idmembro?: string
          nascimento?: string | null
          nome?: string
          profissao?: string | null
          sexo?: string | null
          status?: string | null
          telefone?: string | null
          tipo_membro?: string | null
          uf?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_membros_conjuge"
            columns: ["conjuge_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "membros_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "membros_tipo_membro_fkey"
            columns: ["tipo_membro"]
            isOneToOne: false
            referencedRelation: "tipos_membro"
            referencedColumns: ["tipo"]
          },
        ]
      }
      membros_codigo_legacy: {
        Row: {
          codigo_legacy: string
          idmembro: string
        }
        Insert: {
          codigo_legacy: string
          idmembro: string
        }
        Update: {
          codigo_legacy?: string
          idmembro?: string
        }
        Relationships: [
          {
            foreignKeyName: "membros_codigo_legacy_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      permissoes: {
        Row: {
          permissao: string
        }
        Insert: {
          permissao: string
        }
        Update: {
          permissao?: string
        }
        Relationships: []
      }
      posicao: {
        Row: {
          created_at: string | null
          descricao: string | null
          hierarquia: number | null
          idposicao: string
          nome: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          descricao?: string | null
          hierarquia?: number | null
          idposicao?: string
          nome: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          descricao?: string | null
          hierarquia?: number | null
          idposicao?: string
          nome?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      profissao: {
        Row: {
          idprofissao: string
          profissao: string
        }
        Insert: {
          idprofissao: string
          profissao: string
        }
        Update: {
          idprofissao?: string
          profissao?: string
        }
        Relationships: []
      }
      raizes_interacoes: {
        Row: {
          created_at: string
          created_by: string | null
          data_limite: string | null
          id: string
          observacoes: string | null
          proximo_passo: string | null
          responsavel_id: string | null
          resultado: string | null
          tipo: string
          visitante_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          data_limite?: string | null
          id?: string
          observacoes?: string | null
          proximo_passo?: string | null
          responsavel_id?: string | null
          resultado?: string | null
          tipo: string
          visitante_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          data_limite?: string | null
          id?: string
          observacoes?: string | null
          proximo_passo?: string | null
          responsavel_id?: string | null
          resultado?: string | null
          tipo?: string
          visitante_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "raizes_interacoes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "raizes_interacoes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "raizes_interacoes_visitante_id_fkey"
            columns: ["visitante_id"]
            isOneToOne: false
            referencedRelation: "visitantes"
            referencedColumns: ["id"]
          },
        ]
      }
      relacionamentos_familiares: {
        Row: {
          created_at: string
          id: string
          membro_id: string
          parente_id: string
          tipo_relacionamento: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          membro_id: string
          parente_id: string
          tipo_relacionamento: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          membro_id?: string
          parente_id?: string
          tipo_relacionamento?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "relacionamentos_familiares_membro_id_fkey"
            columns: ["membro_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "relacionamentos_familiares_parente_id_fkey"
            columns: ["parente_id"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      restricaokids: {
        Row: {
          alergias: string | null
          autorizacao_imagem: boolean | null
          created_at: string | null
          id: string
          id_membro: string
          lgpd_aceito_em: string | null
          lgpd_aceito_por: string | null
          necessidades_especiais: string | null
          observacoes: string | null
          restricoes_alimentares: string | null
          updated_at: string | null
        }
        Insert: {
          alergias?: string | null
          autorizacao_imagem?: boolean | null
          created_at?: string | null
          id?: string
          id_membro: string
          lgpd_aceito_em?: string | null
          lgpd_aceito_por?: string | null
          necessidades_especiais?: string | null
          observacoes?: string | null
          restricoes_alimentares?: string | null
          updated_at?: string | null
        }
        Update: {
          alergias?: string | null
          autorizacao_imagem?: boolean | null
          created_at?: string | null
          id?: string
          id_membro?: string
          lgpd_aceito_em?: string | null
          lgpd_aceito_por?: string | null
          necessidades_especiais?: string | null
          observacoes?: string | null
          restricoes_alimentares?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "restricaokids_id_membro_fkey"
            columns: ["id_membro"]
            isOneToOne: true
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
        ]
      }
      salas: {
        Row: {
          capacidade: number
          created_at: string
          created_by: string | null
          descricao: string | null
          equipamentos: string[] | null
          id: string
          idturma: string | null
          nome: string
          observacoes: string | null
          status: string
          updated_at: string
        }
        Insert: {
          capacidade?: number
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          equipamentos?: string[] | null
          id?: string
          idturma?: string | null
          nome: string
          observacoes?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          capacidade?: number
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          equipamentos?: string[] | null
          id?: string
          idturma?: string | null
          nome?: string
          observacoes?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "salas_idturma_fkey"
            columns: ["idturma"]
            isOneToOne: false
            referencedRelation: "turmas"
            referencedColumns: ["idturma"]
          },
        ]
      }
      status_agenda: {
        Row: {
          cor: string | null
          idstatus: string
          status: string
        }
        Insert: {
          cor?: string | null
          idstatus: string
          status: string
        }
        Update: {
          cor?: string | null
          idstatus?: string
          status?: string
        }
        Relationships: []
      }
      tipos_membro: {
        Row: {
          tipo: string
        }
        Insert: {
          tipo: string
        }
        Update: {
          tipo?: string
        }
        Relationships: []
      }
      turmas: {
        Row: {
          capacidade_maxima: number
          created_at: string | null
          created_by: string | null
          descricao: string | null
          dia_semana: string | null
          idade_maxima: number | null
          idade_minima: number | null
          iddepto: string
          idturma: string
          nome: string
          observacoes: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          capacidade_maxima?: number
          created_at?: string | null
          created_by?: string | null
          descricao?: string | null
          dia_semana?: string | null
          idade_maxima?: number | null
          idade_minima?: number | null
          iddepto?: string
          idturma?: string
          nome: string
          observacoes?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          capacidade_maxima?: number
          created_at?: string | null
          created_by?: string | null
          descricao?: string | null
          dia_semana?: string | null
          idade_maxima?: number | null
          idade_minima?: number | null
          iddepto?: string
          idturma?: string
          nome?: string
          observacoes?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      uf: {
        Row: {
          iduf: string
          uf: string
        }
        Insert: {
          iduf: string
          uf: string
        }
        Update: {
          iduf?: string
          uf?: string
        }
        Relationships: []
      }
      usuarios: {
        Row: {
          auth_uid: string | null
          created_at: string | null
          email: string
          idmembro: string | null
          idusuario: string
          permissao: string | null
        }
        Insert: {
          auth_uid?: string | null
          created_at?: string | null
          email: string
          idmembro?: string | null
          idusuario: string
          permissao?: string | null
        }
        Update: {
          auth_uid?: string | null
          created_at?: string | null
          email?: string
          idmembro?: string | null
          idusuario?: string
          permissao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "usuarios_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "usuarios_permissao_fkey"
            columns: ["permissao"]
            isOneToOne: false
            referencedRelation: "permissoes"
            referencedColumns: ["permissao"]
          },
        ]
      }
      visitantes: {
        Row: {
          contato: string | null
          created_at: string
          direcionado: string
          direcionado_flag: boolean | null
          email: string | null
          id: string
          id_short: string | null
          nascimento: string | null
          nome: string
          raizes_data_limite: string | null
          raizes_proximo_passo: string | null
          raizes_status: string | null
          responsavel_id: string | null
          telefone: string | null
        }
        Insert: {
          contato?: string | null
          created_at?: string
          direcionado?: string
          direcionado_flag?: boolean | null
          email?: string | null
          id?: string
          id_short?: string | null
          nascimento?: string | null
          nome: string
          raizes_data_limite?: string | null
          raizes_proximo_passo?: string | null
          raizes_status?: string | null
          responsavel_id?: string | null
          telefone?: string | null
        }
        Update: {
          contato?: string | null
          created_at?: string
          direcionado?: string
          direcionado_flag?: boolean | null
          email?: string | null
          id?: string
          id_short?: string | null
          nascimento?: string | null
          nome?: string
          raizes_data_limite?: string | null
          raizes_proximo_passo?: string | null
          raizes_status?: string | null
          responsavel_id?: string | null
          telefone?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "visitantes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "visitantes_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
        ]
      }
    }
    Views: {
      agenda_full: {
        Row: {
          cor_evento: string | null
          created_at: string | null
          created_by: string | null
          data: string | null
          departamento: string | null
          descricao: string | null
          fim_ts: string | null
          horario_final: string | null
          horario_inicial: string | null
          idagenda: string | null
          iddepto: string | null
          ideventoig: string | null
          idlider: string | null
          idlocal: string | null
          idstatus: string | null
          inicio_ts: string | null
          nome_evento: string | null
          nome_lider: string | null
          nome_local: string | null
          observacao: string | null
          status_evento: string | null
          updated_at: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "agenda_ideventoig_fkey"
            columns: ["ideventoig"]
            isOneToOne: false
            referencedRelation: "eventos_igreja"
            referencedColumns: ["ideventoig"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "lideres"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlider_fkey"
            columns: ["idlider"]
            isOneToOne: false
            referencedRelation: "raizes_lideres_resolvidos"
            referencedColumns: ["idlider"]
          },
          {
            foreignKeyName: "agenda_idlocal_fkey"
            columns: ["idlocal"]
            isOneToOne: false
            referencedRelation: "locais"
            referencedColumns: ["idlocal"]
          },
          {
            foreignKeyName: "agenda_idstatus_fkey"
            columns: ["idstatus"]
            isOneToOne: false
            referencedRelation: "status_agenda"
            referencedColumns: ["idstatus"]
          },
        ]
      }
      escalas_completas: {
        Row: {
          aula_objetivo: string | null
          aula_tema: string | null
          aula_titulo: string | null
          capacidade_maxima: number | null
          created_at: string | null
          departamento_nome: string | null
          descricao: string | null
          escala_data: string | null
          escala_horario_final: string | null
          escala_horario_inicial: string | null
          evento_data: string | null
          evento_descricao: string | null
          evento_fim: string | null
          evento_inicio: string | null
          idagenda: string | null
          idaula: string | null
          iddepto: string | null
          idescala: string | null
          idsala: string | null
          idturma: string | null
          sala_nome: string | null
          status: string | null
          titulo: string | null
          total_alocacoes: number | null
          total_slots: number | null
          turma_nome: string | null
          updated_at: string | null
        }
        Relationships: [
          {
            foreignKeyName: "escala_idagenda_fkey"
            columns: ["idagenda"]
            isOneToOne: false
            referencedRelation: "agenda"
            referencedColumns: ["idagenda"]
          },
          {
            foreignKeyName: "escala_idagenda_fkey"
            columns: ["idagenda"]
            isOneToOne: false
            referencedRelation: "agenda_full"
            referencedColumns: ["idagenda"]
          },
          {
            foreignKeyName: "escala_idaula_fkey"
            columns: ["idaula"]
            isOneToOne: false
            referencedRelation: "aulas"
            referencedColumns: ["idaula"]
          },
          {
            foreignKeyName: "escala_iddepto_fkey"
            columns: ["iddepto"]
            isOneToOne: false
            referencedRelation: "departamentos"
            referencedColumns: ["iddepto"]
          },
          {
            foreignKeyName: "escala_idsala_fkey"
            columns: ["idsala"]
            isOneToOne: false
            referencedRelation: "salas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "escala_idturma_fkey"
            columns: ["idturma"]
            isOneToOne: false
            referencedRelation: "turmas"
            referencedColumns: ["idturma"]
          },
        ]
      }
      me: {
        Row: {
          auth_uid: string | null
          email: string | null
          idmembro: string | null
          idusuario: string | null
          permissao: string | null
        }
        Insert: {
          auth_uid?: string | null
          email?: string | null
          idmembro?: string | null
          idusuario?: string | null
          permissao?: string | null
        }
        Update: {
          auth_uid?: string | null
          email?: string | null
          idmembro?: string | null
          idusuario?: string | null
          permissao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "usuarios_idmembro_fkey"
            columns: ["idmembro"]
            isOneToOne: false
            referencedRelation: "membros"
            referencedColumns: ["idmembro"]
          },
          {
            foreignKeyName: "usuarios_permissao_fkey"
            columns: ["permissao"]
            isOneToOne: false
            referencedRelation: "permissoes"
            referencedColumns: ["permissao"]
          },
        ]
      }
      raizes_lideres_resolvidos: {
        Row: {
          idlider: string | null
          nome: string | null
          nome_ord: string | null
        }
        Relationships: []
      }
      vw_dons_soma: {
        Row: {
          idavaliacao: string | null
          iddom: string | null
          pontuacao: number | null
        }
        Relationships: [
          {
            foreignKeyName: "dons_mapeamento_iddom_fkey"
            columns: ["iddom"]
            isOneToOne: false
            referencedRelation: "dons"
            referencedColumns: ["iddom"]
          },
          {
            foreignKeyName: "dons_respostas_idavaliacao_fkey"
            columns: ["idavaliacao"]
            isOneToOne: false
            referencedRelation: "dons_avaliacoes"
            referencedColumns: ["idavaliacao"]
          },
        ]
      }
    }
    Functions: {
      create_user_with_profile: {
        Args: {
          p_email: string
          p_idmembro: string
          p_password: string
          p_permissao?: string
        }
        Returns: Json
      }
      fn_dons_finalizar: {
        Args: { _id: string }
        Returns: undefined
      }
      get_user_app_status: {
        Args: { p_app_id: string; p_user_id: string }
        Returns: string
      }
      is_current_user_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_current_user_lider_do_depto: {
        Args: { depto: string }
        Returns: boolean
      }
      list_users: {
        Args: Record<PropertyKey, never>
        Returns: {
          auth_uid: string
          created_at: string
          email: string
          idmembro: string
          idusuario: string
          nome_membro: string
          permissao: string
        }[]
      }
      reset_user_password: {
        Args: { p_new_password?: string; p_user_id: string }
        Returns: Json
      }
      toggle_user_app_status: {
        Args: { p_app_id: string; p_status: string; p_user_id: string }
        Returns: Json
      }
      unaccent: {
        Args: { "": string }
        Returns: string
      }
      unaccent_init: {
        Args: { "": unknown }
        Returns: unknown
      }
      update_user_info: {
        Args: { p_email?: string; p_idusuario: string; p_permissao?: string }
        Returns: Json
      }
    }
    Enums: {
      raizes_interacao_tipo:
        | "WhatsApp"
        | "Ligacao"
        | "Visita"
        | "Convite"
        | "Culto"
        | "Encaminhamento"
      raizes_status_type:
        | "Novo"
        | "Aguardando Contato"
        | "Em Contato"
        | "Visita Agendada"
        | "Convidado p/ Culto"
        | "Compareceu ao Culto"
        | "Não Compareceu"
        | "Integrado"
        | "Encerrado"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      raizes_interacao_tipo: [
        "WhatsApp",
        "Ligacao",
        "Visita",
        "Convite",
        "Culto",
        "Encaminhamento",
      ],
      raizes_status_type: [
        "Novo",
        "Aguardando Contato",
        "Em Contato",
        "Visita Agendada",
        "Convidado p/ Culto",
        "Compareceu ao Culto",
        "Não Compareceu",
        "Integrado",
        "Encerrado",
      ],
    },
  },
} as const
