import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

export default function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [autoDone, setAutoDone] = useState(false);

  // Quando a página é aberta via link de recuperação do Supabase,
  // há uma sessão temporária que permite atualizar a senha.
  // Detecta isso pelo hash "type=recovery" e altera automaticamente para 123456.
  useEffect(() => {
    const hash = window.location.hash || "";
    const isRecovery = hash.includes("type=recovery");
    if (!isRecovery || autoDone) return;

    const autoReset = async () => {
      setLoading(true);
      try {
        const { error } = await supabase.auth.updateUser({ password: "123456" });
        if (error) throw error;
        setAutoDone(true);
        toast({
          title: "Senha redefinida",
          description: "Sua senha foi alterada para 123456.",
        });
        // Redireciona para login após sucesso
        navigate("/login", { replace: true });
      } catch (err) {
        toast({
          title: "Erro",
          description: err instanceof Error ? err.message : "Erro ao redefinir senha",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    autoReset();
  }, [navigate, autoDone]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password.length < 6) {
      return toast({
        title: "Erro",
        description: "A senha deve ter pelo menos 6 caracteres",
        variant: "destructive",
      });
    }

    if (password !== confirm) {
      return toast({
        title: "Erro",
        description: "As senhas não conferem",
        variant: "destructive",
      });
    }

    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Senha redefinida com sucesso!",
      });

      // Redireciona para login após sucesso
      navigate("/login");
    } catch (err) {
      toast({
        title: "Erro",
        description: err instanceof Error ? err.message : "Erro ao redefinir senha",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader>
          <CardTitle>Definir Nova Senha</CardTitle>
        </CardHeader>
        <CardContent>
          {autoDone && (
            <div className="mb-4 text-sm text-green-700">
              A senha foi automaticamente definida para <code>123456</code>. Você será redirecionado.
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="password">Nova senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="Digite sua nova senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
              />
            </div>
            <div>
              <Label htmlFor="confirm">Confirmar senha</Label>
              <Input
                id="confirm"
                type="password"
                placeholder="Confirme sua nova senha"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                autoComplete="new-password"
              />
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-primary"
            >
              {loading ? "Salvando..." : "Salvar nova senha"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
