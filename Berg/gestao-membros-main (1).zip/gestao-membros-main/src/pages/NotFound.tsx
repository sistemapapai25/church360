import { useMemo } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

const NotFound = () => {
  const location = useLocation();
  const { user, userProfile } = useAuth();

  const safeTarget = useMemo(() => {
    if (user && userProfile) {
      return userProfile.permission === 'MTR' ? '/perfil-membro' : '/dashboard';
    }
    return '/login';
  }, [user, userProfile]);

  // Redirecta imediatamente para uma rota segura
  return <Navigate to={safeTarget} replace state={{ from: location }} />;
};

export default NotFound;
