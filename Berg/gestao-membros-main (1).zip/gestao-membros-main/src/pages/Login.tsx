import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

// Botão de resetar senha
import ResetPasswordButton from "@/components/ResetPasswordButton";

// ✅ Importa a logo direto da pasta assets
import logoAguas from "@/assets/logo-aguas.png";

export default function Login() {
  const navigate = useNavigate();
  const { user, userProfile } = useAuth();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);

  // Removido: permitir abrir a tela de login mesmo autenticado para trocar de conta no mobile
  useEffect(() => {
    // Intencionalmente não redirecionar do /login quando já autenticado
  }, []);

  const entrar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !senha) {
      return toast({
        title: "Erro",
        description: "Preencha e-mail e senha",
        variant: "destructive",
      });
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password: senha,
      });
      
      if (error) throw error;

      console.log('Login successful:', data);
      
      toast({
        title: "Bem-vindo",
        description: "Login realizado com sucesso!",
        duration: 2000,
      });

      // Aguarda brevemente e decide destino pelo perfil (monitores -> perfil-membro)
      await new Promise((r) => setTimeout(r, 200));
      const { data: perfil } = await supabase
        .from('usuarios')
        .select('permissao')
        .eq('auth_uid', data.user.id)
        .maybeSingle();
      const target = perfil?.permissao === 'MTR' ? '/perfil-membro' : '/dashboard';

      // Tenta SPA navigate primeiro
      navigate(target, { replace: true });
      // Fallback robusto para mobile
      setTimeout(() => {
        if (window.location.pathname !== target) {
          window.location.replace(target);
        }
      }, 200);
    } catch (err) {
      console.error('Login error:', err);
      toast({
        title: "Falha no login",
        description:
          err instanceof Error ? err.message : "Verifique suas credenciais",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-subtle">
      <Card className="w-full max-w-md bg-gradient-card shadow-elegant border-0 backdrop-blur-sm">

        <CardHeader className="text-center pb-6">
          {/* ✅ Logo da igreja */}
          <div className="mx-auto mb-6">
            <img
              src={logoAguas}
              alt="Igreja Águas Purificadoras"
              className="w-20 h-20 mx-auto object-contain"
            />
          </div>

          {/* ✅ Nome completo da igreja */}
          <CardTitle className="text-xl font-bold leading-snug">
            Igreja Apostólica e Profética Águas Purificadoras
          </CardTitle>
          <p className="text-sm text-muted-foreground mt-1">Gestão de Membros</p>
          <p className="text-muted-foreground text-base mt-2">
            Faça login para acessar o sistema
          </p>
        </CardHeader>

        <CardContent>
          <form onSubmit={entrar} className="space-y-4">
            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                autoComplete="email"
                required
              />
            </div>
            <div>
              <Label htmlFor="senha">Senha</Label>
              <Input
                id="senha"
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-primary hover:shadow-primary transition-smooth"
            >
              {loading ? "Entrando..." : "Entrar"}
            </Button>

            <div className="mt-4 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                Esqueceu a senha?
              </span>
              <ResetPasswordButton />
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
