import { useAuth } from "@/hooks/useAuth";
import MainLayout from "@/components/MainLayout";
import Dashboard from "@/components/Dashboard";

export default function DashboardPage() {
  const { userProfile, signOut } = useAuth();

  if (!userProfile) {
    return null; // Será capturado pelo ProtectedRoute
  }

  return (
    <MainLayout user={userProfile} onLogout={signOut}>
      <Dashboard />
    </MainLayout>
  );
}
