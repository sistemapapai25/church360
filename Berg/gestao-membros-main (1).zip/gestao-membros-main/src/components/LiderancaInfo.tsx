import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Crown, Building } from 'lucide-react';

interface LiderancaData {
  idlider: string;
  iddepto: string;
  idarea?: string;
  nome_departamento: string;
  nome_area?: string;
  isLiderDepartamento?: boolean; // indica se é líder principal/secundário do departamento
  isMembroArea?: boolean; // indica se é apenas membro da área (não líder do depto)
  isAuxiliarLider?: boolean; // indica se é auxiliar do líder (liderdepto2)
}

interface LiderancaInfoProps {
  membroId: string;
}

export default function LiderancaInfo({ membroId }: LiderancaInfoProps) {
  const [lideranca, setLideranca] = useState<LiderancaData[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchLideranca();
  }, [membroId]);

  const fetchLideranca = async () => {
    if (!membroId) return;
    
    setLoading(true);
    try {
      // 1. Buscar departamentos onde é líder principal ou secundário
      const { data: deptosLider, error: deptosError } = await supabase
        .from('departamentos')
        .select('iddepto, nome, liderdepto1, liderdepto2')
        .or(`liderdepto1.eq.${membroId},liderdepto2.eq.${membroId}`);

      if (deptosError) throw deptosError;

      const CAPELANIA_DEPT_ID = 'c3245218';
      const deptosLiderIds = new Set((deptosLider || []).map(d => d.iddepto));

      // 2. Buscar liderança de áreas (tabela lideres)
      const { data: lideresData, error: lideresError } = await supabase
        .from('lideres')
        .select(`
          idlider,
          iddepto,
          idarea,
          departamentos:iddepto (nome)
        `)
        .eq('idmembro', membroId)
        .eq('status', 'Ativo');

      if (lideresError) throw lideresError;

      // 3. Buscar áreas ativas
      const { data: areasData, error: areasError } = await supabase
        .from('areas')
        .select('idarea, nome, iddepto')
        .eq('status', 'Ativo');

      if (areasError) throw areasError;

      const liderancaFormatada: LiderancaData[] = [];
      const deptosProcessados = new Set<string>();

      // Processar liderança de áreas
      if (lideresData && lideresData.length > 0) {
        lideresData.forEach(lider => {
          const nomeDept = (lider.departamentos as any)?.nome || 'Departamento não encontrado';
          const isLiderDepto = deptosLiderIds.has(lider.iddepto);
          
          // Se for líder principal/secundário de departamento que NÃO é Capelania
          if (isLiderDepto && lider.iddepto !== CAPELANIA_DEPT_ID) {
            // Adiciona apenas uma vez por departamento (sem área)
            if (!deptosProcessados.has(lider.iddepto)) {
              // Verificar se é auxiliar do líder (liderdepto2)
              const deptoInfo = deptosLider?.find(d => d.iddepto === lider.iddepto);
              const isAuxiliar = deptoInfo?.liderdepto2 === membroId;
              
              liderancaFormatada.push({
                idlider: `depto-${lider.iddepto}`,
                iddepto: lider.iddepto,
                nome_departamento: nomeDept,
                nome_area: undefined,
                isLiderDepartamento: true,
                isMembroArea: false,
                isAuxiliarLider: isAuxiliar
              });
              deptosProcessados.add(lider.iddepto);
            }
          } 
          // Se for Capelania E for líder principal/secundário
          else if (isLiderDepto && lider.iddepto === CAPELANIA_DEPT_ID) {
            // Verificar se é auxiliar do líder (liderdepto2)
            const deptoInfo = deptosLider?.find(d => d.iddepto === lider.iddepto);
            const isAuxiliar = deptoInfo?.liderdepto2 === membroId;
            
            liderancaFormatada.push({
              idlider: lider.idlider,
              iddepto: lider.iddepto,
              idarea: lider.idarea,
              nome_departamento: nomeDept,
              nome_area: lider.idarea ? areasData?.find(a => a.idarea === lider.idarea)?.nome : undefined,
              isLiderDepartamento: true,
              isMembroArea: false,
              isAuxiliarLider: isAuxiliar
            });
          }
          // Se NÃO for líder principal/secundário do departamento (apenas membro da área)
          else {
            liderancaFormatada.push({
              idlider: lider.idlider,
              iddepto: lider.iddepto,
              idarea: lider.idarea,
              nome_departamento: nomeDept,
              nome_area: lider.idarea ? areasData?.find(a => a.idarea === lider.idarea)?.nome : undefined,
              isLiderDepartamento: false,
              isMembroArea: true
            });
          }
        });
      }

      // Adicionar departamentos onde é líder mas não tem registro em lideres
      if (deptosLider && deptosLider.length > 0) {
        deptosLider.forEach(depto => {
          if (!deptosProcessados.has(depto.iddepto)) {
            // Verificar se é auxiliar do líder (liderdepto2)
            const isAuxiliar = depto.liderdepto2 === membroId;
            
            // Para Capelania, criar um registro por área
            if (depto.iddepto === CAPELANIA_DEPT_ID) {
              const areasCapelania = areasData?.filter(a => a.iddepto === CAPELANIA_DEPT_ID) || [];
              areasCapelania.forEach(area => {
                const jaExiste = liderancaFormatada.some(l => 
                  l.iddepto === depto.iddepto && l.idarea === area.idarea
                );
                if (!jaExiste) {
                  liderancaFormatada.push({
                    idlider: `depto-${depto.iddepto}-area-${area.idarea}`,
                    iddepto: depto.iddepto,
                    idarea: area.idarea,
                    nome_departamento: depto.nome,
                    nome_area: area.nome,
                    isLiderDepartamento: true,
                    isAuxiliarLider: isAuxiliar
                  });
                }
              });
            } else {
              // Para outros departamentos
              liderancaFormatada.push({
                idlider: `depto-${depto.iddepto}`,
                iddepto: depto.iddepto,
                nome_departamento: depto.nome,
                nome_area: undefined,
                isLiderDepartamento: true,
                isAuxiliarLider: isAuxiliar
              });
            }
          }
        });
      }

      setLideranca(liderancaFormatada);
    } catch (err) {
      console.error('Erro ao carregar informações de liderança:', err);
      setLideranca([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <h4 className="font-semibold text-lg border-b pb-2 flex items-center gap-2">
          <Crown className="w-5 h-5" />
          Liderança
        </h4>
        <p className="text-sm text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (lideranca.length === 0) {
    return null; // Não mostra a seção se não for líder
  }

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-lg border-b pb-2 flex items-center gap-2">
        <Crown className="w-5 h-5 text-amber-500" />
        Liderança
      </h4>
      
      <div className="space-y-3">
        {lideranca.map((lider) => (
          <div key={lider.idlider} className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
            <div className="flex items-center gap-3">
              <Building className="w-4 h-4 text-amber-600" />
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className="bg-amber-100 text-amber-800 border-amber-300">
                    {lider.nome_departamento}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {lider.iddepto === 'c3245218' // Capelania
                    ? lider.isMembroArea
                      ? `Pertence à área ${lider.nome_area}`
                      : `Líder da área ${lider.nome_area}`
                    : lider.isMembroArea
                      ? `Pertence ao departamento Líderes de Departamentos`
                      : lider.isLiderDepartamento && lider.nome_area
                        ? `Líder da área ${lider.nome_area}`
                        : lider.isAuxiliarLider
                          ? `Auxiliar do Líder do departamento ${lider.nome_departamento}`
                          : `Líder do departamento ${lider.nome_departamento}`}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}