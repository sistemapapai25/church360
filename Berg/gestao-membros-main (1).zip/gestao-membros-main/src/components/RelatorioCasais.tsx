import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Heart, Search, Calendar, Users, Download } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useAuth } from "@/hooks/useAuth";
import { formatPhone } from "@/lib/formatPhone";

// Função auxiliar para obter URL da foto do Supabase Storage
const getPhotoUrl = (fotoPath: string | null | undefined): string | undefined => {
  if (!fotoPath) return undefined;
  // Se já é uma URL completa, retorna como está
  if (fotoPath.startsWith('http')) return fotoPath;

  // Tenta no bucket principal usado pelo app
  const primary = supabase.storage
    .from('member-photos')
    .getPublicUrl(fotoPath).data.publicUrl;

  if (primary) return primary;

  // Fallback para bucket alternativo, se existir
  const fallback = supabase.storage
    .from('membros_fotos')
    .getPublicUrl(fotoPath).data.publicUrl;

  return fallback;
};

interface CasalInfo {
  id: string;
  membro1_id: string;
  membro1_nome: string;
  membro1_apelido?: string;
  membro1_foto?: string;
  membro1_telefone?: string;
  membro1_sexo?: string;
  membro2_id: string;
  membro2_nome: string;
  membro2_apelido?: string;
  membro2_foto?: string;
  membro2_telefone?: string;
  membro2_sexo?: string;
  data_casamento?: string;
  tempo_casado?: string;
}

export default function RelatorioCasais() {
  const { userProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [casais, setCasais] = useState<CasalInfo[]>([]);
  const [totalCasais, setTotalCasais] = useState(0);

  const calcularTempoCasado = (dataCasamento: string): string => {
    const hoje = new Date();
    const casamento = new Date(dataCasamento);
    const diffTime = Math.abs(hoje.getTime() - casamento.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const anos = Math.floor(diffDays / 365);
    const meses = Math.floor((diffDays % 365) / 30);
    
    if (anos > 0) {
      return meses > 0 ? `${anos} anos e ${meses} meses` : `${anos} anos`;
    } else if (meses > 0) {
      return `${meses} meses`;
    } else {
      return `${diffDays} dias`;
    }
  };

  const fetchCasais = async () => {
    setLoading(true);
    try {
      // Buscar relacionamentos de cônjuge na tabela relacionamentos_familiares
      const { data: relacionamentos, error: relError } = await supabase
        .from("relacionamentos_familiares")
        .select(`
          id,
          membro_id,
          parente_id,
          tipo_relacionamento,
          membro:membro_id (
            idmembro,
            nome,
            apelido,
            foto,
            telefone,
            sexo,
            data_casamento
          ),
          parente:parente_id (
            idmembro,
            nome,
            apelido,
            foto,
            telefone,
            sexo,
            data_casamento
          )
        `)
        .eq("tipo_relacionamento", "conjuge");

      if (relError) throw relError;

      // Processar os dados para evitar duplicatas (A->B e B->A)
      const casaisMap = new Map<string, CasalInfo>();
      
      console.log("Dados dos relacionamentos:", relacionamentos);
      
      relacionamentos?.forEach((rel: any) => {
        const membro1 = rel.membro;
        const membro2 = rel.parente;
        
        console.log("Membro 1:", membro1);
        console.log("Membro 2:", membro2);
        
        if (!membro1 || !membro2) return;

        // Criar uma chave única ordenada para evitar duplicatas
        const ids = [membro1.idmembro, membro2.idmembro].sort();
        const chaveUnica = `${ids[0]}_${ids[1]}`;

        if (!casaisMap.has(chaveUnica)) {
          // Determinar qual data de casamento usar (priorizar a mais recente se houver diferença)
          let dataCasamento = membro1.data_casamento || membro2.data_casamento;
          if (membro1.data_casamento && membro2.data_casamento) {
            dataCasamento = new Date(membro1.data_casamento) > new Date(membro2.data_casamento) 
              ? membro1.data_casamento 
              : membro2.data_casamento;
          }

          casaisMap.set(chaveUnica, {
            id: rel.id,
            membro1_id: membro1.idmembro,
            membro1_nome: membro1.nome,
            membro1_apelido: membro1.apelido,
            membro1_foto: membro1.foto,
            membro1_telefone: membro1.telefone,
            membro1_sexo: membro1.sexo,
            membro2_id: membro2.idmembro,
            membro2_nome: membro2.nome,
            membro2_apelido: membro2.apelido,
            membro2_foto: membro2.foto,
            membro2_telefone: membro2.telefone,
            membro2_sexo: membro2.sexo,
            data_casamento: dataCasamento,
            tempo_casado: dataCasamento ? calcularTempoCasado(dataCasamento) : undefined,
          });
        }
      });

      const casaisArray = Array.from(casaisMap.values());
      
      // Filtrar por busca se houver
      const casaisFiltrados = query 
        ? casaisArray.filter(casal => 
            casal.membro1_nome.toLowerCase().includes(query.toLowerCase()) ||
            casal.membro2_nome.toLowerCase().includes(query.toLowerCase())
          )
        : casaisArray;

      // Ordenar por nome do primeiro membro
      casaisFiltrados.sort((a, b) => a.membro1_nome.localeCompare(b.membro1_nome));

      setCasais(casaisFiltrados);
      setTotalCasais(casaisFiltrados.length);

    } catch (error) {
      console.error("Erro ao buscar casais:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userProfile?.permission === 'ADM') {
      fetchCasais();
    }
  }, [userProfile]);

  useEffect(() => {
    if (userProfile?.permission === 'ADM') {
      const timeoutId = setTimeout(() => {
        fetchCasais();
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [query, userProfile]);

  // Verificar se o usuário tem permissão para acessar o relatório
  if (!userProfile) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="text-lg font-medium">Carregando...</div>
        </div>
      </div>
    );
  }

  // Permitir acesso apenas para ADM
  if (userProfile.permission !== 'ADM') {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="text-lg font-medium text-red-600">Acesso Negado</div>
          <div className="text-sm text-gray-600 mt-2">
            Você não tem permissão para acessar este relatório.
          </div>
        </div>
      </div>
    );
  }

  const exportarCSV = () => {
    const headers = [
      "Membro 1",
      "Apelido 1",
      "Telefone 1",
      "Membro 2",
      "Apelido 2",
      "Telefone 2", 
      "Data Casamento",
      "Tempo Casado"
    ];

    const csvContent = [
      headers.join(","),
      ...casais.map(casal => [
        `"${casal.membro1_nome}"`,
        `"${casal.membro1_apelido || ''}"`,
        `"${casal.membro1_telefone || ''}"`,
        `"${casal.membro2_nome}"`,
        `"${casal.membro2_apelido || ''}"`,
        `"${casal.membro2_telefone || ''}"`,
        `"${casal.data_casamento ? format(new Date(casal.data_casamento), 'dd/MM/yyyy') : ''}"`,
        `"${casal.tempo_casado || ''}"`
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `relatorio_casais_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-elegant">
        <CardHeader className="bg-gradient-subtle pb-8">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-2xl">
              <div className="p-2 bg-pink-100 dark:bg-pink-900/20 rounded-lg">
                <Heart className="h-6 w-6 text-pink-600 dark:text-pink-400" />
              </div>
              Relatório de Casais
            </CardTitle>
            <Badge variant="secondary" className="flex items-center gap-2 px-4 py-2 text-base">
              <Users className="h-4 w-4" />
              {totalCasais} {totalCasais === 1 ? 'casal' : 'casais'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nome do casal..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-10 h-11"
              />
            </div>
            <Button 
              onClick={exportarCSV} 
              variant="outline" 
              className="flex items-center gap-2 h-11 px-6"
            >
              <Download className="h-4 w-4" />
              Exportar CSV
            </Button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center space-y-3">
                <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto"></div>
                <p className="text-muted-foreground">Carregando casais...</p>
              </div>
            </div>
          ) : (
            <>
              {/* Tabela para Desktop */}
              <div className="hidden md:block rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="font-semibold w-[300px]">Casal</TableHead>
                      <TableHead className="font-semibold">Telefones</TableHead>
                      <TableHead className="font-semibold">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Data Casamento
                        </div>
                      </TableHead>
                      <TableHead className="font-semibold">Tempo Casado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {casais.map((casal, index) => (
                      <TableRow key={casal.id} className={index % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                        <TableCell>
                          <div className="space-y-4 py-2">
                            {/* Membro 1 */}
                            <div className="flex items-center gap-3">
                              <Avatar className={`h-12 w-12 border-2 ${
                                casal.membro1_sexo === 'M' ? 'border-blue-200' : 'border-pink-200'
                              }`}>
                                <AvatarImage src={getPhotoUrl(casal.membro1_foto) || ''} alt={casal.membro1_nome} />
                                <AvatarFallback className={`font-semibold ${
                                  casal.membro1_sexo === 'M' 
                                    ? 'bg-blue-100 text-blue-700' 
                                    : 'bg-pink-100 text-pink-700'
                                }`}>
                                  {casal.membro1_nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-semibold text-base leading-tight">{casal.membro1_nome}</div>
                                {casal.membro1_apelido && (
                                  <div className="text-sm text-muted-foreground italic">{casal.membro1_apelido}</div>
                                )}
                              </div>
                            </div>
                            
                            {/* Membro 2 */}
                            <div className="flex items-center gap-3 pl-2">
                              <Avatar className={`h-12 w-12 border-2 ${
                                casal.membro2_sexo === 'M' ? 'border-blue-200' : 'border-pink-200'
                              }`}>
                                <AvatarImage src={getPhotoUrl(casal.membro2_foto) || ''} alt={casal.membro2_nome} />
                                <AvatarFallback className={`font-semibold ${
                                  casal.membro2_sexo === 'M' 
                                    ? 'bg-blue-100 text-blue-700' 
                                    : 'bg-pink-100 text-pink-700'
                                }`}>
                                  {casal.membro2_nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-semibold text-base leading-tight">{casal.membro2_nome}</div>
                                {casal.membro2_apelido && (
                                  <div className="text-sm text-muted-foreground italic">{casal.membro2_apelido}</div>
                                )}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            {casal.membro1_telefone && (
                              <div className="text-sm font-medium whitespace-nowrap">{formatPhone(casal.membro1_telefone)}</div>
                            )}
                            {casal.membro2_telefone && (
                              <div className="text-sm font-medium text-muted-foreground whitespace-nowrap">{formatPhone(casal.membro2_telefone)}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {casal.data_casamento ? (
                            <Badge variant="outline" className="font-medium">
                              {format(new Date(casal.data_casamento), 'dd/MM/yyyy', { locale: ptBR })}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground italic">Não informado</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {casal.tempo_casado ? (
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-gradient-primary flex items-center justify-center">
                                <Heart className="h-4 w-4 text-white" />
                              </div>
                              <span className="font-semibold">{casal.tempo_casado}</span>
                            </div>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                {casais.length === 0 && !loading && (
                  <div className="text-center py-12">
                    <Heart className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground text-lg">
                      {query ? "Nenhum casal encontrado para a busca." : "Nenhum casal cadastrado."}
                    </p>
                  </div>
                )}
              </div>

              {/* Cards para Mobile */}
              <div className="md:hidden space-y-4">
                {casais.map((casal) => (
                  <Card key={casal.id} className="overflow-hidden">
                    <CardContent className="p-4 space-y-4">
                      {/* Membro 1 */}
                      <div className="flex items-start gap-3 pb-3 border-b">
                        <Avatar className={`h-14 w-14 border-2 flex-shrink-0 ${
                          casal.membro1_sexo === 'M' ? 'border-blue-200' : 'border-pink-200'
                        }`}>
                          <AvatarImage src={getPhotoUrl(casal.membro1_foto) || ''} alt={casal.membro1_nome} />
                          <AvatarFallback className={`font-semibold text-sm ${
                            casal.membro1_sexo === 'M' 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-pink-100 text-pink-700'
                          }`}>
                            {casal.membro1_nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-base">{casal.membro1_nome}</div>
                          {casal.membro1_apelido && (
                            <div className="text-sm text-muted-foreground italic">{casal.membro1_apelido}</div>
                          )}
                          {casal.membro1_telefone && (
                            <div className="text-sm font-medium mt-1">{formatPhone(casal.membro1_telefone)}</div>
                          )}
                        </div>
                      </div>

                      {/* Membro 2 */}
                      <div className="flex items-start gap-3 pb-3 border-b">
                        <Avatar className={`h-14 w-14 border-2 flex-shrink-0 ${
                          casal.membro2_sexo === 'M' ? 'border-blue-200' : 'border-pink-200'
                        }`}>
                          <AvatarImage src={getPhotoUrl(casal.membro2_foto) || ''} alt={casal.membro2_nome} />
                          <AvatarFallback className={`font-semibold text-sm ${
                            casal.membro2_sexo === 'M' 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-pink-100 text-pink-700'
                          }`}>
                            {casal.membro2_nome.split(' ').map(n => n[0]).slice(0, 2).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-base">{casal.membro2_nome}</div>
                          {casal.membro2_apelido && (
                            <div className="text-sm text-muted-foreground italic">{casal.membro2_apelido}</div>
                          )}
                          {casal.membro2_telefone && (
                            <div className="text-sm font-medium mt-1">{formatPhone(casal.membro2_telefone)}</div>
                          )}
                        </div>
                      </div>

                      {/* Informações do casamento */}
                      <div className="space-y-2">
                        {casal.data_casamento && (
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                            <span className="font-medium">
                              {format(new Date(casal.data_casamento), 'dd/MM/yyyy', { locale: ptBR })}
                            </span>
                          </div>
                        )}
                        {casal.tempo_casado && (
                          <div className="flex items-center gap-2">
                            <div className="h-7 w-7 rounded-full bg-gradient-primary flex items-center justify-center flex-shrink-0">
                              <Heart className="h-3.5 w-3.5 text-white" />
                            </div>
                            <span className="font-semibold text-sm">{casal.tempo_casado}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {casais.length === 0 && !loading && (
                  <div className="text-center py-12">
                    <Heart className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-muted-foreground">
                      {query ? "Nenhum casal encontrado para a busca." : "Nenhum casal cadastrado."}
                    </p>
                  </div>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}