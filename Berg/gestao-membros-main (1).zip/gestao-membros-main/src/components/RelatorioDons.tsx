import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { getImageUrl } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { Award, CheckCircle, CircleDashed } from "lucide-react";

interface MembroItem {
  idmembro: string;
  nome: string;
  apelido?: string | null;
  foto?: string | null;
  statusAvaliacao: "Concluída" | "Não preenchida";
  domPredominante?: string | null;
  domTop2?: string[];
}

export default function RelatorioDons() {
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState("");
  const [membros, setMembros] = useState<MembroItem[]>([]);
  const { userProfile } = useAuth();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Resolve áreas onde o usuário é líder PRINCIPAL (lider1)
        let myAreas: string[] = [];
        if (userProfile?.idmembro) {
          const { data: areasLideradas, error: areasError } = await supabase
            .from("areas")
            .select("idarea, iddepto")
            .eq("lider1", userProfile.idmembro)
            .eq("status", "Ativo");
          
          if (areasError) {
            console.warn("RelatorioDons: erro ao obter áreas lideradas", areasError);
          } else {
            myAreas = (areasLideradas || []).map((a: any) => String(a.idarea)).filter(Boolean);
          }

          // Também verificar se é líder principal ou auxiliar de algum departamento (liderdepto1 ou liderdepto2)
          const { data: deptosLiderados, error: deptosError } = await supabase
            .from("departamentos")
            .select("iddepto")
            .or(`liderdepto1.eq.${userProfile.idmembro},liderdepto2.eq.${userProfile.idmembro}`);
          
          if (!deptosError && deptosLiderados && deptosLiderados.length > 0) {
            // Buscar todas as áreas desses departamentos
            const deptoIds = deptosLiderados.map((d: any) => d.iddepto);
            const { data: areasDoDepto } = await supabase
              .from("areas")
              .select("idarea")
              .in("iddepto", deptoIds)
              .eq("status", "Ativo");
            
            if (areasDoDepto) {
              const areasAdicionais = areasDoDepto.map((a: any) => String(a.idarea));
              myAreas = Array.from(new Set([...myAreas, ...areasAdicionais]));
            }
          }
        }

        // Busca líderes (membros) vinculados às áreas
        let lideresQuery = supabase
          .from("lideres")
          .select(`
            idmembro,
            idarea,
            status,
            membros:idmembro ( idmembro, nome, apelido, foto )
          `)
          .eq("status", "Ativo")
          .not("idarea", "is", null);

        // Para não-admins, restringe às áreas onde o usuário é líder principal
        if (userProfile?.permission !== "ADM") {
          if (myAreas.length === 0) {
            setMembros([]);
            setLoading(false);
            return;
          }
          lideresQuery = lideresQuery.in("idarea", myAreas);
        }

        const { data: lideresData, error: lideresErr } = await lideresQuery;
        if (lideresErr) throw lideresErr;

        // Deduplica por membro (um líder pode estar em mais de uma área)
        const dedupMap = new Map<string, { idmembro: string; nome: string; apelido?: string | null; foto?: string | null }>();
        (lideresData || []).forEach((l: any) => {
          const m = l.membros;
          if (!m) return;
          if (!dedupMap.has(m.idmembro)) {
            dedupMap.set(m.idmembro, {
              idmembro: m.idmembro,
              nome: m.nome,
              apelido: m.apelido,
              foto: m.foto,
            });
          }
        });

        const base = Array.from(dedupMap.values()).map((m) => ({
          idmembro: m.idmembro,
          nome: m.nome,
          apelido: m.apelido,
          foto: m.foto,
          statusAvaliacao: "Não preenchida" as const,
          domPredominante: null,
          domTop2: [],
        }));

        const results = await Promise.all(
          base.map(async (m) => {
            try {
              const { data: avaliacao, error: avError } = await (supabase as any)
                .from("dons_avaliacoes")
                .select(`
                  idavaliacao,
                  criado_em,
                  status,
                  dons_resultados!inner (
                    pontuacao,
                    dons (nome)
                  )
                `)
                .eq("idmembro", m.idmembro)
                .eq("status", "concluida")
                .order("criado_em", { ascending: false })
                .limit(1)
                .single();

              if (avError) {
                return m; // mantém como não preenchida
              }

              if (avaliacao && Array.isArray(avaliacao.dons_resultados) && avaliacao.dons_resultados.length > 0) {
                const sorted = [...avaliacao.dons_resultados].sort((a: any, b: any) => b.pontuacao - a.pontuacao);
                const top2 = sorted.slice(0, 3).map((item: any) => item?.dons?.nome).filter(Boolean);
                const top = sorted[0];
                return {
                  ...m,
                  statusAvaliacao: "Concluída" as const,
                  domPredominante: top?.dons?.nome || null,
                  domTop2: top2,
                };
              }
              return m;
            } catch (e) {
              return m;
            }
          })
        );

        setMembros(results);
      } catch (err) {
        console.error("RelatorioDons: erro ao carregar dados", err);
        setMembros([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [userProfile?.idmembro, userProfile?.permission]);

  const filtered = membros.filter((m) => {
    const term = query.trim().toLowerCase();
    if (!term) return true;
    return (
      m.nome.toLowerCase().includes(term) ||
      (m.apelido || "").toLowerCase().includes(term) ||
      (m.domPredominante || "").toLowerCase().includes(term) ||
      (m.domTop2 || []).some((d) => (d || "").toLowerCase().includes(term))
    );
  });

  // Ordena alfabeticamente pelo nome do dom predominante (itens sem dom vão ao final)
  const sorted = [...filtered].sort((a, b) => {
    const aApelido = (a.apelido || a.nome).toLowerCase();
    const bApelido = (b.apelido || b.nome).toLowerCase();
    return aApelido.localeCompare(bApelido, "pt-BR", { sensitivity: "base" });
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Relatório de Dons</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Input
              placeholder="Filtrar por nome, apelido ou dom predominante"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          {loading ? (
            <div className="text-sm text-muted-foreground">Carregando membros...</div>
          ) : filtered.length === 0 ? (
            <div className="text-sm text-muted-foreground">Nenhum membro encontrado.</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sorted.map((m) => (
                <Card key={m.idmembro} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3 mb-4">
                      <img
                        src={getImageUrl(m.foto) || "/placeholder.svg"}
                        alt={m.apelido || m.nome}
                        className="w-16 h-16 rounded-full object-cover"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
                        }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-base truncate">{m.apelido || m.nome}</div>
                        <div className="text-sm text-muted-foreground truncate">{m.nome}</div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-success flex-shrink-0" />
                        <span className="text-sm font-medium">Status:</span>
                        {m.statusAvaliacao === "Concluída" ? (
                          <Badge className="bg-success text-success-foreground ml-auto">Concluída</Badge>
                        ) : (
                          <span className="flex items-center gap-1 text-sm text-muted-foreground ml-auto">
                            <CircleDashed className="w-4 h-4" />
                            Não preenchida
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-start gap-2">
                        <Award className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium mb-1">Dons Predominantes:</div>
                          {Array.isArray(m.domTop2) && m.domTop2.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {m.domTop2.slice(0, 3).map((don, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs font-medium">
                                  {don}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">Nenhum dom registrado</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}