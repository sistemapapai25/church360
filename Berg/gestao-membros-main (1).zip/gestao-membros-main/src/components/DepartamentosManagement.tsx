import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, Building, User, Users, MapPin, Search, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";

interface Departamento {
  iddepto: string;
  nome: string;
  liderdepto1?: string;
  liderdepto2?: string;
  pertence_capelania?: boolean;
  observacao?: string;
}

interface LiderInfo {
  idmembro: string;
  nome: string;
  apelido?: string;
  foto?: string;
}

interface MembroDepartamento {
  idmembro: string;
  nome: string;
  apelido?: string;
  foto?: string;
  idarea?: string;
}

interface Area {
  idarea: string;
  nome: string;
  descricao?: string;
  status: string;
  iddepto: string;
  lider1?: string | null;
  lider2?: string | null;
}

export default function DepartamentosManagement() {
  const [departamentos, setDepartamentos] = useState<Departamento[]>([]);
  const [lideres, setLideres] = useState<LiderInfo[]>([]);
  const [membrosDepartamento, setMembrosDepartamento] = useState<Record<string, MembroDepartamento[]>>({});
  const [areasDepartamento, setAreasDepartamento] = useState<Record<string, Area[]>>({});
  const [lideresPorArea, setLideresPorArea] = useState<Record<string, LiderInfo[]>>({});
  const [membrosPorArea, setMembrosPorArea] = useState<Record<string, MembroDepartamento[]>>({});
  const [areasLedByMonitor, setAreasLedByMonitor] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDepto, setEditingDepto] = useState<Departamento | null>(null);
  const [formData, setFormData] = useState({ nome: "", liderdepto1: "", liderdepto2: "", pertence_capelania: false, observacao: "" });

  const [searchTerm, setSearchTerm] = useState("");
  const { userProfile } = useAuth();
  const [visibleDeptoIds, setVisibleDeptoIds] = useState<string[] | null>(null);

  const isCapelania = (nome?: string) => (nome || "").toLowerCase() === "capelania";

  const fetchDepartamentos = async () => {
    setLoading(true);
    try {
      let query = supabase.from('departamentos').select('*').order('nome');
      if (Array.isArray(visibleDeptoIds)) {
        if (visibleDeptoIds.length === 0) {
          setDepartamentos([]);
          return;
        }
        query = query.in('iddepto', visibleDeptoIds);
      }
      const { data, error } = await query;
      if (error) throw error;
      setDepartamentos(data || []);
    } catch (err) {
      toast({
        title: "Erro ao carregar departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchLideres = async () => {
    try {
      const { data, error } = await supabase
        .from('membros')
        .select('idmembro, nome, apelido, foto')
        .eq('status', 'Ativo');
      if (error) throw error;
      
      // Ordenar alfabeticamente por apelido ou nome
      const sortedData = (data || []).sort((a, b) => {
        const nameA = a.apelido || a.nome;
        const nameB = b.apelido || b.nome;
        return nameA.localeCompare(nameB);
      });
      
      setLideres(sortedData);
    } catch (err) {
      toast({
        title: "Erro ao carregar líderes",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const fetchMembrosDepartamento = async () => {
    try {
      let membrosQuery = supabase
        .from('membros')
        .select('idmembro, nome, apelido, foto, iddepto')
        .eq('status', 'Ativo')
        .not('iddepto', 'is', null);
      if (Array.isArray(visibleDeptoIds)) {
        if (visibleDeptoIds.length === 0) {
          setMembrosDepartamento({});
        } else {
          membrosQuery = membrosQuery.in('iddepto', visibleDeptoIds);
        }
      }
      const { data, error } = await membrosQuery;
      if (error) throw error;

      // Buscar todos os líderes com suas áreas para contar membros por área
      let lideresQuery = supabase
        .from('lideres')
        .select(`
          idarea,
          iddepto,
          idmembro,
          membros:idmembro ( idmembro, nome, apelido, foto )
        `)
        .eq('status', 'Ativo')
        .not('idarea', 'is', null);
      if (Array.isArray(visibleDeptoIds) && visibleDeptoIds.length > 0) {
        lideresQuery = lideresQuery.in('iddepto', visibleDeptoIds);
      }
      const { data: lideresData, error: lideresError } = await lideresQuery;
      if (lideresError) throw lideresError;

      // Para Monitores: capturar áreas de CAPELANIA onde ele é líder (principal ou secundário)
      if (userProfile?.permission === 'MTR' && userProfile.idmembro) {
        let capelaniaId: string | null = null;
        try {
          const { data: capDept, error: capErr } = await supabase
            .from('departamentos')
            .select('iddepto, nome')
            .eq('nome', 'Capelania')
            .limit(1)
            .maybeSingle();
          if (!capErr && capDept?.iddepto) {
            capelaniaId = capDept.iddepto as string;
          }
        } catch (e) {
          console.warn('[Departamentos] Exceção ao buscar Capelania para áreas do monitor:', e);
        }

        if (capelaniaId) {
          const { data: capAreas, error: capAreasErr } = await supabase
            .from('areas')
            .select('idarea, lider1, lider2, iddepto')
            .eq('iddepto', capelaniaId)
            .or(`lider1.eq.${userProfile.idmembro},lider2.eq.${userProfile.idmembro}`);
          if (!capAreasErr) {
            const myAreas = Array.from(new Set((capAreas || []).map((a: any) => a.idarea)));
            setAreasLedByMonitor(myAreas);
          } else {
            setAreasLedByMonitor([]);
          }
        } else {
          setAreasLedByMonitor([]);
        }
      } else {
        setAreasLedByMonitor([]);
      }

      const membrosGrouped = (data || []).reduce((acc, membro) => {
        if (!acc[membro.iddepto]) acc[membro.iddepto] = [];
        acc[membro.iddepto].push(membro);
        return acc;
      }, {} as Record<string, MembroDepartamento[]>);

      // Agrupar líderes por área (apenas para exibir os líderes) — evitar duplicatas por idmembro
      const lideresGrouped = (lideresData || []).reduce((acc, lider) => {
        if (!lider.idarea || !lider.membros) return acc;
        if (!acc[lider.idarea]) acc[lider.idarea] = [];
        const exists = acc[lider.idarea].some((m) => m.idmembro === lider.membros.idmembro);
        if (!exists) {
          acc[lider.idarea].push({
            idmembro: lider.membros.idmembro,
            nome: lider.membros.nome,
            apelido: lider.membros.apelido,
            foto: lider.membros.foto
          });
        }
        return acc;
      }, {} as Record<string, LiderInfo[]>);

      // Contar membros por área baseado na tabela de líderes
      const membrosPorArea = (lideresData || []).reduce((acc, lider) => {
        if (!lider.idarea || !lider.membros) return acc;
        if (!acc[lider.idarea]) acc[lider.idarea] = [];
        // Evitar duplicatas de membros na mesma área
        if (!acc[lider.idarea].some(m => m.idmembro === lider.membros.idmembro)) {
          acc[lider.idarea].push({
            idmembro: lider.membros.idmembro,
            nome: lider.membros.nome,
            apelido: lider.membros.apelido,
            foto: lider.membros.foto,
            idarea: lider.idarea
          });
        }
        return acc;
      }, {} as Record<string, MembroDepartamento[]>);

      // Ordenar líderes alfabeticamente dentro de cada área
      Object.keys(lideresGrouped).forEach(idarea => {
        lideresGrouped[idarea].sort((a, b) => {
          const nomeA = a.apelido || a.nome;
          const nomeB = b.apelido || b.nome;
          return nomeA.localeCompare(nomeB);
        });
      });

      setMembrosDepartamento(membrosGrouped);
      setLideresPorArea(lideresGrouped);
      setMembrosPorArea(membrosPorArea);
    } catch (err) {
      toast({
        title: "Erro ao carregar membros dos departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const fetchAreasDepartamento = async () => {
    try {
      let areasQuery = supabase
        .from('areas')
        .select('*')
        .eq('status', 'Ativo')
        .order('nome');
      if (Array.isArray(visibleDeptoIds)) {
        if (visibleDeptoIds.length === 0) {
          setAreasDepartamento({});
          return;
        }
        areasQuery = areasQuery.in('iddepto', visibleDeptoIds);
      }
      const { data, error } = await areasQuery;
      if (error) throw error;

      const areasGrouped = (data || []).reduce((acc, area) => {
        if (!acc[area.iddepto]) acc[area.iddepto] = [];
        acc[area.iddepto].push(area);
        return acc;
      }, {} as Record<string, Area[]>);

      setAreasDepartamento(areasGrouped);
    } catch (err) {
      toast({
        title: "Erro ao carregar áreas dos departamentos",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const getLiderInfo = (idmembro: string): LiderInfo | null =>
    lideres.find(lider => lider.idmembro === idmembro) || null;

  const getImageUrl = (imageName: string | null) => {
    if (!imageName) return null;
    if (imageName.startsWith('http') || imageName.startsWith('/')) return imageName;
    const { data } = supabase.storage.from('member-photos').getPublicUrl(imageName);
    return data.publicUrl;
  };

  const generateId = () => {
    const maxId = departamentos.reduce((max, dept) => {
      const numericPart = parseInt(dept.iddepto.replace(/\D/g, ''));
      return Math.max(max, isNaN(numericPart) ? 0 : numericPart);
    }, 0);
    return `DEP${(maxId + 1).toString().padStart(3, '0')}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nome.trim()) {
      toast({ title: "Nome obrigatório", description: "Por favor, informe o nome do departamento", variant: "destructive" });
      return;
    }

    try {
      if (editingDepto) {
        const { error } = await supabase
          .from('departamentos')
          .update({
            nome: formData.nome,
            liderdepto1: formData.liderdepto1 || null,
            liderdepto2: formData.liderdepto2 || null,
            pertence_capelania: formData.pertence_capelania,
            observacao: formData.observacao || null
          })
          .eq('iddepto', editingDepto.iddepto);
        
        if (error) throw error;
        
        toast({ title: "Departamento atualizado!", description: `${formData.nome} foi atualizado com sucesso.` });
        
        // Recarrega todos os dados para garantir sincronização
        await Promise.all([
          fetchDepartamentos(),
          fetchLideres(),
          fetchMembrosDepartamento(),
          fetchAreasDepartamento()
        ]);
      } else {
        const newId = generateId();
        const { error } = await supabase
          .from('departamentos')
          .insert({
            iddepto: newId,
            nome: formData.nome,
            liderdepto1: formData.liderdepto1 || null,
            liderdepto2: formData.liderdepto2 || null,
            pertence_capelania: formData.pertence_capelania,
            observacao: formData.observacao || null
          });
        if (error) throw error;
        toast({ title: "Departamento criado!", description: `${formData.nome} foi criado com sucesso.` });
        
        await fetchDepartamentos();
      }

      setIsDialogOpen(false);
      setEditingDepto(null);
      setFormData({ nome: "", liderdepto1: "", liderdepto2: "", pertence_capelania: false, observacao: "" });
    } catch (err) {
      toast({
        title: editingDepto ? "Erro ao atualizar" : "Erro ao criar",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (depto: Departamento) => {
    console.log('🗑️ Tentando excluir departamento:', depto);
    console.log('👤 Perfil do usuário:', userProfile);
    
    try {
      // Verificar se há líderes vinculados ao departamento (ativos e inativos)
      const { data: todosLideres, error: lideresError } = await supabase
        .from('lideres')
        .select('idlider, idmembro, status, membros:idmembro(nome)')
        .eq('iddepto', depto.iddepto);
      
      if (lideresError) {
        console.error('❌ Erro ao verificar líderes:', lideresError);
        throw new Error('Erro ao verificar líderes do departamento');
      }
      
      // Se há líderes vinculados, desvinculá-los para preservar o histórico
      if (todosLideres && todosLideres.length > 0) {
        console.log('👤 Desvinculando líderes do departamento:', todosLideres);
        const { error: updateLideresError } = await supabase
          .from('lideres')
          .update({ iddepto: null })
          .eq('iddepto', depto.iddepto);
        
        if (updateLideresError) {
          console.error('❌ Erro ao desvincular líderes:', updateLideresError);
          throw new Error('Erro ao desvincular líderes do departamento');
        }
        
        console.log('✅ Líderes desvinculados com sucesso');
      }
      
      // Verificar se há membros vinculados ao departamento
      const { data: membrosVinculados, error: membrosError } = await supabase
        .from('membros')
        .select('idmembro, nome')
        .eq('iddepto', depto.iddepto);
      
      if (membrosError) {
        console.error('❌ Erro ao verificar membros:', membrosError);
        throw new Error('Erro ao verificar membros do departamento');
      }
      
      // Se há membros vinculados, remover a vinculação
      if (membrosVinculados && membrosVinculados.length > 0) {
        console.log('👥 Removendo vinculação de membros:', membrosVinculados);
        const { error: updateMembrosError } = await supabase
          .from('membros')
          .update({ iddepto: null })
          .eq('iddepto', depto.iddepto);
        
        if (updateMembrosError) {
          console.error('❌ Erro ao remover vinculação de membros:', updateMembrosError);
          throw new Error('Erro ao remover vinculação de membros do departamento');
        }
        
        console.log('✅ Vinculação de membros removida com sucesso');
      }
      
      // Verificar se há áreas associadas ao departamento
      const { data: areasAssociadas, error: areasError } = await supabase
        .from('areas')
        .select('idarea, nome')
        .eq('iddepto', depto.iddepto);
      
      if (areasError) {
        console.error('❌ Erro ao verificar áreas:', areasError);
        throw new Error('Erro ao verificar áreas do departamento');
      }
      
      // Se há áreas associadas, desvinculá-las ao invés de excluí-las
      if (areasAssociadas && areasAssociadas.length > 0) {
        console.log('🗂️ Desvinculando áreas associadas:', areasAssociadas);
        const { error: updateAreasError } = await supabase
          .from('areas')
          .update({ iddepto: null })
          .eq('iddepto', depto.iddepto);
        
        if (updateAreasError) {
          console.error('❌ Erro ao desvincular áreas:', updateAreasError);
          throw new Error('Erro ao desvincular áreas do departamento');
        }
        
        console.log('✅ Áreas desvinculadas com sucesso');
      }
      
      // Verificar se há eventos na agenda associados ao departamento
      const { data: eventosAgenda, error: agendaError } = await supabase
        .from('agenda')
        .select('idagenda, descricao')
        .eq('iddepto', depto.iddepto);
      
      if (agendaError) {
        console.error('❌ Erro ao verificar agenda:', agendaError);
        throw new Error('Erro ao verificar eventos na agenda do departamento');
      }
      
      // Se há eventos na agenda, desvinculá-los para preservar o histórico
      if (eventosAgenda && eventosAgenda.length > 0) {
        console.log('📅 Desvinculando eventos da agenda para preservar histórico:', eventosAgenda);
        const { error: updateAgendaError } = await supabase
          .from('agenda')
          .update({ iddepto: null })
          .eq('iddepto', depto.iddepto);
        
        if (updateAgendaError) {
          console.error('❌ Erro ao desvincular eventos da agenda:', updateAgendaError);
          throw new Error('Erro ao desvincular eventos da agenda do departamento');
        }
        
        console.log('✅ Eventos da agenda desvinculados com sucesso (histórico preservado)');
      }
      
      // Agora excluir o departamento
      const { error } = await supabase.from('departamentos').delete().eq('iddepto', depto.iddepto);
      
      if (error) {
        console.error('❌ Erro na exclusão:', error);
        
        // Tratar erros específicos de constraint
        if (error.code === '23503') {
          toast({ 
            title: "Não é possível excluir", 
            description: "Este departamento ainda possui dependências que impedem sua exclusão.", 
            variant: "destructive" 
          });
          return;
        }
        
        throw error;
      }
      
      console.log('✅ Departamento excluído com sucesso');
      
      // Construir mensagem de sucesso detalhada
      let mensagem = `${depto.nome} foi excluído com sucesso.`;
      const detalhes = [];
      
      if (membrosVinculados && membrosVinculados.length > 0) {
        detalhes.push(`${membrosVinculados.length} membro(s) desvinculado(s)`);
      }
      
      if (todosLideres && todosLideres.length > 0) {
        detalhes.push(`${todosLideres.length} líder(es) desvinculado(s)`);
      }
      
      if (areasAssociadas && areasAssociadas.length > 0) {
        detalhes.push(`${areasAssociadas.length} área(s) desvinculada(s)`);
      }
      
      if (eventosAgenda && eventosAgenda.length > 0) {
        detalhes.push(`${eventosAgenda.length} evento(s) da agenda desvinculado(s)`);
      }
      
      if (detalhes.length > 0) {
        mensagem += ` Também foram processados: ${detalhes.join(', ')}.`;
      }
      
      toast({ title: "Departamento excluído!", description: mensagem });
      fetchDepartamentos();
    } catch (err) {
      console.error('💥 Erro capturado:', err);
      toast({ 
        title: "Erro ao excluir", 
        description: err instanceof Error ? err.message : "Erro desconhecido", 
        variant: "destructive" 
      });
    }
  };

  const openEditDialog = (depto: Departamento) => {
    setEditingDepto(depto);
    setFormData({
      nome: depto.nome,
      liderdepto1: depto.liderdepto1 || "",
      liderdepto2: depto.liderdepto2 || "",
      pertence_capelania: depto.pertence_capelania || false,
      observacao: depto.observacao || ""
    });
    setIsDialogOpen(true);
  };

  useEffect(() => {
    const resolveVisible = async () => {
      // Monitores: restringe aos departamentos onde é líder
      if (userProfile?.permission === 'MTR') {
        if (userProfile.idmembro) {
          try {
            const memberId = String(userProfile.idmembro);
            // Departamentos onde é líder de departamento
            const { data: deptosByDeptLeader, error: deptLeaderErr } = await supabase
              .from('departamentos')
              .select('iddepto')
              .or(`liderdepto1.eq.${memberId},liderdepto2.eq.${memberId}`);

            if (deptLeaderErr) {
              console.error('[Departamentos] Erro ao resolver visibilidade (líder de departamento):', deptLeaderErr);
              setVisibleDeptoIds([]);
              return;
            }

            // Áreas: considerar visibilidade APENAS para departamento Capelania onde é líder (principal ou secundário)
            let capelaniaId: string | null = null;
            try {
              const { data: capDept, error: capErr } = await supabase
                .from('departamentos')
                .select('iddepto, nome')
                .eq('nome', 'Capelania')
                .limit(1)
                .maybeSingle();
              if (!capErr && capDept?.iddepto) {
                capelaniaId = capDept.iddepto as string;
              }
            } catch (e) {
              console.warn('[Departamentos] Exceção ao localizar Capelania:', e);
            }

            let areaDeptIds: string[] = [];
            if (capelaniaId) {
              const { data: capAreas, error: capAreasErr } = await supabase
                .from('areas')
                .select('idarea, iddepto, lider1, lider2')
                .eq('iddepto', capelaniaId)
                .or(`lider1.eq.${memberId},lider2.eq.${memberId}`);
              if (!capAreasErr && (capAreas || []).length > 0) {
                areaDeptIds = [capelaniaId];
              }
            }

            const ids = Array.from(new Set([
              ...((deptosByDeptLeader || []).map((d: any) => d.iddepto).filter(Boolean)),
              ...areaDeptIds,
            ]));
            setVisibleDeptoIds(ids);
            if (ids.length === 0) {
              toast({
                title: 'Sem departamentos como líder',
                description: 'Seu perfil de monitor não está vinculado como líder de departamento ou de área em nenhum departamento.',
              });
            }
          } catch (err) {
            console.error('[Departamentos] Erro inesperado ao resolver visibilidade:', err);
            setVisibleDeptoIds([]);
          }
        } else {
          setVisibleDeptoIds([]);
          toast({
            title: 'Perfil sem membro vinculado',
            description: 'Monitores sem idmembro não podem ver departamentos.',
          });
        }
      } else {
        // Demais permissões: vê todos os departamentos
        setVisibleDeptoIds(null);
      }
    };

    resolveVisible();
  }, [userProfile?.permission, userProfile?.idmembro]);

  useEffect(() => {
    // Carrega dados após definir quais departamentos são visíveis
    fetchDepartamentos();
    fetchLideres();
    fetchMembrosDepartamento();
    fetchAreasDepartamento();
  }, [visibleDeptoIds]);

  const normalized = (s?: string) =>
    (s || "").toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");

  const leaderName = (id?: string) => {
    if (!id) return "";
    const l = getLiderInfo(id);
    return l ? normalized(l.apelido || l.nome) : "";
    };

  const filteredDepartamentos = useMemo(() => {
    const q = normalized(searchTerm);
    if (!q) return departamentos;
    return departamentos.filter((d) => {
      const nome = normalized(d.nome);
      const l1 = leaderName(d.liderdepto1);
      const l2 = leaderName(d.liderdepto2);
      return nome.includes(q) || l1.includes(q) || l2.includes(q);
    });
  }, [departamentos, searchTerm, lideres]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <Building className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Gerenciar Departamentos</h2>
        </div>

        {/* Barra de busca */}
        <div className="relative max-w-xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Buscar departamento por nome ou líder..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-10"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {userProfile?.permission !== 'MTR' && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setEditingDepto(null);
                  setFormData({ nome: "", liderdepto1: "", liderdepto2: "", pertence_capelania: false, observacao: "" });
                }}
                className="bg-primary hover:bg-primary-hover w-fit"
              >
                <Plus className="w-4 h-4 mr-2" />
                Novo Departamento
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingDepto ? "Editar Departamento" : "Novo Departamento"}
                </DialogTitle>
                <DialogDescription>Preencha os dados do departamento e selecione os líderes.</DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome do Departamento *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                  placeholder="Digite o nome do departamento"
                  required
                />
              </div>

              <div>
                <Label htmlFor="liderdepto1">Líder do Departamento</Label>
                <Select
                  value={formData.liderdepto1 || "none"}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, liderdepto1: value === "none" ? "" : value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um membro" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {lideres.map((lider) => (
                      <SelectItem key={lider.idmembro} value={lider.idmembro}>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                            {getImageUrl(lider.foto) ? (
                              <img
                                src={getImageUrl(lider.foto)!}
                                alt={lider.nome}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <User className="w-3 h-3 text-muted-foreground" />
                            )}
                          </div>
                          <span>{lider.apelido || lider.nome}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="liderdepto2">Auxiliar do Líder</Label>
                <Select
                  value={formData.liderdepto2 || "none"}
                  onValueChange={(value) =>
                    setFormData((prev) => ({ ...prev, liderdepto2: value === "none" ? "" : value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um membro" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {lideres.map((lider) => (
                      <SelectItem key={lider.idmembro} value={lider.idmembro}>
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                            {getImageUrl(lider.foto) ? (
                              <img
                                src={getImageUrl(lider.foto)!}
                                alt={lider.nome}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <User className="w-3 h-3 text-muted-foreground" />
                            )}
                          </div>
                          <span>{lider.apelido || lider.nome}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-muted/30">
                <div className="space-y-0.5">
                  <Label htmlFor="pertence_capelania" className="text-base">
                    Pertence à Capelania
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Marque se este departamento faz parte da estrutura de Capelania
                  </p>
                </div>
                <Switch
                  id="pertence_capelania"
                  checked={formData.pertence_capelania}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, pertence_capelania: checked }))
                  }
                />
              </div>

              <div>
                <Label htmlFor="observacao">Observação</Label>
                <Textarea
                  id="observacao"
                  value={formData.observacao}
                  onChange={(e) => setFormData((prev) => ({ ...prev, observacao: e.target.value }))}
                  placeholder="Digite observações sobre o departamento"
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">{editingDepto ? "Atualizar" : "Criar"}</Button>
              </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-4">
        {loading ? (
          <div className="text-center py-8">Carregando...</div>
        ) : (
          filteredDepartamentos.map((depto) => (
            <Card key={depto.iddepto} className="bg-gradient-card border-border/50">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg">{depto.nome}</h3>
                      {depto.pertence_capelania && (
                        <Badge variant="secondary" className="text-xs">
                          Capelania
                        </Badge>
                      )}
                    </div>

                    {(depto.liderdepto1 || depto.liderdepto2) && (
                      <div className="mt-3 space-y-2">
                        {depto.liderdepto1 && (() => {
                          const liderInfo = getLiderInfo(depto.liderdepto1);
                          return (
                            <div className="flex items-center gap-2 text-sm">
                              <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                {liderInfo && getImageUrl(liderInfo.foto) ? (
                                  <img
                                    src={getImageUrl(liderInfo.foto)!}
                                    alt={liderInfo.nome}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      e.currentTarget.style.display = "none";
                                      const nextElement = e.currentTarget.nextElementSibling as HTMLElement;
                                      if (nextElement) nextElement.style.display = "flex";
                                    }}
                                  />
                                ) : null}
                                <User className="w-3 h-3 text-muted-foreground" />
                              </div>
                              <div>
                                <span className="font-medium">Líder do Departamento: </span>
                                {liderInfo ? (
                                  <span>{liderInfo.apelido || liderInfo.nome}</span>
                                ) : (
                                  <span className="text-muted-foreground">Membro não encontrado</span>
                                )}
                              </div>
                            </div>
                          );
                        })()}

                        {depto.liderdepto2 && (() => {
                          const liderInfo = getLiderInfo(depto.liderdepto2);
                          return (
                            <div className="flex items-center gap-2 text-sm">
                              <div className="w-6 h-6 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                {liderInfo && getImageUrl(liderInfo.foto) ? (
                                  <img
                                    src={getImageUrl(liderInfo.foto)!}
                                    alt={liderInfo.nome}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      e.currentTarget.style.display = "none";
                                      const nextElement = e.currentTarget.nextElementSibling as HTMLElement;
                                      if (nextElement) nextElement.style.display = "flex";
                                    }}
                                  />
                                ) : null}
                                <User className="w-3 h-3 text-muted-foreground" />
                              </div>
                              <div>
                                <span className="font-medium">Auxiliar do Líder: </span>
                                {liderInfo ? (
                                  <span>{liderInfo.apelido || liderInfo.nome}</span>
                                ) : (
                                  <span className="text-muted-foreground">Membro não encontrado</span>
                                )}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    )}

                    {(() => {
                      const areasBase = areasDepartamento[depto.iddepto] || [];
                      const areasToShow = (userProfile?.permission === 'MTR' && Array.isArray(areasLedByMonitor) && areasLedByMonitor.length > 0)
                        ? areasBase.filter(a => areasLedByMonitor.includes(a.idarea))
                        : areasBase;
                      if (areasToShow.length === 0) return null;
                      return (
                      <div className="mt-4">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium text-muted-foreground">
                            Áreas ({areasToShow.length})
                          </span>
                        </div>
                        <div className="grid gap-2">
                          {areasToShow.map((area) => {
                            const areaLideresCount = isCapelania(depto.nome)
                              ? ((area.lider1 ? 1 : 0) + (area.lider2 ? 1 : 0))
                              : (lideresPorArea[area.idarea]?.length || 0);

                            return (
                              <div key={area.idarea} className="bg-muted/30 rounded-lg p-3 border border-border/30">
                              <div className="flex items-start justify-between">
                                  <div className="flex items-start gap-2 flex-1">
                                    <MapPin className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium text-sm">{area.nome}</span>
                                        <Badge variant="outline" className="text-xs">
                                          {areaLideresCount} {areaLideresCount === 1 ? "líder" : "líderes"}
                                        </Badge>
                                      </div>
                                      {area.descricao && (
                                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                                          {area.descricao}
                                        </p>
                                      )}

                                      {(() => {
                                        const lideresArea = lideresPorArea[area.idarea] || [];
                                        return isCapelania(depto.nome) ? (
                                          <div className="mt-2 space-y-1">
                                            <p className="text-xs font-medium text-muted-foreground">Líderes:</p>
                                            <div className="flex items-center gap-2">
                                              <span className="text-xs font-medium">Líder Principal:</span>
                                              {area.lider1 ? (() => {
                                                const principal = getLiderInfo(area.lider1!);
                                                return principal ? (
                                                  <div className="flex items-center gap-1 bg-primary/10 rounded-full px-2 py-0.5">
                                                    <div className="w-4 h-4 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                                      {getImageUrl(principal.foto ?? null) ? (
                                                        <img
                                                          src={getImageUrl(principal.foto ?? null)!}
                                                          alt={principal.nome}
                                                          className="w-full h-full object-cover"
                                                        />
                                                      ) : (
                                                        <User className="w-2.5 h-2.5 text-muted-foreground" />
                                                      )}
                                                    </div>
                                                    <span className="text-xs font-medium text-primary">
                                                      {principal.apelido || principal.nome}
                                                    </span>
                                                  </div>
                                                ) : (
                                                  <span className="text-xs text-muted-foreground">Membro não encontrado</span>
                                                );
                                              })() : (
                                                <span className="text-xs text-muted-foreground">Não definido</span>
                                              )}
                                            </div>

                                            <div className="flex items-center gap-2">
                                              <span className="text-xs font-medium">Líder Secundário:</span>
                                              {area.lider2 ? (() => {
                                                const secundario = getLiderInfo(area.lider2!);
                                                return secundario ? (
                                                  <div className="flex items-center gap-1 bg-primary/10 rounded-full px-2 py-0.5">
                                                    <div className="w-4 h-4 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                                      {getImageUrl(secundario.foto ?? null) ? (
                                                        <img
                                                          src={getImageUrl(secundario.foto ?? null)!}
                                                          alt={secundario.nome}
                                                          className="w-full h-full object-cover"
                                                        />
                                                      ) : (
                                                        <User className="w-2.5 h-2.5 text-muted-foreground" />
                                                      )}
                                                    </div>
                                                    <span className="text-xs font-medium text-primary">
                                                      {secundario.apelido || secundario.nome}
                                                    </span>
                                                  </div>
                                                ) : (
                                                  <span className="text-xs text-muted-foreground">Membro não encontrado</span>
                                                );
                                              })() : (
                                                <span className="text-xs text-muted-foreground">Não definido</span>
                                              )}
                                            </div>
                                          </div>
                                        ) : (
                                          lideresArea.length > 0 ? (
                                            <div className="mt-2">
                                              <p className="text-xs font-medium text-muted-foreground mb-1">Líderes:</p>
                                              <div className="flex flex-wrap gap-1">
                                                {lideresArea.map((lider) => (
                                                  <div key={lider.idmembro} className="flex items-center gap-1 bg-primary/10 rounded-full px-2 py-0.5">
                                                    <div className="w-4 h-4 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden flex-shrink-0">
                                                      {getImageUrl(lider.foto) ? (
                                                        <img
                                                          src={getImageUrl(lider.foto)!}
                                                          alt={lider.nome}
                                                          className="w-full h-full object-cover"
                                                        />
                                                      ) : (
                                                        <User className="w-2.5 h-2.5 text-muted-foreground" />
                                                      )}
                                                    </div>
                                                    <span className="text-xs font-medium text-primary">
                                                      {lider.apelido || lider.nome}
                                                    </span>
                                                  </div>
                                                ))}
                                              </div>
                                            </div>
                                          ) : null
                                        );
                                      })()}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      );
                    })()}

                    {/* Informação de total de membros removida conforme solicitação */}
                  </div>

                  {userProfile?.permission !== 'MTR' && (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => openEditDialog(depto)}>
                        <Edit className="w-4 h-4" />
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="destructive">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja excluir o departamento "{depto.nome}"?
                              Esta ação não pode ser desfeita.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(depto)}>
                              Excluir
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}

        {!loading && filteredDepartamentos.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <Building className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum departamento encontrado</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
