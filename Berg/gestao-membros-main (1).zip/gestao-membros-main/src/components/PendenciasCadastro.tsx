import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Member {
  idmembro?: string;
  email?: string;
  cep?: string | null;
  nascimento?: string;
  sexo?: string;
  profissao?: string | null;
  estado_civil?: string | null;
  data_casamento?: string | null;
  credencial?: string | null;
  consentimento?: boolean | null;
}

interface PendingField {
  field: string;
  label: string;
  isMissing: boolean;
  isRequired: boolean;
}

interface Props {
  member: Member;
}

export default function PendenciasCadastro({ member }: Props) {
  const [hasDonsAvaliacao, setHasDonsAvaliacao] = useState<boolean>(false);
  const [loadingDons, setLoadingDons] = useState<boolean>(true);

  // Verificar se o membro tem avaliação de dons concluída
  useEffect(() => {
    const checkDonsAvaliacao = async () => {
      if (!member.idmembro) {
        setHasDonsAvaliacao(false);
        setLoadingDons(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('dons_avaliacoes')
          .select('idavaliacao')
          .eq('idmembro', member.idmembro)
          .eq('status', 'concluida')
          .limit(1)
          .single();

        if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
          console.error('Erro ao verificar avaliação de dons:', error);
        }

        setHasDonsAvaliacao(!!data);
      } catch (err) {
        console.error('Erro ao verificar avaliação de dons:', err);
        setHasDonsAvaliacao(false);
      } finally {
        setLoadingDons(false);
      }
    };

    checkDonsAvaliacao();
  }, [member.idmembro]);

  // Função para verificar se um campo está preenchido
  const isFieldEmpty = (value: string | null | undefined): boolean => {
    return !value || value.toString().trim() === "";
  };

  // Função para verificar se o CEP é válido (deve ter exatamente 8 caracteres)
  const isCepInvalid = (cep: string | null | undefined): boolean => {
    if (!cep) return true;
    const cleanCep = cep.toString().replace(/\D/g, ''); // Remove caracteres não numéricos
    return cleanCep.length !== 8;
  };

  // Função para verificar se é casado
  const isCasado = (): boolean => {
    return member.estado_civil === "Casado(a)";
  };

  // Função para verificar se a credencial está vencida
  const isCredencialVencida = (credencial?: string | null): boolean => {
    if (!credencial || credencial.trim() === "") return false; // Se não tem credencial, não está vencida, está em branco
    const today = new Date();
    const credencialDate = new Date(credencial);
    return credencialDate < today;
  };

  // Função para verificar se a credencial está pendente (em branco ou vencida)
  const isCredencialPendente = (): boolean => {
    return isFieldEmpty(member.credencial) || isCredencialVencida(member.credencial);
  };

  // Função para verificar se o consentimento LGPD está pendente
  const isConsentimentoPendente = (): boolean => {
    return member.consentimento !== true; // Pendente se não for explicitamente true
  };

  // Função para verificar se a ficha de dons está pendente
  const isFichaDonsPendente = (): boolean => {
    return !loadingDons && !hasDonsAvaliacao;
  };

  // Lista de campos obrigatórios
  const requiredFields: PendingField[] = [
    {
      field: "email",
      label: "E-mail",
      isMissing: isFieldEmpty(member.email),
      isRequired: true,
    },
    {
      field: "cep",
      label: "CEP",
      isMissing: isCepInvalid(member.cep),
      isRequired: true,
    },
    {
      field: "nascimento",
      label: "Data de Nascimento",
      isMissing: isFieldEmpty(member.nascimento),
      isRequired: true,
    },
    {
      field: "sexo",
      label: "Sexo",
      isMissing: isFieldEmpty(member.sexo),
      isRequired: true,
    },
    {
      field: "profissao",
      label: "Profissão",
      isMissing: isFieldEmpty(member.profissao),
      isRequired: true,
    },
    {
      field: "estado_civil",
      label: "Estado Civil",
      isMissing: isFieldEmpty(member.estado_civil),
      isRequired: true,
    },
    {
      field: "data_casamento",
      label: "Data do Casamento",
      isMissing: isCasado() && isFieldEmpty(member.data_casamento),
      isRequired: isCasado(),
    },
    {
      field: "credencial",
      label: "Credencial",
      isMissing: isCredencialPendente(),
      isRequired: true,
    },
    {
      field: "consentimento",
      label: "Consentimento LGPD",
      isMissing: isConsentimentoPendente(),
      isRequired: true,
    },
    {
      field: "ficha_dons",
      label: "Ficha de Dons Espirituais",
      isMissing: isFichaDonsPendente(),
      isRequired: true,
    },
  ];

  // Filtrar apenas os campos que estão faltando
  const missingFields = requiredFields.filter(field => field.isMissing && field.isRequired);
  const completedFields = requiredFields.filter(field => !field.isMissing && field.isRequired);

  // Calcular percentual de completude
  const totalRequiredFields = requiredFields.filter(field => field.isRequired).length;
  const completedCount = completedFields.length;
  const completionPercentage = totalRequiredFields > 0 ? Math.round((completedCount / totalRequiredFields) * 100) : 0;

  return (
    <Card className="mt-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-orange-500" />
            <CardTitle>Pendências do Cadastro</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge 
              variant={completionPercentage === 100 ? "default" : "secondary"}
              className={completionPercentage === 100 ? "bg-green-500 hover:bg-green-600" : ""}
            >
              {completionPercentage}% Completo
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {missingFields.length === 0 ? (
          <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-green-800 font-medium">Cadastro Completo!</p>
              <p className="text-green-600 text-sm">Todas as informações obrigatórias foram preenchidas.</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="text-orange-800 font-medium mb-2">
                {missingFields.length === 1 
                  ? "1 campo precisa ser preenchido:" 
                  : `${missingFields.length} campos precisam ser preenchidos:`
                }
              </p>
              <div className="space-y-2">
                {missingFields.map((field) => (
                  <div key={field.field} className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                    <span className="text-orange-700 text-sm font-medium">
                      {field.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              <p>
                Para completar seu cadastro, clique em <strong>"Editar Informações"</strong> e 
                preencha os campos indicados acima.
              </p>
              {isCasado() && isFieldEmpty(member.data_casamento) && (
                <p className="mt-2 text-orange-600">
                  <strong>Nota:</strong> Como seu estado civil é "Casado(a)", a data do casamento é obrigatória.
                </p>
              )}
              {isConsentimentoPendente() && (
                <p className="mt-2 text-blue-600">
                  <strong>Consentimento LGPD:</strong> É necessário informar se você concorda ou não com a Política de Privacidade conforme a Lei nº 13.709/2018 (LGPD).
                </p>
              )}
            </div>

            {completedFields.length > 0 && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-green-800 font-medium text-sm mb-2">
                  Campos já preenchidos ({completedFields.length}):
                </p>
                <div className="flex flex-wrap gap-1">
                  {completedFields.map((field) => (
                    <Badge key={field.field} variant="outline" className="text-green-700 border-green-300">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      {field.label}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}