// src/components/PerfilMembro.tsx
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { calculateAge, formatDate, getImageUrl } from "@/lib/utils";
import LiderancaInfo from "@/components/LiderancaInfo";
import FamilyRelationships from "@/components/FamilyRelationships";
import PendenciasCadastro from "@/components/PendenciasCadastro";
import PoliticaPrivacidadeModal from "@/components/PoliticaPrivacidadeModal";
import { formatPhone } from "@/lib/formatPhone";
import { Mail, Phone, Calendar, Building, User, MapPin, ExternalLink, Award, QrCode, Shield, FileText } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "@/hooks/use-toast";
import { useProfissoes } from "@/hooks/useProfissoes";

type Status = "Ativo" | "Inativo";

interface Member {
  idmembro: string;
  nome: string;
  apelido?: string;
  email?: string;
  telefone?: string;
  nascimento?: string;
  sexo?: string;
  cpf?: string | null;
  cep?: string | null;
  endereco?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null; // Nome da cidade ou ID da tabela cidade
  uf?: string | null;     // "SP", "GO"
  profissao?: string | null;
  estado_civil?: string | null; // Solteiro(a), Casado(a)...
  data_casamento?: string | null;
  conjuge_id?: string | null;
  tipo_membro?: string | null;
  status: Status;
  iddepto?: string | null;
  foto?: string | null;
  ficha_pdf?: string | null;
  entrevista?: string | null;
  entrevistador?: string | null;
  credencial?: string | null;
  consentimento?: boolean | null;
  created_at?: string;
  updated_at?: string;
  relacionamentos?: Array<{ tipo_relacionamento: string; parente: { nome: string } }>;
}

const normalizeMember = (m: any): Member => ({
  idmembro: m.idmembro,
  nome: m.nome,
  apelido: m.apelido ?? undefined,
  email: m.email ?? undefined,
  telefone: m.telefone ?? undefined,
  nascimento: m.nascimento ?? undefined,
  sexo: m.sexo ?? undefined,
  cpf: m.cpf ?? null,
  cep: m.cep ?? null,
  endereco: m.endereco ?? null,
  complemento: m.complemento ?? null,
  bairro: m.bairro ?? null,
  cidade: m.cidade ?? null,
  uf: m.uf ?? null,
  profissao: m.profissao ?? null,
  estado_civil: m.estado_civil ?? null,
  data_casamento: m.data_casamento ?? null,
  conjuge_id: m.conjuge_id ?? null,
  tipo_membro: m.tipo_membro ?? null,
  status: m.status as Status,
  iddepto: m.iddepto ?? null,
  foto: m.foto ?? null,
  ficha_pdf: m.ficha_pdf ?? null,
  entrevista: m.entrevista ?? null,
  entrevistador: m.entrevistador ?? null,
  credencial: m.credencial ?? null,
  consentimento: m.consentimento ?? null,
  created_at: m.created_at ?? undefined,
  updated_at: m.updated_at ?? undefined,
  relacionamentos: m.relacionamentos ?? undefined,
});

// Helpers de mapeamento de sexo para código e rótulo
const toSexoCode = (v?: string | null) => {
  if (!v) return undefined;
  if (v === "M" || v === "F") return v;
  const lower = v.toLowerCase();
  if (lower.startsWith("masc")) return "M";
  if (lower.startsWith("fem")) return "F";
  return v; // mantém valor cru se for algo diferente
};

const sexoLabel = (v?: string | null) => {
  if (!v) return "";
  if (v === "M") return "Masculino";
  if (v === "F") return "Feminino";
  return v; // se já vier como "Masculino/Feminino" mantém
};

// Função para verificar se a credencial está vencida
const isCredencialVencida = (credencial?: string | null): boolean => {
  if (!credencial) return false;
  const hoje = new Date();
  const dataCredencial = new Date(credencial);
  return dataCredencial < hoje;
};

// Função para obter o status da credencial
const getCredencialStatus = (credencial?: string | null): { texto: string; cor: string; icone: string } => {
  if (!credencial || credencial.trim() === "") {
    return { texto: "Favor Providenciar a Credencial", cor: "text-yellow-600", icone: "text-yellow-600" };
  }
  
  const vencida = isCredencialVencida(credencial);
  if (vencida) {
    return { texto: "Credencial Vencida", cor: "text-red-600", icone: "text-red-600" };
  } else {
    return { texto: "Credencial Ativa", cor: "text-green-600", icone: "text-green-600" };
  }
};

interface Props {
  user: { email: string; permission: string; memberName?: string };
}

export default function PerfilMembro({ user }: Props) {
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [emailCheckDone, setEmailCheckDone] = useState(false);
  const [emailNotFound, setEmailNotFound] = useState(false);
  const [loadingPredominantDon, setLoadingPredominantDon] = useState(false);
  const [topDons, setTopDons] = useState<Array<{ nome: string; pontuacao: number }>>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<Member>>({});
  const { profissoes, loading: loadingProfissoes, getProfissaoNome } = useProfissoes();
  const [cepLoading, setCepLoading] = useState(false);

  // Auto-seleciona o membro pelo email do usuário logado
  useEffect(() => {
    const fetchByEmail = async () => {
      if (!user?.email) return;
      const { data, error } = await supabase
        .from("membros")
        .select("*")
        .eq("email", user.email)
        .limit(1);
      if (!error) {
        setEmailCheckDone(true);
        if (data && data.length > 0) {
          const m = normalizeMember(data[0]);
          setSelectedMember(m);
          setEmailNotFound(false);
        } else {
          setEmailNotFound(true);
        }
      }
    };
    fetchByEmail();
  }, [user?.email]);

  // Busca a avaliação mais recente concluída e pega o dom com maior pontuação
  useEffect(() => {
    const fetchPredominantDon = async () => {
      if (!selectedMember?.idmembro) {
        setTopDons([]);
        return;
      }
      setLoadingPredominantDon(true);
      try {
        const { data, error } = await (supabase as any)
          .from('dons_avaliacoes')
          .select(`
            idavaliacao,
            criado_em,
            dons_resultados!inner (
              pontuacao,
              dons (codigo, nome)
            )
          `)
          .eq('idmembro', selectedMember.idmembro)
          .eq('status', 'concluida')
          .order('criado_em', { ascending: false })
          .limit(1)
          .single();

        if (error) throw error;

        if (data && Array.isArray(data.dons_resultados) && data.dons_resultados.length > 0) {
          const sorted = [...data.dons_resultados].sort((a: any, b: any) => b.pontuacao - a.pontuacao);
          const top3 = sorted.slice(0, 3).map((item: any) => ({
            nome: item?.dons?.nome ?? "",
            pontuacao: item.pontuacao,
          }));
          setTopDons(top3);
        } else {
          setTopDons([]);
        }
      } catch (err) {
        console.error('Erro ao buscar dom predominante:', err);
        setTopDons([]);
      } finally {
        setLoadingPredominantDon(false);
      }
    };
    fetchPredominantDon();
  }, [selectedMember?.idmembro]);

  const normalizeCep = (v: string) => v.replace(/\D/g, "");
  const toDateInput = (d?: string | null) => (d ? String(d).split('T')[0] : "");
  const emptyToNull = (v: any) => (v === "" || v === undefined ? null : v);

  const handleCepLookup = async () => {
    const rawCep = formData.cep ?? "";
    const cep = normalizeCep(String(rawCep));
    if (!cep || cep.length !== 8) {
      toast({ title: "CEP inválido", description: "Informe 8 dígitos.", variant: "destructive" });
      return;
    }
    try {
      setCepLoading(true);
      const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      if (!res.ok) throw new Error("Falha ao consultar CEP");
      const data = await res.json();
      if (data?.erro) {
        toast({ title: "CEP não encontrado", description: "Verifique o CEP informado.", variant: "destructive" });
        return;
      }

      setFormData((prev) => ({
        ...prev,
        cep,
        endereco: data?.logradouro || prev.endereco || "",
        complemento: data?.complemento || prev.complemento || "",
        bairro: data?.bairro || prev.bairro || "",
        cidade: data?.localidade || prev.cidade || "", // Usar diretamente o nome da cidade
        uf: data?.uf || prev.uf || "",
      }));
      toast({ title: "Endereço preenchido", description: "Dados importados pelo CEP." });
    } catch (err) {
      toast({ title: "Erro na busca de CEP", description: err instanceof Error ? err.message : "Tente novamente", variant: "destructive" });
    } finally {
      setCepLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="h-6 w-6 text-primary" />
            <CardTitle>Perfil do Membro</CardTitle>
          </div>
          {selectedMember && (
            <div className="flex items-center gap-2">
              {!isEditing ? (
                <Button size="sm" variant="outline" onClick={() => { setIsEditing(true); setFormData({ ...selectedMember, sexo: toSexoCode(selectedMember?.sexo), nascimento: toDateInput(selectedMember?.nascimento), credencial: toDateInput(selectedMember?.credencial), data_casamento: toDateInput(selectedMember?.data_casamento) }); }}>
                  Editar Informações
                </Button>
              ) : (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => { setIsEditing(false); setFormData({}); }}
                  >
                    Cancelar
                  </Button>
                  <Button
                    size="sm"
                    className="bg-gradient-primary"
                    onClick={async () => {
                      if (!selectedMember) return;
                      try {
                        // Normaliza campos antes de salvar (envia apenas campos alterados; permite limpar para NULL)
                        const updatePayload: any = {};

                        if ('email' in formData) updatePayload.email = emptyToNull(formData.email);
                        if ('telefone' in formData) updatePayload.telefone = emptyToNull(formData.telefone);
                        if ('nascimento' in formData) updatePayload.nascimento = emptyToNull(formData.nascimento);

                        if ('credencial' in formData) {
                          const cred = formData.credencial && String(formData.credencial).trim() !== '' ? formData.credencial : null;
                          updatePayload.credencial = emptyToNull(cred);
                        }

                        if ('sexo' in formData) {
                          const sexoValue = toSexoCode(formData.sexo);
                          updatePayload.sexo = emptyToNull(sexoValue ?? null);
                        }

                        if ('profissao' in formData) {
                          const profissaoValue = formData.profissao && !String(formData.profissao).startsWith('prof')
                            ? (profissoes.find(p => p.profissao.toLowerCase() === String(formData.profissao).toLowerCase())?.idprofissao ?? formData.profissao)
                            : formData.profissao;
                          updatePayload.profissao = emptyToNull(profissaoValue);
                        }

                        if ('estado_civil' in formData) updatePayload.estado_civil = emptyToNull(formData.estado_civil);

                        if ('data_casamento' in formData) {
                          const casamentoData = formData.data_casamento && String(formData.data_casamento).trim() !== '' ? formData.data_casamento : null;
                          updatePayload.data_casamento = emptyToNull(casamentoData);
                        }

                        if ('cep' in formData) updatePayload.cep = emptyToNull(formData.cep);
                        if ('endereco' in formData) updatePayload.endereco = emptyToNull(formData.endereco);
                        if ('complemento' in formData) updatePayload.complemento = emptyToNull(formData.complemento);
                        if ('bairro' in formData) updatePayload.bairro = emptyToNull(formData.bairro);
                        if ('cidade' in formData) updatePayload.cidade = emptyToNull(formData.cidade);
                        if ('consentimento' in formData && (formData.consentimento === true || formData.consentimento === false || formData.consentimento === null)) {
                          updatePayload.consentimento = formData.consentimento;
                        }

                        if ('uf' in formData) updatePayload.uf = emptyToNull(formData.uf);

                        console.log('💾 Salvando perfil:', updatePayload);

                        const { data: updatedRows, error } = await supabase
                          .from("membros")
                          .update(updatePayload)
                          .eq("idmembro", selectedMember.idmembro)
                          .select('idmembro');
                        
                        if (error) {
                          console.error('❌ Erro ao salvar perfil:', error);
                          throw error;
                        }
                        
                        if (!updatedRows || updatedRows.length === 0) {
                          console.warn('⚠️ Nenhuma linha atualizada - possivelmente sem permissão ou registro não visível pelas políticas RLS.');
                          throw new Error('Não foi possível salvar. Verifique suas permissões de edição do perfil.');
                        }

                        console.log('✅ Perfil salvo com sucesso');

                        const updated: Member = {
                          ...selectedMember,
                          ...updatePayload,
                        };
                        setSelectedMember(updated);
                        setIsEditing(false);
                        toast({ title: "Perfil atualizado", description: "Suas informações foram salvas." });
                      } catch (err) {
                        console.error('❌ Erro completo:', err);
                        toast({ title: "Erro ao salvar", description: err instanceof Error ? err.message : "Tente novamente", variant: "destructive" });
                      }
                    }}
                  >
                    Salvar
                  </Button>
                </>
              )}
            </div>
          )}
        </CardHeader>
        <CardContent>
          {!emailCheckDone ? (
            <div className="text-sm text-muted-foreground">Carregando perfil...</div>
          ) : emailNotFound ? (
            <div className="text-sm text-red-600">Nenhum membro com o e-mail {user.email}</div>
          ) : !selectedMember ? (
            <div className="text-sm text-muted-foreground mt-6">Nenhum membro selecionado.</div>
          ) : (
            <div className="space-y-6 mt-6">
              <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg">
                <div className="w-20 h-20 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden">
                  {(() => {
                    const imageUrl = getImageUrl(selectedMember.foto);
                    return imageUrl ? (
                      <img
                        src={imageUrl}
                        alt={selectedMember.nome}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          console.warn("Erro ao carregar imagem:", imageUrl);
                          (e.currentTarget as HTMLImageElement).src = "/placeholder.svg";
                        }}
                      />
                    ) : (
                      <User className="w-10 h-10 text-muted-foreground" />
                    );
                  })()}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{selectedMember.nome}</h3>
                  {selectedMember.apelido && (
                    <p className="text-muted-foreground">"{selectedMember.apelido}"</p>
                  )}
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={selectedMember.status === "Ativo" ? "default" : "secondary"}>
                      {selectedMember.status}
                    </Badge>
                    {selectedMember.tipo_membro && (
                      <Badge variant="outline">{selectedMember.tipo_membro}</Badge>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Informações Pessoais</h4>
                  {!isEditing ? (
                    <>
                      {selectedMember.email && (
                        <div className="flex items-center gap-3">
                          <Mail className="w-4 h-4 text-muted-foreground" />
                          <span>{selectedMember.email}</span>
                        </div>
                      )}
                      {selectedMember.telefone && (
                        <div className="flex items-center gap-3">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span>{formatPhone(selectedMember.telefone)}</span>
                        </div>
                      )}
                      {selectedMember.nascimento && (
                        <div className="flex items-center gap-3">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>
                            {formatDate(selectedMember.nascimento)} ({calculateAge(selectedMember.nascimento)})
                          </span>
                        </div>
                      )}
                    {selectedMember.sexo && (
                      <div className="flex items-center gap-3">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span>{sexoLabel(selectedMember.sexo)}</span>
                      </div>
                    )}
                    {selectedMember.profissao && (
                      <div className="flex items-center gap-3">
                        <Building className="w-4 h-4 text-muted-foreground" />
                        <span>{getProfissaoNome(selectedMember.profissao)}</span>
                      </div>
                    )}
                    {selectedMember.estado_civil && (
                      <div className="flex items-center gap-3">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span>{selectedMember.estado_civil}</span>
                      </div>
                    )}
                    {selectedMember.data_casamento && (
                      <div className="flex items-center gap-3">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span>{formatDate(selectedMember.data_casamento)}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-3">
                      <Shield className={`w-4 h-4 ${getCredencialStatus(selectedMember.credencial).icone}`} />
                      <span className={getCredencialStatus(selectedMember.credencial).cor}>
                        {selectedMember.credencial && selectedMember.credencial.trim() !== "" 
                          ? `${getCredencialStatus(selectedMember.credencial).texto} - ${formatDate(selectedMember.credencial)}`
                          : getCredencialStatus(selectedMember.credencial).texto
                        }
                      </span>
                    </div>
                    
                    {/* Campo de Consentimento LGPD - Visualização */}
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-muted-foreground" />
                      <div className="flex items-center gap-2">
                        <span className={
                          selectedMember.consentimento === true ? "text-green-600 font-medium" :
                          selectedMember.consentimento === false ? "text-red-600 font-medium" :
                          "text-gray-500 font-medium"
                        }>
                          {selectedMember.consentimento === true ? "✓ Consentimento LGPD concedido" :
                           selectedMember.consentimento === false ? "✗ Consentimento LGPD negado" :
                           "⚪ Consentimento LGPD não informado"}
                        </span>
                        <PoliticaPrivacidadeModal>
                          <Button variant="link" size="sm" className="h-auto p-0 text-primary underline">
                            📜 Ver Política
                          </Button>
                        </PoliticaPrivacidadeModal>
                      </div>
                    </div>
                    </>
                  ) : (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <Label htmlFor="email">E-mail</Label>
                        <Input id="email" value={formData.email ?? ""} onChange={(e) => setFormData({ ...formData, email: e.target.value })} placeholder="seu@email.com" />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="telefone">Telefone</Label>
                        <Input id="telefone" value={formData.telefone ?? ""} onChange={(e) => setFormData({ ...formData, telefone: e.target.value })} placeholder="(xx) xxxxx-xxxx" />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="nascimento">Nascimento</Label>
                        <div className="flex gap-2">
                          <Input id="nascimento" type="date" value={formData.nascimento ?? ""} onChange={(e) => setFormData({ ...formData, nascimento: e.target.value })} />
                          {formData.nascimento && (
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="icon"
                              onClick={() => setFormData({ ...formData, nascimento: "" })}
                            >
                              ✕
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="credencial">Credencial</Label>
                        <div className="flex gap-2">
                          <Input
                            id="credencial"
                            type="date"
                            value={formData.credencial || ""}
                            onChange={(e) => {
                              const value = e.target.value;
                              if (!value || /^\d{4}-\d{2}-\d{2}$/.test(value)) {
                                setFormData({ ...formData, credencial: value });
                              } else {
                                toast({
                                  title: "Formato de data inválido",
                                  description: "Use o formato AAAA-MM-DD",
                                  variant: "destructive",
                                });
                              }
                            }}
                          />
                          {formData.credencial && (
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="icon"
                              onClick={() => setFormData({ ...formData, credencial: "" })}
                            >
                              ✕
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="sexo">Sexo</Label>
                        <Select value={formData.sexo || undefined} onValueChange={(v) => setFormData({ ...formData, sexo: v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="M">Masculino</SelectItem>
                            <SelectItem value="F">Feminino</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="profissao">Profissão</Label>
                        <Select value={formData.profissao || undefined} onValueChange={(v) => setFormData({ ...formData, profissao: v })}>
                          <SelectTrigger>
                            <SelectValue placeholder={loadingProfissoes ? "Carregando profissões..." : "Selecione a profissão"} />
                          </SelectTrigger>
                          <SelectContent>
                            {profissoes.map((p) => (
                              <SelectItem key={p.idprofissao} value={p.idprofissao}>{p.profissao}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="estado_civil">Estado Civil</Label>
                        <Select value={formData.estado_civil || undefined} onValueChange={(v) => setFormData({ ...formData, estado_civil: v })}>
                          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Solteiro(a)">Solteiro(a)</SelectItem>
                            <SelectItem value="Casado(a)">Casado(a)</SelectItem>
                            <SelectItem value="Divorciado(a)">Divorciado(a)</SelectItem>
                            <SelectItem value="Viúvo(a)">Viúvo(a)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="data_casamento">Data do Casamento</Label>
                        <div className="flex gap-2">
                          <Input
                            id="data_casamento"
                            type="date"
                            value={formData.data_casamento || ""}
                            onChange={(e) => {
                            const value = e.target.value;
                            if (!value || /^\d{4}-\d{2}-\d{2}$/.test(value)) {
                              setFormData({ ...formData, data_casamento: value });
                            } else {
                              toast({
                                title: "Formato de data inválido",
                                description: "Use o formato AAAA-MM-DD",
                                variant: "destructive",
                              });
                            }
                          }}
                          disabled={formData.estado_civil !== "Casado(a)"}
                        />
                        {formData.data_casamento && (
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="icon"
                            onClick={() => setFormData({ ...formData, data_casamento: "" })}
                            disabled={formData.estado_civil !== "Casado(a)"}
                          >
                            ✕
                          </Button>
                        )}
                        </div>
                      </div>

                      {/* Campo de Consentimento LGPD */}
                      <div className="space-y-3 p-4 border rounded-lg bg-muted/20">
                        <div className="space-y-3">
                          <Label className="text-sm font-medium">
                            Consentimento LGPD - Li e concordo com a Política de Privacidade e autorizo o uso dos meus dados e imagem conforme a Lei nº 13.709/2018 (LGPD):
                          </Label>
                          <div className="flex gap-4">
                            <div className="flex items-center space-x-2">
                              <input
                                type="radio"
                                id="consentimento-sim"
                                name="consentimento"
                                checked={formData.consentimento === true}
                                onChange={() => setFormData({ ...formData, consentimento: true })}
                                className="h-4 w-4"
                              />
                              <Label htmlFor="consentimento-sim" className="text-sm text-green-600 font-medium">
                                ✓ Sim, concordo
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input
                                type="radio"
                                id="consentimento-nao"
                                name="consentimento"
                                checked={formData.consentimento === false}
                                onChange={() => setFormData({ ...formData, consentimento: false })}
                                className="h-4 w-4"
                              />
                              <Label htmlFor="consentimento-nao" className="text-sm text-red-600 font-medium">
                                ✗ Não concordo
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input
                                type="radio"
                                id="consentimento-null"
                                name="consentimento"
                                checked={formData.consentimento === null}
                                onChange={() => setFormData({ ...formData, consentimento: null })}
                                className="h-4 w-4"
                              />
                              <Label htmlFor="consentimento-null" className="text-sm text-gray-500 font-medium">
                                ⚪ Não informado
                              </Label>
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-start">
                          <PoliticaPrivacidadeModal>
                            <Button variant="link" size="sm" className="h-auto p-0 text-primary underline">
                              <FileText className="h-4 w-4 mr-1" />
                              📜 Ler Política de Privacidade completa
                            </Button>
                          </PoliticaPrivacidadeModal>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-lg border-b pb-2">Endereço</h4>
                  {!isEditing ? (
                    (selectedMember.endereco || selectedMember.bairro || selectedMember.cidade || selectedMember.uf) && (
                      <div className="bg-muted/30 p-4 rounded-lg space-y-2">
                        {selectedMember.cep && <p><strong>CEP:</strong> {selectedMember.cep}</p>}
                        {selectedMember.endereco && <p><strong>Endereço:</strong> {selectedMember.endereco}</p>}
                        {selectedMember.complemento && <p><strong>Complemento:</strong> {selectedMember.complemento}</p>}
                        {selectedMember.bairro && <p><strong>Bairro:</strong> {selectedMember.bairro}</p>}
                        <div className="flex gap-4">
                          {selectedMember.cidade && <p><strong>Cidade:</strong> {selectedMember.cidade}</p>}
                          {selectedMember.uf && <p><strong>UF:</strong> {selectedMember.uf}</p>}
                        </div>
                        {(selectedMember.endereco || selectedMember.bairro || selectedMember.cidade || selectedMember.uf) && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-3 gap-2"
                            onClick={() => {
                              const endereco = `${selectedMember.endereco || ""}, ${selectedMember.bairro || ""}, ${selectedMember.cidade || ""}, ${selectedMember.uf || ""}`
                                .replace(/,\s*,/g, ",")
                                .replace(/^,\s*|,\s*$/g, "");
                              window.open(`https://www.google.com/maps/search/${encodeURIComponent(endereco)}`, "_blank");
                            }}
                          >
                            <MapPin className="w-4 h-4" />
                            Ver no Google Maps
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    )
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1 sm:col-span-2">
                        <Label htmlFor="cep">CEP</Label>
                        <div className="flex gap-2">
                          <Input
                            id="cep"
                            value={formData.cep ?? ""}
                            onChange={(e) => setFormData({ ...formData, cep: normalizeCep(e.target.value) })}
                            onBlur={() => {
                              const cep = normalizeCep(String(formData.cep ?? ""));
                              if (cep.length === 8) handleCepLookup();
                            }}
                            placeholder="Somente números"
                            disabled={cepLoading}
                            className="w-full"
                          />
                          <Button type="button" variant="outline" onClick={handleCepLookup} disabled={cepLoading} className="shrink-0">
                            {cepLoading ? "Buscando..." : "Buscar CEP"}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <Label htmlFor="endereco">Endereço</Label>
                        <Input id="endereco" value={formData.endereco ?? ""} onChange={(e) => setFormData({ ...formData, endereco: e.target.value })} />
                      </div>
                      <div className="space-y-1 sm:col-span-2">
                        <Label htmlFor="complemento">Complemento</Label>
                        <Input id="complemento" value={formData.complemento ?? ""} onChange={(e) => setFormData({ ...formData, complemento: e.target.value })} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="bairro">Bairro</Label>
                        <Input id="bairro" value={formData.bairro ?? ""} onChange={(e) => setFormData({ ...formData, bairro: e.target.value })} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="cidade">Cidade</Label>
                        <Input id="cidade" value={formData.cidade ?? ""} onChange={(e) => setFormData({ ...formData, cidade: e.target.value })} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="uf">UF</Label>
                        <Input id="uf" value={formData.uf ?? ""} onChange={(e) => setFormData({ ...formData, uf: e.target.value })} placeholder="SP, RJ, MG..." />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <PendenciasCadastro member={selectedMember} />

              <LiderancaInfo membroId={selectedMember.idmembro} />

              {/* QR Code do Membro */}
              <Card className="mt-4">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <QrCode className="h-6 w-6 text-primary" />
                    <CardTitle>QR Code do Membro</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6 flex-wrap">
                    <div className="p-3 bg-muted/30 rounded-lg">
                      <QRCodeSVG
                        id={`qr-${selectedMember.idmembro}`}
                        value={selectedMember.idmembro}
                        size={160}
                        includeMargin
                        level="M"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const el = document.querySelector<SVGSVGElement>(`#qr-${selectedMember.idmembro}`);
                            if (!el) return;
                            const serializer = new XMLSerializer();
                            const source = serializer.serializeToString(el);
                            const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement("a");
                            a.href = url;
                            a.download = `qr-${selectedMember.idmembro}.svg`;
                            a.click();
                            URL.revokeObjectURL(url);
                          }}
                        >
                          Baixar SVG
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Dom Predominante */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Award className="h-6 w-6 text-primary" />
                    <CardTitle>Dons Predominantes (Top 3)</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  {!loadingPredominantDon ? (
                    topDons.length > 0 ? (
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <div className="space-y-3">
                          {topDons.map((don, idx) => (
                            <div key={idx} className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">{idx + 1}º</span>
                                <span className="text-sm font-semibold">{don.nome}</span>
                              </div>
                              <div className="text-sm font-semibold">{don.pontuacao}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="text-sm text-muted-foreground">Nenhuma avaliação concluída encontrada.</div>
                    )
                  ) : (
                    <div className="text-sm text-muted-foreground">Carregando dons predominantes...</div>
                  )}
                </CardContent>
              </Card>

              <div className="mt-6">
                <FamilyRelationships membroId={selectedMember.idmembro} membroNome={selectedMember.nome} allowAdd={false} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}