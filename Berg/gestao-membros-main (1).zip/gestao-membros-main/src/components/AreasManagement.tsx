// src/pages/AreasManagement.tsx
import { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, MapPin, Building, Search, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAreas, type Area } from "@/hooks/useAreas";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export default function AreasManagement() {
  const {
    areas,
    departamentos,
    loading,
    createArea,
    updateArea,
    deleteArea,
  } = useAreas();

  const { userProfile } = useAuth();
  const [visibleAreaIds, setVisibleAreaIds] = useState<string[] | null>(null);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [formData, setFormData] = useState({ nome: "", descricao: "", iddepto: "", lider1: "", lider2: "" });
  const [searchTerm, setSearchTerm] = useState("");

  // Membros disponíveis para seleção quando o departamento for Capelania
  const [availableMembers, setAvailableMembers] = useState<Array<{ idmembro: string; nome: string; apelido?: string }>>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);

  // Mapa de membros por id para exibir nomes nas listagens
  const [membersMap, setMembersMap] = useState<Record<string, { idmembro: string; nome: string; apelido?: string }>>({});

  const resetForm = () => {
    setEditingArea(null);
    setFormData({ nome: "", descricao: "", iddepto: "", lider1: "", lider2: "" });
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (area: Area) => {
    setEditingArea(area);
    setFormData({
      nome: area.nome,
      descricao: area.descricao || "",
      iddepto: area.iddepto,
      lider1: (area as any).lider1 || "",
      lider2: (area as any).lider2 || "",
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    if (!formData.nome.trim()) {
      toast({ title: "Nome obrigatório", description: "Informe o nome da área.", variant: "destructive" });
      return;
    }
    if (!formData.iddepto) {
      toast({ title: "Departamento obrigatório", description: "Selecione um departamento válido.", variant: "destructive" });
      return;
    }

    // Validação: Capelania exige apenas Líder Principal; Secundário é opcional
    const isCapelania = isCapelaniaDept(formData.iddepto);
    if (isCapelania) {
      if (!formData.lider1) {
        toast({ title: "Líder Principal obrigatório", description: "Na Capelania, selecione o Líder Principal.", variant: "destructive" });
        return;
      }
      if (formData.lider2 && formData.lider1 === formData.lider2) {
        toast({ title: "Líderes devem ser distintos", description: "Se escolher Secundário, precisa ser diferente do Principal.", variant: "destructive" });
        return;
      }
    }

    setSubmitting(true);
    const result = editingArea
      ? await updateArea(editingArea.idarea, formData.nome, formData.descricao, formData.iddepto, formData.lider1 || null, formData.lider2 || null)
      : await createArea(formData.nome, formData.descricao, formData.iddepto, formData.lider1 || null, formData.lider2 || null);
    setSubmitting(false);

    if (result.success) {
      setIsDialogOpen(false);
      resetForm();
    }
  };

  const handleDelete = async (area: Area) => {
    await deleteArea(area.idarea, area.nome);
  };

  // Helper para identificar Capelania por nome do departamento
  const isCapelaniaDept = (iddepto: string) => {
    const dept = departamentos.find((d) => d.iddepto === iddepto);
    if (!dept?.nome) return false;
    return dept.nome.trim().toLowerCase() === "capelania";
  };

  // Ordenar alfabeticamente por apelido (se existir) ou nome
  const sortByDisplayName = (
    a: { idmembro: string; nome: string; apelido?: string },
    b: { idmembro: string; nome: string; apelido?: string }
  ) => {
    const an = (a.apelido || a.nome || "").toLowerCase();
    const bn = (b.apelido || b.nome || "").toLowerCase();
    return an.localeCompare(bn);
  };

  // Carregar membros do departamento selecionado quando for Capelania
  useEffect(() => {
    const loadMembers = async () => {
      if (!formData.iddepto || !isCapelaniaDept(formData.iddepto)) {
        setAvailableMembers([]);
        return;
      }
      setLoadingMembers(true);
      try {
        if (editingArea) {
          // Em edição: listar apenas líderes vinculados à área
          const { data, error } = await supabase
            .from("lideres")
            .select("idmembro, status, membros:idmembro(idmembro,nome,apelido)")
            .eq("idarea", editingArea.idarea)
            .eq("status", "Ativo");
          if (error) throw error;
          const list = (data || []).map((l: any) => ({ idmembro: String(l.idmembro), nome: String(l.membros?.nome || ""), apelido: l.membros?.apelido ? String(l.membros.apelido) : undefined }));
          const unique = Array.from(new Map(list.map(m => [m.idmembro, m])).values());
          unique.sort(sortByDisplayName);
          setAvailableMembers(unique);
        } else {
          // Em criação: listar membros ativos do departamento
          const { data, error } = await supabase
            .from("membros")
            .select("idmembro, nome, apelido, status, iddepto")
            .eq("iddepto", formData.iddepto)
            .eq("status", "Ativo")
            .order("nome");
          if (error) throw error;
          const mapped = (data || []).map((m: any) => ({ idmembro: String(m.idmembro), nome: String(m.nome || ""), apelido: m.apelido ? String(m.apelido) : undefined }));
          mapped.sort(sortByDisplayName);
          setAvailableMembers(mapped);
        }
      } catch (error) {
        console.error("[AreasManagement] Erro ao carregar lista de líderes/membros:", error);
        setAvailableMembers([]);
      } finally {
        setLoadingMembers(false);
      }
    };
    loadMembers();
  }, [formData.iddepto, departamentos, editingArea]);

  // (movido) Carregar nomes dos líderes para exibição nas listagens será definido após baseAreas

  // --- Busca ---
  const normalize = (s?: string) => {
    if (!s) return "";
    try {
      return s.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
    } catch {
      return s
        .toLowerCase()
        .replace(/[áàãâä]/g, "a").replace(/[éèêë]/g, "e")
        .replace(/[íìîï]/g, "i").replace(/[óòõôö]/g, "o")
        .replace(/[úùûü]/g, "u").replace(/[ç]/g, "c");
    }
  };

  // Áreas visíveis para o usuário (monitores veem apenas áreas que lideram)
  useEffect(() => {
    const loadAreasLedByUser = async () => {
      if (userProfile?.permission === "MTR") {
        const memberId = (userProfile as any).idmembro;
        if (!memberId) {
          setVisibleAreaIds([]);
          return;
        }
        const { data, error } = await supabase
          .from("lideres")
          .select("idarea,status")
          .eq("idmembro", memberId)
          .eq("status", "Ativo");
        if (error) {
          console.error("[AreasManagement] Erro ao buscar áreas do monitor:", error);
          setVisibleAreaIds([]);
          return;
        }
        const ids = (data || [])
          .map((l: any) => l.idarea)
          .filter((id: string | null) => Boolean(id)) as string[];
        setVisibleAreaIds(Array.from(new Set(ids)));
      } else {
        setVisibleAreaIds(null);
      }
    };
    loadAreasLedByUser();
  }, [userProfile]);

  const baseAreas = useMemo(() => {
    if (Array.isArray(visibleAreaIds)) {
      return areas.filter((a) => visibleAreaIds.includes(a.idarea));
    }
    return areas;
  }, [areas, visibleAreaIds]);

  // Carregar nomes dos líderes para exibição nas listagens (agora após baseAreas)
  useEffect(() => {
    const ids = Array.from(new Set(
      baseAreas.flatMap((a) => [ (a as any).lider1, (a as any).lider2 ].filter(Boolean))
    ));
    if (ids.length === 0) {
      setMembersMap({});
      return;
    }
    (async () => {
      const { data, error } = await supabase
        .from("membros")
        .select("idmembro, nome, apelido")
        .in("idmembro", ids as string[]);
      if (error) {
        console.error("[AreasManagement] Erro ao carregar nomes dos líderes:", error);
        return;
      }
      const map: Record<string, { idmembro: string; nome: string; apelido?: string }> = {};
      (data || []).forEach((m: any) => { map[m.idmembro] = { idmembro: m.idmembro, nome: m.nome, apelido: m.apelido }; });
      setMembersMap(map);
    })();
  }, [baseAreas]);

  const filteredAreas = useMemo(() => {
    const q = normalize(searchTerm);
    if (!q) return baseAreas;
    return baseAreas.filter((a) => {
      const nome = normalize(a.nome);
      const desc = normalize(a.descricao || "");
      const dep = normalize((a as any).nome_departamento || "");
      return nome.includes(q) || desc.includes(q) || dep.includes(q);
    });
  }, [baseAreas, searchTerm]);

  // Agrupar áreas por departamento
  const areasByDepartamento = useMemo(() => {
    const grouped = filteredAreas.reduce((acc, area) => {
      const deptoId = area.iddepto;
      if (!acc[deptoId]) {
        acc[deptoId] = {
          departamento: departamentos.find(d => d.iddepto === deptoId),
          areas: []
        };
      }
      acc[deptoId].areas.push(area);
      return acc;
    }, {} as Record<string, { departamento?: any; areas: Area[] }>);
    
    // Ordenar áreas dentro de cada departamento alfabeticamente
    Object.values(grouped).forEach(group => {
      group.areas.sort((a, b) => a.nome.localeCompare(b.nome));
    });
    
    return Object.values(grouped)
      .filter(group => group.departamento)
      .sort((a, b) => a.departamento.nome.localeCompare(b.departamento.nome));
  }, [filteredAreas, departamentos]);

  return (
    <div className="space-y-6">
      {/* Cabeçalho + Ações */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <MapPin className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">Gerenciar Áreas</h2>
        </div>

        {/* Barra de busca */}
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Buscar área por nome, descrição ou departamento..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-10"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {userProfile?.permission !== "MTR" && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={openCreateDialog} className="bg-primary">
                  <Plus className="w-4 h-4 mr-2" />
                  Nova Área
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingArea ? "Editar Área" : "Nova Área"}</DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome da Área *</Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                      placeholder="Ex.: Hospital São Silvestre - Terça"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="iddepto">Departamento *</Label>
                    <Select
                      value={formData.iddepto}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, iddepto: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue
                          placeholder={
                            departamentos.length === 0 ? "Nenhum departamento encontrado" : "Selecione o departamento"
                          }
                        />
                      </SelectTrigger>
                      <SelectContent>
                        {departamentos.map((dept) => (
                          <SelectItem key={dept.iddepto} value={dept.iddepto}>
                            {dept.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {departamentos.length === 0 && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Cadastre departamentos antes de criar áreas.
                      </p>
                    )}
                    {formData.iddepto && isCapelaniaDept(formData.iddepto) && (
                      <div className="mt-3 space-y-3">
                        <p className="text-xs text-muted-foreground">
                          Capelania: Líder Principal é obrigatório; Secundário é opcional.
                          {editingArea && " (somente líderes já vinculados à área)"}
                        </p>
                        <div>
                          <Label htmlFor="lider1">Líder Principal *</Label>
                          <Select
                            value={formData.lider1}
                            onValueChange={(value) => setFormData((prev) => ({ ...prev, lider1: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder={loadingMembers ? "Carregando membros..." : "Selecione o Líder Principal"} />
                            </SelectTrigger>
                            <SelectContent>
                              {availableMembers.map((m) => (
                                <SelectItem key={m.idmembro} value={m.idmembro}>
                                  {m.nome}{m.apelido ? ` (${m.apelido})` : ""}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="lider2">Líder Secundário (opcional)</Label>
                          <Select
                            value={formData.lider2}
                            onValueChange={(value) => setFormData((prev) => ({ ...prev, lider2: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder={loadingMembers ? "Carregando membros..." : "Selecione o Líder Secundário"} />
                            </SelectTrigger>
                            <SelectContent>
                              {availableMembers.map((m) => (
                                <SelectItem key={m.idmembro} value={m.idmembro}>
                                  {m.nome}{m.apelido ? ` (${m.apelido})` : ""}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="descricao">Descrição</Label>
                    <Textarea
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData((prev) => ({ ...prev, descricao: e.target.value }))}
                      placeholder="Descreva as atividades e objetivos desta área"
                      rows={3}
                    />
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button
                      type="submit"
                      disabled={submitting || !formData.nome.trim() || !formData.iddepto || departamentos.length === 0}
                    >
                      {submitting ? "Salvando..." : editingArea ? "Atualizar" : "Criar"}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {/* Departamentos com suas Áreas */}
      <div className="grid gap-6">
        {loading ? (
          <div className="text-center py-8">Carregando...</div>
        ) : areasByDepartamento.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                {filteredAreas.length === 0 ? "Nenhuma área encontrada" : "Nenhum departamento com áreas encontrado"}
              </p>
            </CardContent>
          </Card>
        ) : (
          areasByDepartamento.map((group) => (
            <Card key={group.departamento.iddepto} className="bg-gradient-card border-border/50">
              <CardContent className="p-6">
                {/* Cabeçalho do Departamento */}
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border/50">
                  <Building className="h-6 w-6 text-primary" />
                  <h3 className="text-xl font-bold text-primary">{group.departamento.nome}</h3>
                  <span className="text-sm text-muted-foreground ml-auto">
                    {group.areas.length} {group.areas.length === 1 ? 'área' : 'áreas'}
                  </span>
                </div>

                {/* Áreas do Departamento */}
                <div className="grid gap-4">
                  {group.areas.map((area) => (
                    <Card key={area.idarea} className="bg-background/50 border-border/30 hover:bg-background/70 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <MapPin className="h-4 w-4 text-muted-foreground" />
                              <h4 className="font-semibold text-base break-words">{area.nome}</h4>
                            </div>
                            {area.descricao && (
                              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                                {area.descricao}
                              </p>
                            )}
                          </div>

                          {userProfile?.permission !== "MTR" && (
                            <div className="flex gap-2 shrink-0">
                              <Button size="sm" variant="outline" onClick={() => openEditDialog(area)} title="Editar">
                                <Edit className="w-4 h-4" />
                              </Button>

                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive" title="Desativar">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Confirmar desativação</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja desativar a área <strong>"{area.nome}"</strong>? Você pode reativá-la depois.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(area)}>Desativar</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      )}
                    </div>

                    {/* Exibição de líderes da área (se houver) */}
                    {((area as any).lider1 || (area as any).lider2) && (
                      <div className="mt-2 space-y-1">
                        {(area as any).lider1 && (
                          <p className="text-sm text-muted-foreground">
                            Líder Principal: <span className="font-medium text-foreground">
                              {membersMap[(area as any).lider1]?.apelido || membersMap[(area as any).lider1]?.nome || (area as any).lider1}
                            </span>
                          </p>
                        )}
                        {(area as any).lider2 && (
                          <p className="text-sm text-muted-foreground">
                            Líder Secundário: <span className="font-medium text-foreground">
                              {membersMap[(area as any).lider2]?.apelido || membersMap[(area as any).lider2]?.nome || (area as any).lider2}
                            </span>
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
