import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText } from "lucide-react";

interface Props {
  children: React.ReactNode;
}

export default function PoliticaPrivacidadeModal({ children }: Props) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Política de Privacidade – Igreja Apostólica e Profética Águas Purificadoras
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[60vh] pr-4">
          <div className="space-y-6 text-sm">
            <section>
              <h3 className="font-semibold text-lg mb-2">1️⃣ Introdução</h3>
              <p className="text-muted-foreground leading-relaxed">
                A Igreja Apostólica e Profética Águas Purificadoras valoriza a privacidade e a segurança das informações pessoais de seus membros, líderes, voluntários e visitantes.
                Esta Política de Privacidade explica como os dados coletados neste aplicativo são tratados, armazenados e utilizados, em conformidade com a Lei nº 13.709/2018 – Lei Geral de Proteção de Dados Pessoais (LGPD).
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">2️⃣ Dados Coletados</h3>
              <p className="text-muted-foreground mb-2">O aplicativo pode coletar os seguintes tipos de dados pessoais:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Nome completo</li>
                <li>CPF ou RG</li>
                <li>Data de nascimento</li>
                <li>Endereço, telefone e e-mail</li>
                <li>Foto (imagem de perfil ou credencial)</li>
                <li>Dados de participação em departamentos, eventos e escalas</li>
                <li>Outras informações fornecidas voluntariamente no cadastro</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">3️⃣ Finalidade do Tratamento dos Dados</h3>
              <p className="text-muted-foreground mb-2">Os dados são utilizados exclusivamente para fins ministeriais, administrativos e de comunicação interna, incluindo:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Organização e gestão de departamentos e ministérios;</li>
                <li>Emissão de credenciais digitais e carteirinhas;</li>
                <li>Registro de presença em eventos e atividades;</li>
                <li>Comunicação entre líderes e membros;</li>
                <li>Envio de mensagens institucionais e informativos;</li>
                <li>Controle de acesso e segurança nas atividades da igreja.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">4️⃣ Uso de Imagem (Fotos)</h3>
              <p className="text-muted-foreground mb-2">As fotos e imagens pessoais fornecidas no aplicativo têm as seguintes finalidades:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Identificar o membro, líder ou voluntário dentro do sistema;</li>
                <li>Exibir a foto em credenciais digitais e perfis internos;</li>
                <li>Compor registros administrativos e relatórios da igreja;</li>
                <li>Ser eventualmente utilizadas em publicações oficiais da igreja, incluindo redes sociais, site ou materiais de divulgação, somente em contextos relacionados a cultos, eventos, ações sociais ou atividades ministeriais da Igreja Apostólica e Profética Águas Purificadoras.</li>
              </ul>
              <div className="mt-3 space-y-2 text-muted-foreground">
                <p>• Nenhuma foto será usada para fins comerciais ou fora do contexto eclesiástico.</p>
                <p>• Ao cadastrar-se e consentir com esta política, o usuário autoriza o uso da sua imagem conforme descrito acima.</p>
                <p>• O titular pode, a qualquer momento, revogar a autorização para o uso da imagem, solicitando formalmente à administração da igreja.</p>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">5️⃣ Compartilhamento de Dados</h3>
              <p className="text-muted-foreground mb-2">Os dados não são compartilhados com terceiros, salvo quando houver:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Obrigação legal ou ordem judicial;</li>
                <li>Consentimento explícito do titular;</li>
                <li>Necessidade de integração com sistemas internos da própria igreja.</li>
              </ul>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">6️⃣ Armazenamento e Segurança</h3>
              <div className="space-y-2 text-muted-foreground">
                <p>• Os dados são armazenados de forma segura e protegida, utilizando servidores com padrões de segurança e criptografia adequados.</p>
                <p>• O acesso aos dados é restrito a pessoas autorizadas, exclusivamente para o cumprimento das finalidades descritas nesta política.</p>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">7️⃣ Direitos do Titular dos Dados</h3>
              <p className="text-muted-foreground mb-2">De acordo com a LGPD, o titular tem direito a:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground ml-4">
                <li>Acessar seus dados pessoais;</li>
                <li>Corrigir dados incorretos ou desatualizados;</li>
                <li>Solicitar a exclusão de seus dados pessoais;</li>
                <li>Revogar o consentimento para o tratamento de dados;</li>
                <li>Solicitar informações sobre o uso e o compartilhamento dos seus dados.</li>
              </ul>
              <p className="text-muted-foreground mt-2">Essas solicitações podem ser feitas diretamente à administração da igreja.</p>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">8️⃣ Responsável pelo Tratamento de Dados</h3>
              <p className="text-muted-foreground mb-2">
                O controlador dos dados pessoais é a Igreja Apostólica e Profética Águas Purificadoras, responsável por garantir a conformidade com a LGPD e atender às solicitações dos titulares.
              </p>
              <div className="bg-muted p-3 rounded-lg">
                <p className="font-medium">📩 Contato:</p>
                <p className="text-muted-foreground">E-mail: sistemapapai@aguaspurificadoras.com.br</p>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">9️⃣ Consentimento</h3>
              <div className="space-y-2 text-muted-foreground">
                <p>• Ao utilizar este aplicativo, o usuário declara ter lido e concordado com esta Política de Privacidade e autoriza o tratamento de seus dados pessoais e uso de imagem (foto) para as finalidades aqui descritas.</p>
                <p>• O consentimento poderá ser revogado a qualquer momento, mediante solicitação formal.</p>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-lg mb-2">🔒 Última Atualização</h3>
              <div className="space-y-2 text-muted-foreground">
                <p>Esta Política foi atualizada em 17 de outubro de 2025.</p>
                <p>A Igreja Apostólica e Profética Águas Purificadoras reserva-se o direito de atualizar este documento sempre que necessário, para mantê-lo em conformidade com a legislação vigente.</p>
              </div>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}