import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Users, CheckCircle, AlertTriangle, RefreshCw } from "lucide-react";

interface RelacionamentoIncompleto {
  idmembro: string;
  nome: string;
  conjuge_id: string;
  nome_conjuge: string;
  conjuge_tem_reciproco: boolean;
}

export const CorrecaoConjuges: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [analisando, setAnalisando] = useState(false);
  const [relacionamentosIncompletos, setRelacionamentosIncompletos] = useState<RelacionamentoIncompleto[]>([]);
  const [corrigidasCount, setCorrigidasCount] = useState(0);
  const { toast } = useToast();

  const analisarRelacionamentos = async () => {
    setAnalisando(true);
    try {
      // Buscar todos os relacionamentos de cônjuge na tabela relacionamentos_familiares
      const { data: relacionamentosConjuge, error } = await supabase
        .from("relacionamentos_familiares")
        .select(`
          id,
          membro_id,
          parente_id,
          tipo_relacionamento
        `)
        .eq("tipo_relacionamento", "conjuge");

      if (error) {
        throw error;
      }

      if (!relacionamentosConjuge || relacionamentosConjuge.length === 0) {
        toast({
          title: "Análise concluída",
          description: "Não foram encontrados relacionamentos de cônjuge cadastrados.",
        });
        setRelacionamentosIncompletos([]);
        return;
      }

      // Buscar informações dos membros
      const membrosIds = Array.from(new Set([
        ...relacionamentosConjuge.map(r => r.membro_id),
        ...relacionamentosConjuge.map(r => r.parente_id)
      ]));

      const { data: membros, error: membrosError } = await supabase
        .from("membros")
        .select("idmembro, nome")
        .in("idmembro", membrosIds);

      if (membrosError) {
        throw membrosError;
      }

      // Criar um mapa para facilitar a busca de nomes
      const membrosMap = new Map(membros?.map(m => [m.idmembro, m.nome]) || []);

      // Verificar quais relacionamentos estão incompletos (sem reciprocidade)
      const incompletos: RelacionamentoIncompleto[] = [];

      for (const relacionamento of relacionamentosConjuge) {
        // Verificar se existe o relacionamento recíproco
        const reciprocoExiste = relacionamentosConjuge.some(r => 
          r.membro_id === relacionamento.parente_id && 
          r.parente_id === relacionamento.membro_id &&
          r.tipo_relacionamento === "conjuge"
        );

        if (!reciprocoExiste) {
          incompletos.push({
            idmembro: relacionamento.membro_id,
            nome: membrosMap.get(relacionamento.membro_id) || "Nome não encontrado",
            conjuge_id: relacionamento.parente_id,
            nome_conjuge: membrosMap.get(relacionamento.parente_id) || "Nome não encontrado",
            conjuge_tem_reciproco: false
          });
        }
      }

      setRelacionamentosIncompletos(incompletos);
      
      toast({
        title: "Análise concluída",
        description: `Encontrados ${incompletos.length} relacionamentos incompletos.`,
        variant: incompletos.length > 0 ? "destructive" : "default"
      });

    } catch (error) {
      console.error("Erro ao analisar relacionamentos:", error);
      toast({
        title: "Erro",
        description: "Erro ao analisar relacionamentos de cônjuges.",
        variant: "destructive",
      });
    } finally {
      setAnalisando(false);
    }
  };

  const corrigirRelacionamentos = async () => {
    if (relacionamentosIncompletos.length === 0) {
      toast({
        title: "Nada para corrigir",
        description: "Não há relacionamentos incompletos para corrigir.",
      });
      return;
    }

    setLoading(true);
    setCorrigidasCount(0);
    let corrigidas = 0;

    try {
      for (const relacionamento of relacionamentosIncompletos) {
        // Criar o relacionamento recíproco na tabela relacionamentos_familiares
        const { error } = await supabase
          .from("relacionamentos_familiares")
          .insert({
            membro_id: relacionamento.conjuge_id,
            parente_id: relacionamento.idmembro,
            tipo_relacionamento: "conjuge"
          });

        if (error) {
          console.error(`Erro ao corrigir relacionamento para ${relacionamento.nome_conjuge}:`, error);
          toast({
            title: "Erro parcial",
            description: `Erro ao corrigir relacionamento de ${relacionamento.nome_conjuge}.`,
            variant: "destructive",
          });
        } else {
          corrigidas++;
          setCorrigidasCount(corrigidas);
        }
      }

      if (corrigidas > 0) {
        toast({
          title: "Correção concluída!",
          description: `${corrigidas} relacionamentos foram corrigidos com sucesso.`,
        });
        
        // Limpar a lista após correção
        setRelacionamentosIncompletos([]);
      }

    } catch (error) {
      console.error("Erro ao corrigir relacionamentos:", error);
      toast({
        title: "Erro",
        description: "Erro ao corrigir relacionamentos de cônjuges.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Correção Automática de Cônjuges
          </CardTitle>
          <CardDescription>
            Esta ferramenta verifica e corrige automaticamente os relacionamentos de cônjuges na base de dados.
            Se João está cadastrado como cônjuge de Maria, mas Maria não está cadastrada como cônjuge de João,
            a ferramenta irá corrigir automaticamente essa inconsistência.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Button
              onClick={analisarRelacionamentos}
              disabled={analisando || loading}
              variant="outline"
            >
              {analisando ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analisando...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Analisar Relacionamentos
                </>
              )}
            </Button>

            {relacionamentosIncompletos.length > 0 && (
              <Button
                onClick={corrigirRelacionamentos}
                disabled={loading || analisando}
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Corrigindo... ({corrigidasCount}/{relacionamentosIncompletos.length})
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Corrigir Todos ({relacionamentosIncompletos.length})
                  </>
                )}
              </Button>
            )}
          </div>

          {relacionamentosIncompletos.length > 0 && (
            <>
              <Separator />
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  Relacionamentos Incompletos Encontrados
                </h3>
                <div className="space-y-2">
                  {relacionamentosIncompletos.map((rel, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{rel.nome}</p>
                        <p className="text-sm text-gray-600">
                          Está cadastrado(a) como cônjuge de <strong>{rel.nome_conjuge}</strong>
                        </p>
                      </div>
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                        Recíproco ausente
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {relacionamentosIncompletos.length === 0 && !analisando && (
            <div className="text-center py-8 text-gray-500">
              <CheckCircle className="h-12 w-12 mx-auto mb-3 text-green-500" />
              <p>Clique em "Analisar Relacionamentos" para verificar a base de dados.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CorrecaoConjuges;