// src/pages/LideresManagement.tsx
import { useState, useEffect, useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatPhone } from "@/lib/formatPhone";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Users,
  Building,
  Crown,
  Phone,
  Mail,
  MapPin,
  Edit,
  Search,
  X,
  Trash2,
  Award,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
// Accordion removido para exibir a área diretamente sem clique

/** Tipagens */
interface LiderAgrupado {
  idmembro: string;
  nome_membro: string;
  apelido_membro?: string;
  email_membro?: string;
  telefone_membro?: string;
  foto_membro?: string;
  foto_membro_url?: string;
  departamentos: Array<{
    iddepto: string;
    nome_departamento: string;
    idlider: string;
    idarea?: string | null;
    nome_area?: string;
    status: string; // status do vínculo do líder com o departamento
  }>;
}
interface Member {
  idmembro: string;
  nome: string;
  apelido?: string;
  status: string;
  email?: string;
  telefone?: string;
  foto?: string;
}
interface Department { iddepto: string; nome: string; liderdepto1?: string | null; liderdepto2?: string | null; }
interface Area { 
  idarea: string; 
  nome: string; 
  iddepto: string; 
  status?: string; 
  lider1?: string | null; 
  lider2?: string | null; 
}
interface User { email: string; permission: string; idmembro?: string; }
interface Props { user: User; }

const NONE = "none";

/** Componente */
export default function LideresManagement({ user }: Props) {
  const [lideres, setLideres] = useState<LiderAgrupado[]>([]);
  const [dominantDonByMember, setDominantDonByMember] = useState<Record<string, string[]>>({});
  const [members, setMembers] = useState<Member[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [areas, setAreas] = useState<Area[]>([]);
  const [loading, setLoading] = useState(false);

  // Diálogos
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [liderToDelete, setLiderToDelete] = useState<{ idlider: string; nomeMembro: string; nomeDepartamento: string; nomeArea?: string } | null>(null);

  // Edição
  const [editingLider, setEditingLider] = useState<{ idlider: string; idmembro: string; iddepto: string; idarea?: string | null } | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const [selectedArea, setSelectedArea] = useState<string>(NONE);
  const [selectedStatus, setSelectedStatus] = useState<"Ativo" | "Inativo" | "Desligado">("Ativo");

  // Inclusão
  const [selectedMember, setSelectedMember] = useState<string>("");
  const [newLiderDepartment, setNewLiderDepartment] = useState<string>("");
  const [newLiderArea, setNewLiderArea] = useState<string>(NONE);

  // Busca e filtro de status
  const [searchTerm, setSearchTerm] = useState("");
  const [showInactive, setShowInactive] = useState(false); // <- toggle para mostrar inativos/desligados
  const [myAreaIds, setMyAreaIds] = useState<string[]>([]);
  const [myLeaderAreas, setMyLeaderAreas] = useState<string[]>([]);

  useEffect(() => {
    console.log('LideresManagement: mounting, fetching data...');
    fetchLideres();
    fetchMembers();
    fetchDepartments();
    fetchAreas();
    
    return () => {
      console.log('LideresManagement: unmounting...');
    };
  }, []);

  // Carregar áreas lideradas pelo usuário logado (como lider1)
  useEffect(() => {
    const fetchMyLeaderAreas = async () => {
      if (!user?.idmembro) {
        setMyLeaderAreas([]);
        setMyAreaIds([]);
        return;
      }
      
      // Buscar áreas onde é líder principal (lider1)
      const { data: leaderData } = await supabase
        .from('areas')
        .select('idarea')
        .eq('lider1', user.idmembro)
        .eq('status', 'Ativo');
      const leaderIds = (leaderData || []).map(a => a.idarea);
      setMyLeaderAreas(leaderIds);
      
      // Para monitores, também buscar áreas onde é líder (tabela lideres)
      if (user.permission === 'MTR') {
        const { data: areaData } = await supabase
          .from('lideres')
          .select('idarea')
          .eq('status', 'Ativo')
          .eq('idmembro', user.idmembro)
          .not('idarea', 'is', null);
        const areaIds = Array.from(new Set((areaData || []).map((r: any) => String(r.idarea))));
        setMyAreaIds(areaIds);
      }
    };
    fetchMyLeaderAreas();
  }, [user?.permission, user?.idmembro]);

  /** Carregar líderes + nomes relacionais (JOIN direto) */
  const fetchLideres = async () => {
    console.log('LideresManagement: fetching lideres...');
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("lideres")
        .select(`
          *,
          membros:idmembro ( nome, apelido, email, telefone, foto ),
          departamentos:iddepto ( nome ),
          areas:idarea ( idarea, nome, status, iddepto )
        `)
        .order("idlider");

      if (error) throw error;

      const map = new Map<string, LiderAgrupado>();
      (data || []).forEach((l: any) => {
        const membroId = l.idmembro;
        const deptoItem = {
          iddepto: l.iddepto,
          nome_departamento: l.departamentos?.nome || "Sem departamento",
          idlider: l.idlider,
          idarea: l.idarea,
          nome_area: l.areas?.nome,
          status: l.status,
        };

        if (map.has(membroId)) {
          map.get(membroId)!.departamentos.push(deptoItem);
        } else {
          map.set(membroId, {
            idmembro: l.idmembro,
            nome_membro: l.membros?.nome || "Nome não encontrado",
            apelido_membro: l.membros?.apelido,
            email_membro: l.membros?.email,
            telefone_membro: l.membros?.telefone,
            foto_membro: l.membros?.foto,
            departamentos: [deptoItem],
          });
        }
      });

      const arr = Array.from(map.values()).sort((a, b) =>
        a.nome_membro.localeCompare(b.nome_membro)
      );

      // Resolver URL de foto via Signed URL (mitiga ORB e buckets privados)
      const resolved = await Promise.all(
        arr.map(async (l) => {
          const f = l.foto_membro;
          if (f && !f.startsWith("http") && !f.startsWith("/")) {
            try {
              const { data } = await supabase.storage
                .from("member-photos")
                .createSignedUrl(f, 3600);
              return { ...l, foto_membro_url: data?.signedUrl || undefined };
            } catch (e) {
              // fallback para publicUrl
              const { data: pub } = supabase.storage
                .from("member-photos")
                .getPublicUrl(f);
              return { ...l, foto_membro_url: pub?.publicUrl };
            }
          }
          return { ...l, foto_membro_url: f };
        })
      );

      setLideres(resolved);

      // Após carregar líderes, buscar dom predominante (nome) para cada membro
      try {
        const memberIds = resolved.map((l) => l.idmembro).filter(Boolean);
        if (memberIds.length === 0) {
          setDominantDonByMember({});
        } else {
          const { data: donsAval, error: donsErr } = await (supabase as any)
            .from('dons_avaliacoes')
            .select(`
              idmembro,
              criado_em,
              dons_resultados!inner (
                pontuacao,
                dons ( nome )
              )
            `)
            .in('idmembro', memberIds)
            .eq('status', 'concluida')
            .order('criado_em', { ascending: false });

          if (donsErr) throw donsErr;

          const latestByMember: Record<string, any> = {};
          (donsAval || []).forEach((row: any) => {
            const id = String(row.idmembro);
            // mantém a primeira (mais recente) ocorrência devido à ordenação desc
            if (!latestByMember[id]) latestByMember[id] = row;
          });

          const mapDon: Record<string, string[]> = {};
          Object.entries(latestByMember).forEach(([idmembro, row]: [string, any]) => {
            const resultados = Array.isArray(row?.dons_resultados) ? row.dons_resultados : [];
            if (resultados.length > 0) {
              const sorted = [...resultados].sort((a: any, b: any) => b.pontuacao - a.pontuacao);
              const top3 = sorted.slice(0, 3).map((item: any) => item?.dons?.nome).filter(Boolean);
              if (top3.length > 0) mapDon[idmembro] = top3 as string[];
            }
          });

          setDominantDonByMember(mapDon);
        }
      } catch (e) {
        console.warn('Falha ao buscar dom predominante dos líderes:', e);
        setDominantDonByMember({});
      }
    } catch (err) {
      toast({
        title: "Erro ao carregar líderes",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchMembers = async () => {
    console.log('LideresManagement: fetching members...');
    const { data } = await supabase
      .from("membros")
      .select("idmembro, nome, apelido, status, email, telefone, foto")
      .eq("status", "Ativo")
      .order("nome");
    setMembers(data || []);
  };

  const fetchDepartments = async () => {
    console.log('LideresManagement: fetching departments...');
    const { data } = await supabase.from("departamentos").select("*").order("nome");
    setDepartments(data || []);
  };

  const fetchAreas = async () => {
    console.log('LideresManagement: fetching areas...');
    const { data } = await supabase
      .from("areas")
      .select("idarea, nome, iddepto, status")
      .eq("status", "Ativo")
      .order("nome");
    setAreas(data || []);
  };

  const getAreasByDepartment = (iddepto: string) => areas.filter((a) => a.iddepto === iddepto);

  /** Salvar edição */
  const handleEditLider = async () => {
    if (!editingLider || !selectedDepartment) {
      toast({ title: "Campos obrigatórios", description: "Selecione um departamento.", variant: "destructive" });
      return;
    }
    try {
      const { error } = await supabase
        .from("lideres")
        .update({
          iddepto: selectedDepartment,
          idarea: selectedArea === NONE ? null : selectedArea,
          status: selectedStatus,
        })
        .eq("idlider", editingLider.idlider);

      if (error) throw error;

      toast({ title: "Líder alterado com sucesso!", description: "As informações do líder foram atualizadas." });
      setIsEditDialogOpen(false);
      setEditingLider(null);
      setSelectedDepartment("");
      setSelectedArea(NONE);
      fetchLideres();
    } catch (err) {
      toast({ title: "Erro ao alterar líder", description: err instanceof Error ? err.message : "Erro desconhecido", variant: "destructive" });
    }
  };

  /** Incluir novo líder */
  const handleAddLider = async () => {
    if (!selectedMember || !newLiderDepartment) {
      toast({ title: "Campos obrigatórios", description: "Selecione um membro e um departamento.", variant: "destructive" });
      return;
    }
    try {
      const { error } = await supabase
        .from("lideres")
        .insert({
          idmembro: selectedMember,
          iddepto: newLiderDepartment,
          idarea: newLiderArea === NONE ? null : newLiderArea,
          status: "Ativo",
        });

      if (error) throw error;

      toast({ title: "Líder incluído com sucesso!", description: "O novo líder foi adicionado ao sistema." });
      setIsAddDialogOpen(false);
      setSelectedMember("");
      setNewLiderDepartment("");
      setNewLiderArea(NONE);
      fetchLideres();
    } catch (err) {
      toast({ title: "Erro ao incluir líder", description: err instanceof Error ? err.message : "Erro desconhecido", variant: "destructive" });
    }
  };

  /** Estado para posição do líder no departamento */
  const [leaderDeptPosition, setLeaderDeptPosition] = useState<string>("");

  /** Abrir diálogo Alterar */
  const openEditDialog = async (lider: LiderAgrupado, departamento: { iddepto: string; idlider: string; idarea?: string | null; status: string }) => {
    const currentDept = departamento.iddepto;
    const currentArea = departamento.idarea ?? null;

    // Buscar departamento atualizado do banco para verificar posição
    const { data: deptData } = await supabase
      .from('departamentos')
      .select('liderdepto1, liderdepto2')
      .eq('iddepto', currentDept)
      .single();

    let position = "";
    if (deptData) {
      if (deptData.liderdepto1 === lider.idmembro) {
        position = "Líder do Departamento";
      } else if (deptData.liderdepto2 === lider.idmembro) {
        position = "Auxiliar do Líder";
      }
    }
    setLeaderDeptPosition(position);

    setEditingLider({
      idlider: departamento.idlider,
      idmembro: lider.idmembro,
      iddepto: currentDept,
      idarea: currentArea,
    });
    setSelectedDepartment(currentDept);
    setSelectedArea(currentArea ?? NONE);
    setSelectedStatus((departamento.status as any) || "Ativo");
    setIsEditDialogOpen(true);
  };

  /** Abrir diálogo de exclusão */
  const openDeleteDialog = (lider: LiderAgrupado, departamento: { iddepto: string; idlider: string; nome_departamento: string; nome_area?: string }) => {
    setLiderToDelete({
      idlider: departamento.idlider,
      nomeMembro: lider.nome_membro,
      nomeDepartamento: departamento.nome_departamento,
      nomeArea: departamento.nome_area,
    });
    setIsDeleteDialogOpen(true);
  };

  /** Excluir líder de área/departamento */
  const handleDeleteLider = async () => {
    if (!liderToDelete) return;

    try {
      // Se tem área, remove apenas a área (deixa idarea como null)
      // Se não tem área, marca como inativo
      const updateData = liderToDelete.nomeArea 
        ? { idarea: null }
        : { status: "Inativo" };

      const { error } = await supabase
        .from("lideres")
        .update(updateData)
        .eq("idlider", liderToDelete.idlider);

      if (error) throw error;

      const message = liderToDelete.nomeArea
        ? `${liderToDelete.nomeMembro} foi removido da área ${liderToDelete.nomeArea}.`
        : `${liderToDelete.nomeMembro} foi removido da liderança.`;

      toast({
        title: "Líder removido com sucesso!",
        description: message,
      });

      setIsDeleteDialogOpen(false);
      setLiderToDelete(null);
      fetchLideres();
    } catch (err) {
      toast({
        title: "Erro ao remover líder",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  };

  /** Imagem pública */
  const getImageUrl = (foto?: string) => {
    if (!foto) return null;
    if (foto.startsWith("http") || foto.startsWith("/")) return foto;
    const { data } = supabase.storage.from("member-photos").getPublicUrl(foto);
    return data.publicUrl;
  };

  // --------- FILTROS (status + busca) ----------
  // 1) filtra departamentos visíveis conforme o toggle showInactive
  const myDeptIds = useMemo(() => {
    if (user?.permission !== 'MTR' || !user?.idmembro) return [] as string[];
    return departments
      .filter((d) => d.liderdepto1 === user.idmembro || d.liderdepto2 === user.idmembro)
      .map((d) => String(d.iddepto));
  }, [departments, user?.permission, user?.idmembro]);

  const leadersWithVisibleDepts = useMemo(() => {
    const isMonitor = user?.permission === 'MTR';
    const isLeader = myLeaderAreas.length > 0;
    const myDeptSet = new Set(myDeptIds);
    
    return lideres
      .map((l) => ({
        ...l,
        departamentos: l.departamentos.filter((d) => {
          const statusOk = showInactive ? true : d.status === 'Ativo';
          
          // Se for Monitor, filtra por departamento
          if (isMonitor) {
            return statusOk && myDeptSet.has(String(d.iddepto));
          }
          
          // Se for líder de área, filtra pela área
          if (isLeader && d.idarea) {
            return statusOk && myLeaderAreas.includes(d.idarea);
          }
          
          // ADM ou outros: mostra tudo
          return statusOk;
        }),
      }))
      .filter((l) => l.departamentos.length > 0);
  }, [lideres, showInactive, user?.permission, myLeaderAreas, myDeptIds]);

  // 2) aplica a busca em cima da lista já filtrada por status
  const filtered = useMemo(() => {
    const q = searchTerm.toLowerCase();
    if (!q) return leadersWithVisibleDepts;
    return leadersWithVisibleDepts.filter(
      (l) =>
        l.nome_membro.toLowerCase().includes(q) ||
        (l.apelido_membro && l.apelido_membro.toLowerCase().includes(q)) ||
        l.departamentos.some((d) => d.nome_departamento.toLowerCase().includes(q))
    );
  }, [leadersWithVisibleDepts, searchTerm]);

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Gestão de Líderes
              </CardTitle>

              <div className="flex items-center gap-4">
                {user?.permission !== 'MTR' && (
                  <Button 
                    onClick={() => setIsAddDialogOpen(true)}
                    className="bg-gradient-primary"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Incluir Líder
                  </Button>
                )}

                {/* Toggle mostrar inativos/desligados (oculto para Monitores) */}
                {user?.permission !== 'MTR' && (
                  <div className="flex items-center gap-2">
                    <Switch id="show-inactive" checked={showInactive} onCheckedChange={setShowInactive} />
                    <Label htmlFor="show-inactive" className="text-sm">
                      Mostrar inativos/desligados
                    </Label>
                  </div>
                )}
              </div>
            </div>

            {/* Modal de Edição */}
            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Alterar Líder</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {leaderDeptPosition && (
                    <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
                      <div className="flex items-center gap-2">
                        <Crown className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium text-primary">
                          {leaderDeptPosition}
                        </span>
                      </div>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Departamento</label>
                    <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um departamento" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => (
                          <SelectItem key={d.iddepto} value={d.iddepto}>
                            {d.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedDepartment && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Área</label>
                      <Select value={selectedArea} onValueChange={setSelectedArea}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma área" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={NONE}>Nenhuma área</SelectItem>
                          {getAreasByDepartment(selectedDepartment).map((a) => (
                            <SelectItem key={a.idarea} value={a.idarea}>
                              {a.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Status</label>
                    <Select value={selectedStatus} onValueChange={(v) => setSelectedStatus(v as any)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o status" />
                      </SelectTrigger>
                      <SelectContent>
                         <SelectItem value="Ativo">Ativo</SelectItem>
                         <SelectItem value="Inativo">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleEditLider} className="bg-gradient-primary">
                      Alterar Líder
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {/* Modal de Inclusão (oculto para Monitores) */}
            {user?.permission !== 'MTR' && (
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Incluir Novo Líder</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Membro</label>
                    <Select value={selectedMember} onValueChange={setSelectedMember}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um membro" />
                      </SelectTrigger>
                      <SelectContent>
                        {members.map((m) => (
                          <SelectItem key={m.idmembro} value={m.idmembro}>
                            {m.nome} {m.apelido && `"${m.apelido}"`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Departamento</label>
                    <Select value={newLiderDepartment} onValueChange={setNewLiderDepartment}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um departamento" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => (
                          <SelectItem key={d.iddepto} value={d.iddepto}>
                            {d.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {newLiderDepartment && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Área</label>
                      <Select value={newLiderArea} onValueChange={setNewLiderArea}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma área" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={NONE}>Nenhuma área</SelectItem>
                          {getAreasByDepartment(newLiderDepartment).map((a) => (
                            <SelectItem key={a.idarea} value={a.idarea}>
                              {a.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleAddLider} className="bg-gradient-primary">
                      Incluir Líder
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            )}

            {/* Modal de Confirmação de Exclusão */}
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirmar Remoção</AlertDialogTitle>
                  <AlertDialogDescription>
                    {liderToDelete?.nomeArea ? (
                      <>
                        Tem certeza que deseja remover <strong>{liderToDelete?.nomeMembro}</strong> da área <strong>{liderToDelete.nomeArea}</strong>?
                        <br /><br />
                        O líder continuará ativo no departamento <strong>{liderToDelete.nomeDepartamento}</strong>, apenas não liderará mais esta área específica.
                      </>
                    ) : (
                      <>
                        Tem certeza que deseja remover <strong>{liderToDelete?.nomeMembro}</strong> da liderança do departamento <strong>{liderToDelete?.nomeDepartamento}</strong>?
                        <br /><br />
                        Esta ação marcará o status como "Inativo" e pode ser revertida posteriormente.
                      </>
                    )}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDeleteLider}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Remover
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardHeader>

        <CardContent>
          {/* Busca */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Buscar líder por nome ou departamento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-20 w-full rounded-lg" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">
                {searchTerm ? "Nenhum líder encontrado" : "Nenhum líder encontrado com os filtros atuais"}
              </p>
              <p className="text-sm">Ajuste a busca ou ative “Mostrar inativos/desligados”.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {filtered.map((lider) => (
                <Card key={lider.idmembro} className="bg-muted/20 border border-border/40 hover:bg-muted/30 transition-colors">
                  <CardContent className="p-5">
                    <div className="flex flex-col sm:flex-row items-start gap-4">
                      {/* Foto */}
                      <div className="flex-shrink-0 mx-auto sm:mx-0">
                        <div className="w-16 h-16 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden relative ring-2 ring-primary/20 shadow-sm">
                          {(() => {
                            const img = lider.foto_membro_url || getImageUrl(lider.foto_membro);
                            return img ? (
                              <img src={img} alt={lider.nome_membro} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full bg-gradient-primary rounded-full flex items-center justify-center ring-2 ring-primary/20 shadow-sm">
                                <Crown className="w-8 h-8 text-primary-foreground" />
                              </div>
                            );
                          })()}
                        </div>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0 w-full">
                        <div className="flex flex-col gap-2 mb-3 text-center sm:text-left">
                          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                            <div>
                              <h3 className="font-semibold text-lg leading-tight">{lider.nome_membro}</h3>
                              {lider.apelido_membro && (
                                <p className="text-sm text-muted-foreground">"{lider.apelido_membro}"</p>
                              )}
                            </div>
                            <Badge variant="default" className="text-xs w-fit mx-auto sm:mx-0">Líder</Badge>
                          </div>
                        </div>
                        <div className="h-px bg-border/60 mb-3"></div>

                        <div className="space-y-3">
                          <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                            <Building className="w-3 h-3" /> Liderança
                          </h4>

                          {lider.departamentos.map((dept) => (
                            <div key={`${dept.idlider}-${dept.iddepto}`} className="bg-muted/20 border border-border/50 p-3 rounded-lg">
                              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                                <div className="flex items-center gap-2">
                                  <Building className="w-4 h-4 text-primary" />
                                  <span className="font-medium text-sm">{dept.nome_departamento}</span>
                                  {dept.status !== "Ativo" && (
                                    <Badge variant="outline" className="text-[10px] uppercase">
                                      {dept.status}
                                    </Badge>
                                  )}
                                </div>
                                {user?.permission !== 'MTR' && (
                                  <div className="flex gap-1 self-end sm:self-auto">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => openEditDialog(lider, dept)}
                                      className="h-7 px-2"
                                    >
                                      <Edit className="w-3 h-3" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => openDeleteDialog(lider, dept)}
                                      className="h-7 px-2 text-destructive hover:text-destructive hover:bg-destructive/10"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                  </div>
                                )}
                              </div>
                              {dept.nome_area && dept.iddepto === 'c3245218' && (
                                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                                  <MapPin className="w-3 h-3" />
                                  <span>
                                    Área: <span className="font-medium">{dept.nome_area}</span>
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}

                          <div className="mt-4 pt-3 border-t border-border/40 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {(lider.telefone_membro || lider.email_membro) && (
                              <div className="bg-muted/20 border border-border/50 p-3 rounded-lg">
                                <div className="flex items-center gap-2">
                                  <Phone className="w-4 h-4 text-primary" />
                                  <span className="font-medium text-sm">Contato</span>
                                </div>
                                <div className="mt-2 space-y-2 text-sm">
                                  {lider.telefone_membro && (
                                    <div className="flex items-center gap-2">
                                      <Phone className="w-3 h-3 flex-shrink-0 text-muted-foreground" />
                                      <span>{formatPhone(lider.telefone_membro)}</span>
                                    </div>
                                  )}
                                  {lider.email_membro && (
                                    <div className="flex items-center gap-2">
                                      <Mail className="w-3 h-3 flex-shrink-0 text-muted-foreground" />
                                      <span className="truncate">{lider.email_membro}</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                            {Array.isArray(dominantDonByMember[lider.idmembro]) && dominantDonByMember[lider.idmembro].length > 0 && (
                              <div className="bg-muted/20 border border-border/50 p-3 rounded-lg">
                                <div className="flex items-center gap-2">
                                  <Award className="w-3 h-3 text-amber-500" />
                                  <span className="font-medium text-sm">Dons Predominates</span>
                                </div>
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {dominantDonByMember[lider.idmembro].map((nome, idx) => (
                                    <span
                                      key={idx}
                                      className="border border-amber-300/60 rounded-md px-2 py-0.5 text-amber-700 bg-amber-50"
                                    >
                                      <span className="font-medium mr-1">{idx + 1}º</span>
                                      {nome}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
