// src/components/MainLayout.tsx
import { ReactNode, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Dashboard from "@/components/Dashboard";
import UserManagement from "@/components/UserManagement";
import MemberManagement from "@/components/MemberManagement";
import AgendaManagement from "@/components/AgendaManagement";
import LideresManagement from "@/components/LideresManagement";
import DepartamentosManagement from "@/components/DepartamentosManagement";
import AreasManagement from "@/components/AreasManagement";
import TiposEventosManagement from "@/components/TiposEventosManagement";
import LocaisEventosManagement from "@/components/LocaisEventosManagement";
import PerfilMembro from "./PerfilMembro";
import RelatorioDons from "./RelatorioDons";
import RelatorioCasais from "./RelatorioCasais";
import CorrecaoConjuges from "./CorrecaoConjuges";
import { AppSidebar } from "@/components/AppSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";

interface User {
  email: string;
  permission: "ADM" | "LDR" | "USR" | "MTR" | "OPE";
  memberName?: string;
}

interface Props {
  user: User;
  onLogout: () => Promise<{ error: any }> | (() => void);
  children?: ReactNode;
}

export default function MainLayout({ user, onLogout, children }: Props) {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname.split('/')[1] || 'dashboard';

  const handleTabChange = (tab: string) => {
    navigate(`/${tab}`);
  };

  // Removido redirecionamento forçado de monitores para não bloquear navegação


  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-subtle">
        <AppSidebar
          user={user}
          activeTab={currentPath}
          onTabChange={handleTabChange}
          onLogout={() => onLogout()}
        />

        <div className="flex-1 min-w-0">
          {/* Header */}
          <header className="bg-background/95 backdrop-blur-sm border-b shadow-lg sticky top-0 z-40">
            <div className="flex items-center gap-3 px-4 py-3">
              <SidebarTrigger className="mr-1" />
              <img
                src="/lovable-uploads/9d9229f3-fb14-4b21-9692-6a6aa36e1d16.png"
                alt="Igreja Águas Purificadoras"
                className="w-8 h-8 object-contain shadow-none border-none bg-transparent p-0 select-none pointer-events-none"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = "none";
                }}
              />
              <h1 className="text-lg font-bold bg-gradient-to-r from-primary via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Sistema de Gestão
              </h1>
            </div>
          </header>

          {/* Content */}
          <main className="p-6">
            {children ? (
              children
            ) : (
              <>
                {currentPath === "dashboard" && user.permission !== "MTR" && <Dashboard />}
                {currentPath === "agenda" && (
                  <>
                    {console.log('[MainLayout] Rendering AgendaManagement with user:', user)}
                    <AgendaManagement user={user} />
                  </>
                )}
                {currentPath === "membros" && user.permission !== "MTR" && <MemberManagement />}
                {currentPath === "perfil-membro" && <PerfilMembro user={user} />}
                {currentPath === "relatorios-dons" && <RelatorioDons />}
                {currentPath === "relatorio-casais" && user.permission === "ADM" && <RelatorioCasais />}

                {/* Liderança */}
                {currentPath === "lideres" && <LideresManagement user={user} />}
                {currentPath === "departamentos" && <DepartamentosManagement />}
                {currentPath === "areas" && <AreasManagement />}

                {/* Agenda - Cadastros */}
                {currentPath === "tipos-eventos" && user.permission === "ADM" && (
                  <TiposEventosManagement />
                )}
                {currentPath === "locais-eventos" && user.permission === "ADM" && (
                  <LocaisEventosManagement />
                )}

                {/* Administração */}
                {currentPath === "usuarios" && user.permission === "ADM" && (
                  <UserManagement />
                )}
                {currentPath === "correcao-conjuges" && user.permission === "ADM" && (
                  <CorrecaoConjuges />
                )}
                

              </>
            )}

          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
