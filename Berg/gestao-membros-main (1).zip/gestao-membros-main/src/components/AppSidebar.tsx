// src/components/AppSidebar.tsx
import {
  Calendar,
  Users,
  UserCog,
  UserCheck,
  Building,
  MapPin,
  LogOut,
  BarChart3,
  List,
  User,
  Award,
  Trash2,
  RefreshCw,
  Heart,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import ChangePasswordButton from "@/components/ChangePasswordButton";

interface User {
  email: string;
  permission: "ADM" | "LDR" | "USR" | "MTR" | "OPE";
  memberName?: string;
}

interface AppSidebarProps {
  user: User;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
}

const PERMISSION_LABELS = {
  ADM: { label: "Administrador", color: "bg-success text-success-foreground" },
  LDR: { label: "Líder", color: "bg-warning text-warning-foreground" },
  USR: { label: "Usuário", color: "bg-secondary text-secondary-foreground" },
  MTR: { label: "Monitor", color: "bg-accent text-accent-foreground" },
  OPE: { label: "Operador", color: "bg-muted text-muted-foreground" },
};

export function AppSidebar({ user, activeTab, onTabChange, onLogout }: AppSidebarProps) {
  const { state, setOpenMobile } = useSidebar();
  const collapsed = state === "collapsed";
  const permissionInfo = PERMISSION_LABELS[user.permission];

  const handleTabChange = (tab: string) => {
    onTabChange(tab);
    setOpenMobile(false);
  };

  const itemCls = (isActive: boolean) =>
    [
      "w-full justify-start",
      isActive
        ? "bg-primary/10 text-primary font-medium border-l-4 border-primary rounded-r-lg"
        : "hover:bg-muted",
    ].join(" ");

  return (
    <Sidebar className="border-r border-sidebar-border">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <img
            src="/lovable-uploads/9d9229f3-fb14-4b21-9692-6a6aa36e1d16.png"
            alt="Igreja Águas Purificadoras"
            className="h-8 w-8 object-contain shadow-none border-none bg-transparent rounded-full"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
          />
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-semibold text-sidebar-foreground truncate">
                Gestão de Membros
              </h2>
              <p className="text-xs text-sidebar-foreground/70 truncate">
                Igreja Águas Purificadoras
              </p>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="space-y-4">
        {/* Menu Principal */}
        <SidebarGroup>
          <SidebarGroupLabel>Menu Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {user.permission !== "MTR" && (
                <>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => handleTabChange("dashboard")}
                      isActive={activeTab === "dashboard"}
                      className={itemCls(activeTab === "dashboard")}
                    >
                      <BarChart3 className="h-4 w-4 flex-shrink-0" />
                      {!collapsed && <span>Dashboard</span>}
                    </SidebarMenuButton>
                  </SidebarMenuItem>

                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => handleTabChange("membros")}
                      isActive={activeTab === "membros"}
                      className={itemCls(activeTab === "membros")}
                    >
                      <UserCheck className="h-4 w-4 flex-shrink-0" />
                      {!collapsed && <span>Membros</span>}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </>
              )}

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => handleTabChange("perfil-membro")}
                  isActive={activeTab === "perfil-membro"}
                  className={itemCls(activeTab === "perfil-membro")}
                >
                  <User className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span>Perfil Membro</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Agenda */}
        <SidebarGroup>
          <SidebarGroupLabel>Agenda</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => handleTabChange("agenda")}
                  isActive={activeTab === "agenda"}
                  className={itemCls(activeTab === "agenda")}
                >
                  <Calendar className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span>Agenda</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>

              {user.permission === "ADM" && (
                <>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => handleTabChange("tipos-eventos")}
                      isActive={activeTab === "tipos-eventos"}
                      className={itemCls(activeTab === "tipos-eventos")}
                    >
                      <List className="h-4 w-4 flex-shrink-0" />
                      {!collapsed && <span>Tipos de Eventos</span>}
                    </SidebarMenuButton>
                  </SidebarMenuItem>

                  <SidebarMenuItem>
                    <SidebarMenuButton
                      onClick={() => handleTabChange("locais-eventos")}
                      isActive={activeTab === "locais-eventos"}
                      className={itemCls(activeTab === "locais-eventos")}
                    >
                      <MapPin className="h-4 w-4 flex-shrink-0" />
                      {!collapsed && <span>Locais de Eventos</span>}
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Liderança */}
        <SidebarGroup>
          <SidebarGroupLabel>Liderança</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => handleTabChange("lideres")}
                  isActive={activeTab === "lideres"}
                  className={itemCls(activeTab === "lideres")}
                >
                  <Users className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span>Gestão de Líderes</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => handleTabChange("departamentos")}
                  isActive={activeTab === "departamentos"}
                  className={itemCls(activeTab === "departamentos")}
                >
                  <Building className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span>Departamentos</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>

              {user.permission !== "MTR" && (
                <SidebarMenuItem>
                  <SidebarMenuButton
                    onClick={() => handleTabChange("areas")}
                    isActive={activeTab === "areas"}
                    className={itemCls(activeTab === "areas")}
                  >
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    {!collapsed && <span>Áreas</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Casais */}
        {user.permission === "ADM" && (
          <SidebarGroup>
            <SidebarGroupLabel>Casais</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    onClick={() => handleTabChange("relatorio-casais")}
                    isActive={activeTab === "relatorio-casais"}
                    className={itemCls(activeTab === "relatorio-casais")}
                  >
                    <Heart className="h-4 w-4 flex-shrink-0" />
                    {!collapsed && <span>Relatório de Casais</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
                
                <SidebarMenuItem>
                  <SidebarMenuButton
                    onClick={() => handleTabChange("correcao-conjuges")}
                    isActive={activeTab === "correcao-conjuges"}
                    className={itemCls(activeTab === "correcao-conjuges")}
                  >
                    <RefreshCw className="h-4 w-4 flex-shrink-0" />
                    {!collapsed && <span>Correção de Cônjuges</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Relatórios */}
        <SidebarGroup>
          <SidebarGroupLabel>Relatórios</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => handleTabChange("relatorios-dons")}
                  isActive={activeTab === "relatorios-dons"}
                  className={itemCls(activeTab === "relatorios-dons")}
                >
                  <Award className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && <span>Relatório de Dons</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Administração */}
        {user.permission === "ADM" && (
          <SidebarGroup>
            <SidebarGroupLabel>Administração</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    onClick={() => handleTabChange("usuarios")}
                    isActive={activeTab === "usuarios"}
                    className={itemCls(activeTab === "usuarios")}
                  >
                    <UserCog className="h-4 w-4 flex-shrink-0" />
                    {!collapsed && <span>Usuários</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        {!collapsed && (
          <div className="mb-3">
            <div className="text-xs text-sidebar-foreground/70">
              {user.memberName ? `Olá, ${user.memberName}` : user.email}
            </div>
          </div>
        )}
        {/* Alterar Senha */}
        <ChangePasswordButton collapsed={collapsed} />
        <Button
          variant="ghost"
          size="sm"
          onClick={onLogout}
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
          title="Sair"
        >
          <LogOut className="h-4 w-4 flex-shrink-0" />
          {!collapsed && <span className="ml-2">Sair</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
