import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useUsers } from '@/hooks/useUsers';
import { supabase } from '@/integrations/supabase/client';
import { UserPlus, Users, Mail, Shield, Calendar, User, KeyRound, Edit } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';

interface UserData {
  idusuario: string;
  email: string;
  idmembro: string | null;
  permissao: string;
  auth_uid: string;
  nome_membro: string;
  created_at: string;
}

interface Member {
  idmembro: string;
  nome: string;
  foto?: string;
  email?: string;
}

const PERMISSION_LABELS = {
  ADM: { label: 'Administrador', color: 'bg-destructive text-destructive-foreground' },
  LDR: { label: 'Líder', color: 'bg-warning text-warning-foreground' },
  USR: { label: 'Usuário', color: 'bg-secondary text-secondary-foreground' },
  MTR: { label: 'Monitor', color: 'bg-accent text-accent-foreground' },
  OPE: { label: 'Operador', color: 'bg-muted text-muted-foreground' }
};

export default function UserManagement() {
  const { users, loading, createUser, resetPassword, updateUser } = useUsers();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [permission, setPermission] = useState('USR');
  const [selectedMember, setSelectedMember] = useState<string>('');
  const [memberEmail, setMemberEmail] = useState<string>('');
  const [members, setMembers] = useState<Member[]>([]);
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [membersPhotos, setMembersPhotos] = useState<Record<string, string>>({});
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [editEmail, setEditEmail] = useState('');
  const [editPermission, setEditPermission] = useState('');

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const { data, error } = await supabase
          .from('membros')
          .select('idmembro, nome, foto, email')
          .eq('status', 'Ativo')
          .not('email', 'is', null)
          .order('nome');
        
        if (!error && data) {
          // Filtrar apenas membros que têm email e não têm usuário
          const membersWithEmail = data.filter(member => member.email);
          const existingUsers = users.map(user => user.idmembro).filter(Boolean);
          const availableMembers = membersWithEmail.filter(member => 
            !existingUsers.includes(member.idmembro)
          );
          
          setMembers(availableMembers);
          // Create a photos map
          const photosMap = availableMembers.reduce((acc, member) => {
            if (member.foto) {
              acc[member.idmembro] = member.foto;
            }
            return acc;
          }, {} as Record<string, string>);
          setMembersPhotos(photosMap);
        }
      } catch (err) {
        console.error('Error fetching members:', err);
      }
    };

    fetchMembers();
  }, [users]);

  const handleMemberChange = (memberId: string) => {
    setSelectedMember(memberId);
    const selectedMemberData = members.find(member => member.idmembro === memberId);
    if (selectedMemberData && selectedMemberData.email) {
      setMemberEmail(selectedMemberData.email);
    } else {
      setMemberEmail('');
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberEmail || !password || !selectedMember) return;

    setCreating(true);
    const result = await createUser(memberEmail, password, permission, selectedMember);
    
    if (result.success) {
      setIsDialogOpen(false);
      setPassword('');
      setPermission('USR');
      setSelectedMember('');
      setMemberEmail('');
    }
    setCreating(false);
  };

  const formatDate = (dateString: string) => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(dateString));
  };

  const getImageUrl = (imageName: string | null) => {
    if (!imageName) return null;
    
    if (imageName.startsWith('http') || imageName.startsWith('/')) {
      return imageName;
    }
    
    const { data } = supabase.storage.from('member-photos').getPublicUrl(imageName);
    return data.publicUrl;
  };

  const handleEditUser = (user: UserData) => {
    setEditingUser(user);
    setEditEmail(user.email);
    setEditPermission(user.permissao);
    setIsEditDialogOpen(true);
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    setUpdating(true);
    const updates: { email?: string; permissao?: string } = {};
    
    if (editEmail !== editingUser.email) {
      updates.email = editEmail;
    }
    
    if (editPermission !== editingUser.permissao) {
      updates.permissao = editPermission;
    }

    if (Object.keys(updates).length === 0) {
      toast({
        title: "Nenhuma alteração detectada",
        description: "Não há mudanças para salvar.",
        variant: "destructive"
      });
      setUpdating(false);
      return;
    }

    const result = await updateUser(editingUser.idusuario, updates);
    
    if (result.success) {
      setIsEditDialogOpen(false);
      setEditingUser(null);
      setEditEmail('');
      setEditPermission('');
    }
    setUpdating(false);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-elegant">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Gerenciamento de Usuários
            </CardTitle>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-primary text-primary-foreground hover:shadow-primary">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Novo Usuário
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Criar Novo Usuário</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateUser} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="member">Membro</Label>
                    <Select value={selectedMember} onValueChange={handleMemberChange} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um membro" />
                      </SelectTrigger>
                      <SelectContent>
                        {members.map((member) => (
                          <SelectItem key={member.idmembro} value={member.idmembro}>
                            {member.nome} - {member.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {memberEmail && (
                      <p className="text-sm text-muted-foreground">
                        E-mail: {memberEmail}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Senha do usuário"
                      required
                      minLength={6}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="permission">Permissão</Label>
                    <Select value={permission} onValueChange={setPermission}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a permissão" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USR">Usuário</SelectItem>
                        <SelectItem value="LDR">Líder</SelectItem>
                        <SelectItem value="MTR">Monitor</SelectItem>
                        <SelectItem value="OPE">Operador</SelectItem>
                        <SelectItem value="ADM">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                      disabled={creating}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={creating}
                      className="bg-gradient-primary"
                    >
                      {creating ? 'Criando...' : 'Criar Usuário'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Editar Usuário</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleUpdateUser} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="editEmail">E-mail</Label>
                    <Input
                      id="editEmail"
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      placeholder="E-mail do usuário"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="editPermission">Permissão</Label>
                    <Select value={editPermission} onValueChange={setEditPermission}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a permissão" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USR">Usuário</SelectItem>
                        <SelectItem value="LDR">Líder</SelectItem>
                        <SelectItem value="MTR">Monitor</SelectItem>
                        <SelectItem value="OPE">Operador</SelectItem>
                        <SelectItem value="ADM">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex justify-end gap-2 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsEditDialogOpen(false)}
                      disabled={updating}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updating}
                      className="bg-gradient-primary"
                    >
                      {updating ? 'Atualizando...' : 'Atualizar'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-4 w-[200px]" />
                  <Skeleton className="h-4 w-[150px]" />
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-4 w-[120px]" />
                </div>
              ))}
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Nenhum usuário encontrado</p>
              <p className="text-sm">
                Crie o primeiro usuário para começar
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Foto</TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      E-mail
                    </div>
                  </TableHead>
                  <TableHead>Membro</TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      Permissão
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Criado em
                    </div>
                  </TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => {
                  const permissionInfo = PERMISSION_LABELS[user.permissao as keyof typeof PERMISSION_LABELS];
                  const userPhoto = user.idmembro ? membersPhotos[user.idmembro] : null;
                  return (
                    <TableRow key={user.idusuario}>
                      <TableCell>
                        <div className="w-10 h-10 bg-gradient-subtle rounded-full flex items-center justify-center overflow-hidden">
                          {userPhoto && getImageUrl(userPhoto) ? (
                            <img 
                              src={getImageUrl(userPhoto)!} 
                              alt={user.nome_membro} 
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                                const nextElement = e.currentTarget.nextElementSibling as HTMLElement;
                                if (nextElement) nextElement.style.display = 'flex';
                              }}
                            />
                          ) : null}
                          <User className="w-5 h-5 text-muted-foreground" />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{user.email}</TableCell>
                      <TableCell>
                        {user.nome_membro === 'Sem membro vinculado' ? (
                          <span className="text-muted-foreground text-sm">
                            {user.nome_membro}
                          </span>
                        ) : (
                          user.nome_membro
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className={permissionInfo?.color || 'bg-muted text-muted-foreground'}>
                          {permissionInfo?.label || user.permissao}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {formatDate(user.created_at)}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditUser(user)}
                            className="h-8"
                          >
                            <Edit className="w-3 h-3 mr-1" />
                            Editar
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              console.log('🔄 Tentando resetar senha para:', { 
                                auth_uid: user.auth_uid, 
                                email: user.email,
                                tipo: typeof user.auth_uid
                              });
                              if (!user.auth_uid) {
                                toast({
                                  title: "Erro",
                                  description: "Usuário não possui ID de autenticação válido",
                                  variant: "destructive"
                                });
                                return;
                              }
                              resetPassword(user.auth_uid, user.email);
                            }}
                            className="h-8 min-w-[80px]"
                          >
                            <KeyRound className="w-3 h-3 mr-1" />
                            Resetar Senha
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}