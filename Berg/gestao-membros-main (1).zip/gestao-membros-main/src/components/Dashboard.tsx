import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, Calendar, MapPin, Gift } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface DashboardStats {
  membrosAtivosSemVisitantes: number;
  visitantes: number;
  totalLideres: number;
  lideresAtivos: number;
  eventosProximos: number;
  aniversariantesHoje: number;
}

interface EventData {
  nome_evento: string;
  data: string;
  horario_inicial: string;
  nome_local: string;
  departamento: string;
}

interface AniversarianteData {
  nome: string;
  apelido: string;
  nascimento: string;
  idade: number;
  idmembro: string;
  relacionamentos?: {
    tipo: string;
    nome: string;
  }[];
}

import { useNavigate } from "react-router-dom";

const LoadingState = () => (
  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
    {[...Array(6)].map((_, i) => (
      <Card key={i}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">
            <Skeleton className="h-4 w-[150px]" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-8 w-[100px]" />
        </CardContent>
      </Card>
    ))}
  </div>
);

const Dashboard = () => {
  const navigate = useNavigate();
  // Usuário seguro (evita permission undefined)
  const { user: sessionUser, userProfile } = useAuth();
  const user = useMemo(() => {
    const email =
      (userProfile as any)?.email ??
      (sessionUser as any)?.email ??
      "";
    const permission =
      (userProfile as any)?.permission ??
      (userProfile as any)?.role ??
      "USR";
    return { email, permission } as { email: string; permission: string };
  }, [sessionUser, userProfile]);

  const [stats, setStats] = useState<DashboardStats>({
    membrosAtivosSemVisitantes: 0,
    visitantes: 0,
    totalLideres: 0,
    lideresAtivos: 0,
    eventosProximos: 0,
    aniversariantesHoje: 0,
  });

  const [upcomingEvents, setUpcomingEvents] = useState<EventData[]>([]);
  const [aniversariantes, setAniversariantes] = useState<AniversarianteData[]>([]);
  const [loading, setLoading] = useState(true);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    if (sessionUser && userProfile) {
      setAuthChecked(true);
      fetchDashboardData();
    } else if (sessionUser && !userProfile) {
      // Usuário logado mas sem perfil - aguarda o perfil ser carregado
      console.log('Dashboard: User logged in but profile not loaded yet, waiting...');
      setAuthChecked(true);
      setLoading(false);
    }
    // Removido redirecionamento para /login - deixa o ProtectedRoute cuidar disso
  }, [sessionUser, userProfile]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      await Promise.all([fetchStats(), fetchUpcomingEvents(), fetchAniversariantes()]);
    } catch (error) {
      console.error("Erro geral no dashboard:", error);
      toast({
        title: "Erro ao carregar dashboard",
        description: "Não foi possível carregar todas as informações",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const { count: visitantesCount, error: visitErr } = await supabase
        .from("membros")
        .select("idmembro", { count: "planned" })
        .ilike("tipo_membro", "%visit%");
      if (visitErr) throw visitErr;

      // Membros Ativos EXCLUINDO visitantes
      // ⚠️ Sintaxe correta do PostgREST no .or():
      // "campo.op.valor,campo.op.valor"
      const { count: ativosSemVisitantes, error: ativosErr } = await supabase
        .from("membros")
        .select("idmembro", { count: "planned" })
        .eq("status", "Ativo")
        .or("tipo_membro.is.null,tipo_membro.not.ilike.%visit%");
      if (ativosErr) throw ativosErr;

      // Líderes únicos ativos
      const { data: lideresData, error: lideresErr } = await supabase
        .from("lideres")
        .select("idmembro")
        .eq("status", "Ativo");
      if (lideresErr) throw lideresErr;

      const lideresUnicos = new Set((lideresData || []).map((l) => l.idmembro));
      const totalLideres = lideresUnicos.size;

      // Eventos próximos (7 dias)
      const today = new Date().toISOString().split("T")[0];
      const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0];

      const { data: eventos, error: evErr } = await supabase
        .from("agenda")
        .select("*")
        .gte("data", today)
        .lte("data", nextWeek);
      if (evErr) throw evErr;

      // Aniversariantes do mês (apenas número para stats)
      const hoje = new Date();
      const mesAtual = hoje.getMonth() + 1;
      const { data: anivMes, error: anivErr } = await supabase
        .from("membros")
        .select("nascimento")
        .eq("status", "Ativo");
      if (anivErr) throw anivErr;

      const aniversariantesDoMes =
        anivMes?.filter((p) => {
          if (!p.nascimento) return false;
          const [ano, mes, dia] = p.nascimento.split('-');
          return parseInt(mes) === mesAtual;
        }) || [];

      setStats({
        membrosAtivosSemVisitantes: ativosSemVisitantes || 0,
        visitantes: visitantesCount || 0,
        totalLideres,
        lideresAtivos: totalLideres,
        eventosProximos: eventos?.length || 0,
        aniversariantesHoje: aniversariantesDoMes.length,
      });
    } catch (err) {
      console.error("fetchStats falhou:", err);
      throw err;
    }
  };

  const fetchUpcomingEvents = async () => {
    try {
      const today = new Date().toISOString().split("T")[0];
      const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0];

      const { data, error } = await supabase
        .from("agenda_full")
        .select("*")
        .gte("data", today)
        .lte("data", nextWeek)
        .order("data")
        .limit(5);

      if (error) throw error;
      setUpcomingEvents(data || []);
    } catch (err) {
      console.error("fetchUpcomingEvents falhou:", err);
      setUpcomingEvents([]);
    }
  };

  const fetchAniversariantes = async () => {
    try {
      const hoje = new Date();
      const mesAtual = hoje.getMonth() + 1;

      const { data, error } = await supabase
        .from("membros")
        .select("idmembro, nome, apelido, nascimento")
        .eq("status", "Ativo");
      if (error) throw error;

      // Filtra aniversariantes do mês - usando split para evitar problemas de timezone
      const aniversariantesTemp = data
        ?.filter((p) => {
          if (!p.nascimento) return false;
          const [ano, mes, dia] = p.nascimento.split('-');
          return parseInt(mes) === mesAtual;
        })
        .map((p) => {
          const [ano, mes, dia] = p.nascimento.split('-');
          const idade = hoje.getFullYear() - parseInt(ano);
          return { ...p, idade, relacionamentos: [] };
        })
        .sort(
          (a, b) => {
            const [, , diaA] = a.nascimento.split("-");
            const [, , diaB] = b.nascimento.split("-");
            return parseInt(diaA) - parseInt(diaB);
          }
        )
        .slice(0, 15) || [];

      // Busca relacionamentos para cada aniversariante
      const relacionamentosPromises = aniversariantesTemp.map(async (aniversariante) => {
        // Busca onde o aniversariante é o relacionado (filho)
        const { data: relDataFilho, error: relErrorFilho } = await supabase
          .from('relacionamentos_familiares')
          .select(`
            tipo_relacionamento,
            membros!relacionamentos_familiares_membro_id_fkey(nome, apelido)
          `)
          .eq('parente_id', aniversariante.idmembro);

        if (relErrorFilho) {
          console.error('Erro ao buscar relacionamentos como filho:', relErrorFilho);
        }

        // Busca onde o aniversariante é o titular (pai/mãe)
        const { data: relDataPai, error: relErrorPai } = await supabase
          .from('relacionamentos_familiares')
          .select(`
            tipo_relacionamento,
            membros!relacionamentos_familiares_parente_id_fkey(nome, apelido)
          `)
          .eq('membro_id', aniversariante.idmembro);

        if (relErrorPai) {
          console.error('Erro ao buscar relacionamentos como pai/mãe:', relErrorPai);
        }

        const relacionamentosFilho = relDataFilho?.map(rel => {
          return {
            tipo: rel.tipo_relacionamento,
            nome: rel.membros?.apelido || rel.membros?.nome || ''
          };
        }) || [];

        const relacionamentosPai = relDataPai?.map(rel => {
          return {
            tipo: rel.tipo_relacionamento,
            nome: rel.membros?.apelido || rel.membros?.nome || ''
          };
        }) || [];

        return { ...aniversariante, relacionamentos: [...relacionamentosFilho, ...relacionamentosPai] };
      });

      const aniversariantesData = await Promise.all(relacionamentosPromises);

      setAniversariantes(aniversariantesData);
    } catch (err) {
      console.error("fetchAniversariantes falhou:", err);
      setAniversariantes([]);
    }
  };

  const formatDate = (dateString: string) =>
    new Intl.DateTimeFormat("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      weekday: "short",
    }).format(new Date(dateString));

  const formatTime = (timeString: string) => (timeString ? timeString.slice(0, 5) : "");

  if (loading) {
    if (!authChecked) {
    return <LoadingState />;
  }

  if (!sessionUser || !userProfile) {
    return null; // Will be redirected to login
  }

  return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">Visão geral das atividades da igreja</p>
        <p className="text-xs text-muted-foreground mt-2">
          Usuário: {user.email || "—"} • Permissão: {user.permission}
        </p>
      </div>

      {/* Cards de estatística */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Membros Ativos (sem visitantes) */}
        <Card className="bg-gradient-to-r from-blue-500/10 to-blue-600/10 border-blue-200/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300">
              Membros Ativos
            </CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-800 dark:text-blue-200">
              {stats.membrosAtivosSemVisitantes}
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-400"></p>
          </CardContent>
        </Card>

        {/* Visitantes */}
        <Card className="bg-gradient-to-r from-amber-500/10 to-amber-600/10 border-amber-200/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-amber-700 dark:text-amber-300">
              Visitantes
            </CardTitle>
            <Users className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-800 dark:text-amber-200">
              {stats.visitantes}
            </div>
            <p className="text-xs text-amber-600 dark:text-amber-400"></p>
          </CardContent>
        </Card>

        {/* Líderes Ativos */}
        <Card className="bg-gradient-to-r from-green-500/10 to-green-600/10 border-green-200/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700 dark:text-green-300">
              Líderes Ativos
            </CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800 dark:text-green-200">
              {stats.lideresAtivos}
            </div>
            <p className="text-xs text-green-600 dark:text-green-400"></p>
          </CardContent>
        </Card>
      </div>

      {/* Próximos Eventos */}
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Próximos Eventos
            </CardTitle>
          </CardHeader>
        <CardContent>
            <div className="space-y-3">
              {upcomingEvents.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  Nenhum evento próximo
                </p>
              ) : (
                upcomingEvents.map((event, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                    <div className="flex flex-col items-center justify-center bg-primary/10 rounded-lg p-2 min-w-[60px]">
                      <span className="text-xs font-medium text-primary">
                        {formatDate(event.data)}
                      </span>
                      <span className="text-xs text-primary">
                        {formatTime(event.horario_inicial)}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{event.nome_evento}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        <span className="truncate">{event.nome_local || "Local não definido"}</span>
                      </div>
                      {event.departamento && (
                        <Badge variant="outline" className="mt-1 text-xs">
                          {event.departamento}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Aniversariantes do Mês */}
      {aniversariantes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5" />
              Aniversariantes do Mês
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {aniversariantes.map((pessoa, index) => {
                const [, , diaStr] = pessoa.nascimento.split("-");
                const dia = parseInt(diaStr);
                return (
                  <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-orange-500/10 border border-orange-200/20">
                    <div className="flex flex-col items-center justify-center w-12 h-12 bg-orange-100 rounded-full">
                      <span className="text-xs font-bold text-orange-800">{dia}</span>
                      <Gift className="h-3 w-3 text-orange-600 mt-1" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-orange-800 dark:text-orange-200">
                        {pessoa.apelido || pessoa.nome}
                      </p>
                      <p className="text-sm text-orange-600 dark:text-orange-400">
                        {pessoa.idade} anos
                      </p>
                      {pessoa.relacionamentos && pessoa.relacionamentos.length > 0 && (
                        <div className="mt-1">
                          {pessoa.relacionamentos.map((rel, idx) => {
                            let tipoRelacao = '';
                            if (rel.tipo === 'pai' || rel.tipo === 'mae' || rel.tipo === 'filho' || rel.tipo === 'filha' || rel.tipo === 'conjuge' || rel.tipo === 'irmao' || rel.tipo === 'irma') {
                              tipoRelacao = rel.tipo.charAt(0).toUpperCase() + rel.tipo.slice(1);
                            }
                            return tipoRelacao ? (
                              <p key={idx} className="text-xs text-orange-600 dark:text-orange-400">
                                {rel.nome} ({tipoRelacao})
                              </p>
                            ) : null;
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Dashboard;
