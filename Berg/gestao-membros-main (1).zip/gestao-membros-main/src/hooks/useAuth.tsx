import { useState, useEffect, useRef } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface UserProfile {
  email: string;
  permission: 'ADM' | 'LDR' | 'USR' | 'MTR' | 'OPE';
  memberName?: string;
  idmembro?: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileFetched, setProfileFetched] = useState(false);
  const signingOutRef = useRef(false);
  
  console.log('useAuth render - user:', !!user, 'session:', !!session, 'userProfile:', !!userProfile, 'loading:', loading, 'profileFetched:', profileFetched);

  const fetchUserProfile = async (userId: string, userEmail?: string) => {
    try {
      console.log('🔍 fetchUserProfile: Starting for userId:', userId, 'email:', userEmail);
      
      // Adiciona um timeout para a requisição
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Timeout fetching user profile')), 10000)
      );

      console.log('🔍 fetchUserProfile: Making Supabase query...');
      const fetchPromise = supabase
        .from('usuarios')
        .select('email, permissao, idmembro')
        .eq('auth_uid', userId)
        .maybeSingle();

      const result = await Promise.race([fetchPromise, timeoutPromise])
        .catch(error => {
          console.error('🚨 fetchUserProfile: Failed to fetch user profile:', error);
          return { data: null, error };
        });
      
      console.log('🔍 fetchUserProfile: Query result:', result);
      const { data: profile, error } = result as { data: any, error: any };
      
      if (error) {
        console.error('🚨 fetchUserProfile: Error fetching user from usuarios:', error);
        throw error;
      }
      
      if (!profile) {
        console.warn('⚠️ fetchUserProfile: No profile found for user:', userId, 'returning default profile');
        // Retorna um perfil padrão em vez de null
        const defaultProfile = {
          email: userEmail || '',
          permission: 'USR' as const,
          memberName: undefined,
          idmembro: undefined
        };
        console.log('✅ fetchUserProfile: Returning default profile:', defaultProfile);
        return defaultProfile;
      }

      console.log('✅ fetchUserProfile: Found user profile:', profile);

      let memberName = profile.idmembro;
      if (profile.idmembro) {
        const { data: memberData, error: memberError } = await supabase
          .from('membros')
          .select('apelido, nome')
          .eq('idmembro', profile.idmembro)
          .maybeSingle();
        
        if (memberError) {
          console.error('Error fetching member data:', memberError);
        } else if (memberData) {
          memberName = memberData.apelido || memberData.nome || profile.idmembro;
          console.log('Found member data:', memberData);
        }
      }

      const userProfile = {
        email: profile.email,
        permission: profile.permissao as 'ADM' | 'LDR' | 'USR' | 'MTR' | 'OPE',
        memberName,
        idmembro: profile.idmembro
      };

      console.log('Returning user profile:', userProfile);
      return userProfile;
    } catch (err) {
      console.error('Error in fetchUserProfile:', err);
      // Retorna um perfil padrão em vez de null em caso de erro
      return {
         email: userEmail || '',
         permission: 'USR' as const,
         memberName: undefined,
         idmembro: undefined
       };
    }
  };

  useEffect(() => {
    let mounted = true;

    const handleAuthChange = async (session: Session | null) => {
      if (!mounted) return;
      
      console.log('🔄 handleAuthChange: Auth state changed:', session ? 'Session exists' : 'No session');
      
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        try {
          console.log('🔄 handleAuthChange: Fetching profile for user:', session.user.id);
          const profile = await fetchUserProfile(session.user.id, session.user.email);
          if (mounted) {
            console.log('🔄 handleAuthChange: Setting profile:', profile);
            setUserProfile(profile);
            setProfileFetched(true);
            setLoading(false);
            console.log('✅ handleAuthChange: Profile set successfully, loading finished');
          }
        } catch (error) {
          console.error('🚨 handleAuthChange: Error fetching profile, setting default profile:', error);
          if (mounted) {
            const defaultProfile = {
              email: session.user.email || '',
              permission: 'USR' as const,
              memberName: undefined,
              idmembro: undefined
            };
            setUserProfile(defaultProfile);
            setProfileFetched(true);
            setLoading(false);
          }
        }
      } else {
        if (mounted) {
          console.log('🔄 handleAuthChange: No session, clearing state');
          setUserProfile(null);
          setProfileFetched(false);
          setLoading(false);
        }
      }
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth event:', event);

      if (event === 'SIGNED_OUT' && !session) {
        if (signingOutRef.current) {
          console.log('SIGNED_OUT during manual signOut; skipping redirect/toast.');
          // Limpa estado local rapidamente
          setSession(null);
          setUser(null);
          setUserProfile(null);
          setProfileFetched(false);
          setLoading(false);
          return;
        }
        console.warn('Signed out event (likely expired), clearing local session and redirecting to login.');
        setUser(null);
        setSession(null);
        setUserProfile(null);
        setProfileFetched(false);
        setLoading(false);
        toast({ title: 'Sessão expirada', description: 'Faça login novamente.', variant: 'destructive' });
        setTimeout(() => {
          window.location.href = '/login';
        }, 100);
        return;
      }

      // Atualiza sessão/usuário de forma síncrona
      setSession(session);
      setUser(session?.user ?? null);

      if (session?.user) {
        // Deferir chamadas ao Supabase para evitar deadlocks
        setLoading(true);
        const uid = session.user.id;
        const email = session.user.email;
        setTimeout(() => {
          fetchUserProfile(uid, email)
            .then((profile) => {
              setUserProfile(profile);
              setProfileFetched(true);
              setLoading(false);
            })
            .catch((error) => {
              console.error('Error fetching profile (deferred):', error);
              setUserProfile({
                email: email || '',
                permission: 'USR',
                memberName: undefined,
                idmembro: undefined,
              });
              setProfileFetched(true);
              setLoading(false);
            });
        }, 0);
      } else {
        setUserProfile(null);
        setProfileFetched(false);
        setLoading(false);
      }
    });

    supabase.auth.getSession().then(
      (response) => handleAuthChange(response.data.session)
    ).catch(err => {
      console.error('useAuth: Error getting initial session:', err);
      if (mounted) setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []); // Dependências vazias estão corretas - só roda uma vez

  const signIn = async (email: string, password: string) => {
    console.log('Attempting sign in for:', email);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.error('Sign in error:', error);
    } else {
      console.log('Sign in successful:', data);
    }
    
    return { error };
  };

  const signOut = async () => {
    console.log('Attempting sign out');
    let logoutError: any = null;
    try {
      signingOutRef.current = true;
      // Usar escopo local evita chamada global; suficiente para limpar cliente
      const { error } = await supabase.auth.signOut({ scope: 'local' });
      logoutError = error || null;
      if (logoutError && String(logoutError.message || '').includes('Refresh Token Not Found')) {
        // Erro comum em sessões já invalidadas; trata como sucesso
        console.warn('SignOut warning ignored: Refresh Token Not Found');
        logoutError = null;
      }
    } catch (err) {
      console.warn('SignOut request threw but was ignored:', err);
    } finally {
      // Sempre limpa estado local
      setUser(null);
      setSession(null);
      setUserProfile(null);
      setProfileFetched(false);
      console.log('Sign out finished (local state cleared)');
      signingOutRef.current = false;
      await new Promise((r) => setTimeout(r, 100));
      window.location.href = '/login';
    }
    return { error: logoutError };
  };

  // Fallback: evita ficar preso em loading em dispositivos que bloqueiam eventos iniciais
  useEffect(() => {
    if (!loading) return;
    const t = setTimeout(() => {
      console.warn('useAuth: fallback timeout hit, forcing loading=false');
      setLoading(false);
    }, 5000);
    return () => clearTimeout(t);
  }, [loading]);

  return {
    user,
    session,
    userProfile,
    loading,
    signIn,
    signOut
  };
}