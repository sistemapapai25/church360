import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface UserData {
  idusuario: string;
  email: string;
  idmembro: string | null;
  permissao: string;
  auth_uid: string;
  nome_membro: string;
  created_at: string;
}

export function useUsers() {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('list_users');
      if (error) throw error;
      setUsers(data || []);
    } catch (err) {
      toast({
        title: "Erro ao carregar usuários",
        description: err instanceof Error ? err.message : "Erro desconhecido",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const createUser = async (email: string, password: string, permissao: string = 'USR', idmembro: string) => {
    try {
      const { data, error } = await supabase.rpc('create_user_with_profile', {
        p_email: email,
        p_password: password,
        p_permissao: permissao,
        p_idmembro: idmembro
      });

      if (error) throw error;

      toast({
        title: "Usuário criado com sucesso!",
        description: `E-mail: ${email}`,
      });

      // Recarregar lista de usuários
      await fetchUsers();
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro ao criar usuário';
      toast({
        title: "Erro ao criar usuário",
        description: message,
        variant: "destructive"
      });
      return { success: false, error: message };
    }
  };

  const resetPassword = async (userId: string | null, email: string, newPassword: string = '123456') => {
    try {
      // Verificar se userId é válido
      if (!userId || userId === 'null' || userId === null) {
        throw new Error('Usuário não possui ID de autenticação válido. Entre em contato com o administrador do sistema.');
      }

      console.log('🔄 Resetando senha para usuario ID:', userId);
      
      const { data, error } = await supabase.rpc('reset_user_password', {
        p_user_id: userId,
        p_new_password: newPassword
      });

      if (error) throw error;

      toast({
        title: "Senha resetada com sucesso!",
        description: `Nova senha para ${email}: ${newPassword}`,
      });

      return { success: true };
    } catch (err) {
      console.error('❌ Erro ao resetar senha:', err);
      const message = err instanceof Error ? err.message : 'Erro ao resetar senha';
      toast({
        title: "Erro ao resetar senha",
        description: message,
        variant: "destructive"
      });
      return { success: false, error: message };
    }
  };

  const updateUser = async (idusuario: string, updates: { email?: string; permissao?: string }) => {
    try {
      const { data, error } = await supabase.rpc('update_user_info' as any, {
        p_idusuario: idusuario,
        p_email: updates.email,
        p_permissao: updates.permissao
      });

      if (error) throw error;

      toast({
        title: "Usuário atualizado com sucesso!",
        description: "As informações do usuário foram atualizadas.",
      });

      // Recarregar lista de usuários
      await fetchUsers();
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro ao atualizar usuário';
      toast({
        title: "Erro ao atualizar usuário",
        description: message,
        variant: "destructive"
      });
      return { success: false, error: message };
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return {
    users,
    loading,
    fetchUsers,
    createUser,
    resetPassword,
    updateUser
  };
}