import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface Area {
  idarea: string;
  nome: string;
  descricao?: string | null;
  iddepto: string;
  status: string;
  lider1?: string | null;
  lider2?: string | null;
  nome_departamento?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Departamento {
  iddepto: string;
  nome: string;
}

function buildErrorDescription(err: unknown) {
  if (err && typeof err === 'object') {
    const e = err as any;
    const parts = [e.message, e.details, e.hint, e.code].filter(Boolean);
    if (parts.length) return parts.join(' | ');
  }
  return 'Erro desconhecido';
}

export function useAreas() {
  const [areas, setAreas] = useState<Area[]>([]);
  const [departamentos, setDepartamentos] = useState<Departamento[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAreas = async () => {
    setLoading(true);
    try {
      // Áreas ativas
      const { data: areasData, error: areasError } = await supabase
        .from('areas')
        .select('*')
        .eq('status', 'Ativo')
        .order('nome', { ascending: true });

      if (areasError) throw areasError;

      // Departamentos (para exibir nome)
      const { data: deptsData, error: deptsError } = await supabase
        .from('departamentos')
        .select('iddepto, nome');

      if (deptsError) throw deptsError;

      const areasWithDeptName =
        areasData?.map((area) => {
          const dept = deptsData?.find((d) => d.iddepto === area.iddepto);
          return { ...area, nome_departamento: dept?.nome } as Area;
        }) || [];

      setAreas(areasWithDeptName);
    } catch (err) {
      toast({
        title: 'Erro ao carregar áreas',
        description: buildErrorDescription(err),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartamentos = async () => {
    try {
      const { data, error } = await supabase
        .from('departamentos')
        .select('iddepto, nome')
        .order('nome', { ascending: true });

      if (error) throw error;
      setDepartamentos(data || []);
    } catch (err) {
      toast({
        title: 'Erro ao carregar departamentos',
        description: buildErrorDescription(err),
        variant: 'destructive',
      });
    }
  };

  const createArea = async (nome: string, descricao: string, iddepto: string, lider1?: string | null, lider2?: string | null) => {
    try {
      const nomeTrim = (nome || '').trim();
      if (!nomeTrim) {
        toast({ title: 'Informe o nome da área', variant: 'destructive' });
        return { success: false, error: 'Nome obrigatório' };
      }
      if (!iddepto) {
        toast({ title: 'Selecione um departamento', variant: 'destructive' });
        return { success: false, error: 'Departamento obrigatório' };
      }

      const { data, error } = await supabase
        .from('areas')
        .insert({
          nome: nomeTrim,
          descricao: descricao?.trim() || null,
          iddepto,
          status: 'Ativo',
          lider1: lider1 ?? null,
          lider2: lider2 ?? null,
        })
        .select('*')
        .single(); // garante retorno da linha inserida

      if (error) throw error;

      toast({
        title: 'Área criada!',
        description: `${data?.nome || nomeTrim} foi criada com sucesso.`,
      });

      await fetchAreas();
      return { success: true };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao criar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const updateArea = async (
    idarea: string,
    nome: string,
    descricao: string,
    iddepto: string,
    lider1?: string | null,
    lider2?: string | null,
  ) => {
    try {
      const nomeTrim = (nome || '').trim();
      if (!idarea) return { success: false, error: 'idarea inválido' };
      if (!nomeTrim) {
        toast({ title: 'Informe o nome da área', variant: 'destructive' });
        return { success: false, error: 'Nome obrigatório' };
      }
      if (!iddepto) {
        toast({ title: 'Selecione um departamento', variant: 'destructive' });
        return { success: false, error: 'Departamento obrigatório' };
      }

      const { error } = await supabase
        .from('areas')
        .update({
          nome: nomeTrim,
          descricao: descricao?.trim() || null,
          iddepto,
          lider1: lider1 ?? null,
          lider2: lider2 ?? null,
          updated_at: new Date().toISOString(),
        })
        .eq('idarea', idarea);

      if (error) throw error;

      toast({
        title: 'Área atualizada!',
        description: `${nomeTrim} foi atualizada com sucesso.`,
      });

      await fetchAreas();
      return { success: true };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao atualizar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const deleteArea = async (idarea: string, nome: string) => {
    try {
      if (!idarea) return { success: false, error: 'idarea inválido' };

      // Soft delete (status = Inativo)
      const { error } = await supabase
        .from('areas')
        .update({ status: 'Inativo', updated_at: new Date().toISOString() })
        .eq('idarea', idarea);

      if (error) throw error;

      toast({
        title: 'Área desativada!',
        description: `${nome} foi desativada com sucesso.`,
      });

      await fetchAreas();
      return { success: true };
    } catch (err) {
      const message = buildErrorDescription(err);
      toast({
        title: 'Erro ao desativar área',
        description: message,
        variant: 'destructive',
      });
      return { success: false, error: message };
    }
  };

  const getAreasByDepartamento = (iddepto: string) =>
    areas.filter((area) => area.iddepto === iddepto);

  useEffect(() => {
    fetchAreas();
    fetchDepartamentos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    areas,
    departamentos,
    loading,
    fetchAreas,
    fetchDepartamentos,
    createArea,
    updateArea,
    deleteArea,
    getAreasByDepartamento,
  };
}
