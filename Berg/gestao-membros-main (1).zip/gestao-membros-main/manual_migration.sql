-- SQL para executar manualmente no Supabase Dashboard
-- Este script torna o campo iddepto nullable na tabela lideres
-- para preservar o histórico quando departamentos são excluídos

-- 1. Remover a constraint existente lideres_iddepto_fkey
ALTER TABLE public.lideres DROP CONSTRAINT IF EXISTS lideres_iddepto_fkey;

-- 2. Tornar a coluna iddepto nullable (permitir valores NULL)
ALTER TABLE public.lideres ALTER COLUMN iddepto DROP NOT NULL;

-- 3. Recriar a constraint com ON DELETE SET NULL para preservar histórico
ALTER TABLE public.lideres
ADD CONSTRAINT lideres_iddepto_fkey
FOREIGN KEY (iddepto)
REFERENCES public.departamentos(iddepto)
ON DELETE SET NULL;

-- Verificar se a alteração foi aplicada corretamente
SELECT 
    column_name, 
    is_nullable, 
    data_type 
FROM information_schema.columns 
WHERE table_name = 'lideres' 
AND column_name = 'iddepto';